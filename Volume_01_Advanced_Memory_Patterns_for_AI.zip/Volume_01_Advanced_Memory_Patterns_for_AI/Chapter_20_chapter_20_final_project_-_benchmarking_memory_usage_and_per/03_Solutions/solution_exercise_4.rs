
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.rs
// Description: Solution for Exercise 4
// ==========================================

struct Block {
    id: u32,
    offset: usize,
    size: usize,
    is_free: bool,
}

struct MemoryVisualizer {
    memory_size: usize,
    blocks: Vec<Block>,
}

impl MemoryVisualizer {
    pub fn new(total_size: usize) -> Self {
        MemoryVisualizer {
            memory_size: total_size,
            blocks: vec
![Block { id: 0, offset: 0, size: total_size, is_free: true }
],
        }
    }

    pub fn allocate(&mut self, id: u32, size: usize) {
        // Find a free block that fits the size (First Fit strategy)
        let mut target_index = None;
        for (i, block) in self.blocks.iter().enumerate() {
            if block.is_free && block.size >= size {
                target_index = Some(i);
                break;
            }
        }

        if let Some(index) = target_index) {
            let block = &self.blocks[index];
            let offset = block.offset;
            let remaining = block.size - size;

            // Split the block: replace the free block with the allocated one
            // and insert a new free block for the remainder if any.
            self.blocks[index] = Block { id, offset, size, is_free: false };
            
            if remaining > 0 {
                let new_block = Block {
                    id: 0,
                    offset: offset + size,
                    size: remaining,
                    is_free: true,
                };
                self.blocks.insert(index + 1, new_block);
            }
            println!("Allocated Block {} at offset {}, size {}", id, offset, size);
        } else {
            println!("Failed to allocate Block {} (size {}): Not enough contiguous space", id, size);
        }
    }

    pub fn deallocate(&mut self, id: u32) {
        if let Some(index) = self.blocks.iter().position(|b| b.id == id) {
            self.blocks[index].is_free = true;
            self.blocks[index].id = 0; // Clear ID
            println!("Deallocated Block {} at offset {}", id, self.blocks[index].offset);
            self.merge_free_blocks();
        }
    }

    fn merge_free_blocks(&mut self) {
        let mut i = 0;
        while i < self.blocks.len() - 1 {
            if self.blocks[i].is_free && self.blocks[i + 1].is_free {
                // Merge i and i+1
                let next_size = self.blocks[i + 1].size;
                self.blocks[i].size += next_size;
                self.blocks.remove(i + 1);
            } else {
                i += 1;
            }
        }
    }

    pub fn generate_dot_graph(&self) -> String {
        let mut dot = String::from("digraph MemoryLayout {\n");
        dot += "  node [shape=box, fontname=\"Arial\"];\n";
        dot += "  rankdir=LR;\n";
        
        // Create a single cluster for the memory
        dot += "  subgraph cluster_memory {\n";
        dot += "    label = \"Memory Layout (Total: 1024 bytes)\";\n";
        dot += "    style = filled;\n";
        dot += "    color = lightgrey;\n";

        for block in &self.blocks {
            let color = if block.is_free { "green" } else { "red" };
            let label = if block.is_free { 
                format!("Free\\nOffset: {}\\nSize: {}", block.offset, block.size) 
            } else { 
                format!("ID: {}\\nOffset: {}\\nSize: {}", block.id, block.offset, block.size) 
            };
            
            dot += &format!("    block_{}_{} [label=\"{}\", style=filled, fillcolor={}];\n", 
                            block.offset, block.size, label, color);
        }
        dot += "  }\n";
        dot += "}\n";
        dot
    }
}

pub fn run_fragmentation_demo() {
    let mut viz = MemoryVisualizer::new(1024);

    // Sequence
    viz.allocate(1, 100); // A
    viz.allocate(2, 200); // B
    viz.deallocate(1);    // Deallocate A
    viz.allocate(3, 50);  // C (Fits in A's hole)
    viz.allocate(4, 150); // D (Likely fits after B or C? Let's see)
                          // Current layout: [Free(0-50)][C(50-100)][B(100-300)][Free(300-1024)]
                          // D needs 150. It fits in Free(300-1024).
                          // To create fragmentation, we need to force D into a smaller hole or leave a hole.
                          // Let's adjust the sequence slightly to ensure fragmentation is visible.
                          // Actually, let's Deallocate B to create a large hole, then allocate C (small) and D (medium)
                          // to split the free space.
    
    // Let's restart the sequence for better visualization of fragmentation
    let mut viz2 = MemoryVisualizer::new(1024);
    viz2.allocate(1, 200); // A (Offset 0-200)
    viz2.allocate(2, 300); // B (Offset 200-500)
    viz2.deallocate(1);    // Free (0-200)
    viz2.allocate(3, 100); // C (Fits in 0-200, leaving 100-200 free)
    viz2.allocate(4, 150); // D (Needs 150. 100-200 is too small (size 100). Must go after B (500+))
    
    println!("{}", viz2.generate_dot_graph());
}
