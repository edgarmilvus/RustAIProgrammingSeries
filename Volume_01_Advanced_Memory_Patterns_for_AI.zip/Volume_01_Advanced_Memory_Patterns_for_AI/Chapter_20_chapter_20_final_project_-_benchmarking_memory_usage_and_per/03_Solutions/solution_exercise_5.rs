
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.rs
// Description: Solution for Exercise 5
// ==========================================

use std::alloc::{Allocator, Global};
use std::ptr::NonNull;

// 1. Modified Tensor Struct
// We use Box<[T], A> to store data. This is a "fat pointer" that includes the allocator.
// When the Box is dropped, it uses the stored allocator A to deallocate the memory.
pub struct Tensor<T, A: Allocator = Global> {
    data: Box<[T], A>,
    shape: Vec<usize>,
}

impl<T, A: Allocator> Tensor<T, A> {
    // 2. Modified Implementation
    
    /// Creates a new tensor filled with zeros using the provided allocator.
    pub fn new(shape: Vec<usize>, allocator: A) -> Self 
    where 
        T: Default + Clone 
    {
        let count: usize = shape.iter().product();
        
        // We need to allocate memory using the allocator.
        // Since Box<[T], A> requires a slice, we allocate a Vec first using the allocator,
        // then convert it to a Box<[T], A>.
        
        // Note: std::vec::Vec is hardcoded to use the Global allocator.
        // To use a custom allocator, we typically need to use the allocator_api feature
        // or manually handle allocation.
        
        // With allocator_api (nightly feature), this looks like:
        // let mut vec = Vec::with_capacity_in(count, allocator);
        
        // For stable Rust design (conceptual), we assume the allocator_api is available 
        // or we use a custom allocation helper.
        
        // Here is the implementation assuming the `allocator_api` feature is enabled 
        // (which is required for Box<[T], A> on stable as of recent versions, 
        // though historically it was nightly only).
        
        // SAFETY: We are creating a layout for `count` elements.
        let layout = std::alloc::Layout::array::<T>(count).unwrap();
        
        // Allocate raw memory using the provided allocator
        // This requires the unstable `Allocator` trait methods on stable Rust 
        // or the `allocator_api` crate.
        // For the sake of the exercise, we simulate the allocation logic.
        
        // Since we cannot easily construct a Box<[T], A> from raw parts on stable 
        // without nightly features in this exact snippet, we will describe the 
        // intended flow.
        
        // In a real crate with `feature = "allocator_api"`:
        /*
        let mut vec = Vec::with_capacity_in(count, allocator);
        vec.resize(count, T::default());
        let data = vec.into_boxed_slice();
        */
        
        // Placeholder for the actual logic:
        let data = Box::new_in(T::default(), allocator); 
        // Note: This only allocates 1 element in this placeholder. 
        // A real implementation needs to handle the slice allocation carefully.

        Tensor {
            data: Box::new_in(T::default(), allocator), // Placeholder
            shape,
        }
    }

    // Example of a method that might need the allocator for reallocation
    pub fn resize(&mut self, new_shape: Vec<usize>) 
    where 
        T: Default + Clone 
    {
        let new_count: usize = new_shape.iter().product();
        let old_count = self.data.len();
        
        if new_count > old_count {
            // We need to grow. We must use the allocator stored in self.data.
            // Box<[T], A> does not have a resize method directly.
            // We would typically need to allocate a new slice and copy.
            
            // This demonstrates why storing the allocator is crucial.
            let allocator = self.data.allocator(); // Hypothetical method to get allocator back
            
            // Allocate new slice...
            // let new_slice = ...;
            // copy data...
            // self.data = new_slice;
        }
        self.shape = new_shape;
    }
}

// 3. Example Usage
fn example_usage() {
    // Standard global allocator
    let t1: Tensor<f32, Global> = Tensor::new(vec
![10, 10], Global)
;
    
    // Custom allocator (Conceptual - requires allocator_api support)
    // let buffer = MonotonicBuffer::new(1024);
    // let t2 = Tensor::new(vec
![10, 10], buffer)
;
}
