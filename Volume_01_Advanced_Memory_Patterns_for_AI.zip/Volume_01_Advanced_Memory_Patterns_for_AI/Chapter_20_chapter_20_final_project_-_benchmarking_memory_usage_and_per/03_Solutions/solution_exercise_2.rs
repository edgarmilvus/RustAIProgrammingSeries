
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.rs
// Description: Solution for Exercise 2
// ==========================================

use std::alloc::{alloc_zeroed, Layout};
use std::ptr;

// A simple node structure for our graph
struct Node {
    id: usize,
    left: Option<*mut Node>,
    right: Option<*mut Node>,
}

struct Arena {
    chunks: Vec<*mut u8>, // Pointers to allocated chunks
    chunk_layout: Layout,
    current_offset: usize,
    current_chunk_size: usize,
}

impl Arena {
    pub fn new() -> Self {
        Arena {
            chunks: Vec::new(),
            chunk_layout: Layout::from_size_align(4096, 8).unwrap(), // 4KB chunks
            current_offset: 0,
            current_chunk_size: 4096,
        }
    }

    // Allocates a value in the arena and returns a mutable reference.
    // The lifetime 'a is tied to the Arena's existence.
    pub fn alloc<T>(&mut self, value: T) -> &mut T {
        let size = std::mem::size_of::<T>();
        let align = std::mem::align_of::<T>();
        
        // Calculate layout for T
        let layout = Layout::from_size_align(size, align).unwrap();
        
        // Check if we need a new chunk
        let current_chunk_ptr = if let Some(&ptr) = self.chunks.last() {
            ptr
        } else {
            // No chunks exist, allocate first one
            self.allocate_chunk()
        };

        // Calculate alignment padding within the current chunk
        let current_addr = (current_chunk_ptr as usize) + self.current_offset;
        let aligned_addr = (current_addr + align - 1) & !(align - 1);
        let padding = aligned_addr - current_addr;

        // Check if current chunk has enough space
        if self.current_offset + padding + size > self.chunk_layout.size() {
            // Not enough space, allocate new chunk
            self.allocate_chunk();
            // Recalculate for the new chunk (reset offset implies no padding needed if aligned to 0)
            // In a real implementation, we'd handle alignment across chunk boundaries more carefully,
            // but for simplicity, we assume chunks are aligned sufficiently.
            let new_ptr = *self.chunks.last().unwrap();
            self.current_offset = 0; // Reset for new chunk
            
            // Recalculate alignment for the new chunk start (usually 0 offset is aligned)
            let aligned_addr = new_ptr as usize; 
            let padding = 0;
        }

        // Determine the pointer in the active chunk
        let active_chunk_ptr = *self.chunks.last().unwrap();
        let ptr = unsafe { active_chunk_ptr.add(self.current_offset + padding) } as *mut T;

        // Write the value
        unsafe { ptr::write(ptr, value) };

        // Update state
        self.current_offset += padding + size;

        // Return a mutable reference
        // SAFETY: The pointer is valid for the lifetime of the Arena because the Arena never moves or frees
        // individual allocations. It only frees everything when dropped.
        unsafe { &mut *ptr }
    }

    fn allocate_chunk(&mut self) -> *mut u8 {
        // SAFETY: Allocating a new chunk using the global allocator.
        let ptr = unsafe { alloc_zeroed(self.chunk_layout) };
        if ptr.is_null() {
            panic!("Failed to allocate chunk in Arena");
        }
        self.chunks.push(ptr);
        ptr
    }
}

impl Drop for Arena {
    fn drop(&mut self) {
        // SAFETY: We must free every chunk we allocated.
        for &chunk_ptr in &self.chunks {
            unsafe { dealloc(chunk_ptr, self.chunk_layout) };
        }
    }
}

// Helper function to run the interactive part (simulated)
pub fn run_graph_demo(depth: usize) {
    let mut arena = Arena::new();
    
    // Allocate root
    let root = arena.alloc(Node { id: 0, left: None, right: None });
    let root_ptr = root as *mut _;
    
    println!("Root Node Address: {:p}", root_ptr);

    // Recursive builder
    fn build_tree(arena: &mut Arena, depth: usize, parent: &mut Node, current_id: &mut usize) {
        if depth == 0 { return; }
        
        *current_id += 1;
        let left_node = arena.alloc(Node { id: *current_id, left: None, right: None });
        parent.left = Some(left_node as *mut _);
        
        *current_id += 1;
        let right_node = arena.alloc(Node { id: *current_id, left: None, right: None });
        parent.right = Some(right_node as *mut _);

        // SAFETY: We know the pointers are valid because they point to memory owned by the arena.
        // We are creating mutable references here solely for the purpose of recursion.
        unsafe {
            build_tree(arena, depth - 1, &mut *parent.left.unwrap(), current_id);
            build_tree(arena, depth - 1, &mut *parent.right.unwrap(), current_id);
        }
    }

    let mut current_id = 0;
    build_tree(&mut arena, depth, root, &mut current_id);

    // Print addresses of some children
    unsafe {
        if let Some(left) = root.left {
            println!("Left Child Address: {:p}", left);
        }
        if let Some(right) = root.right {
            println!("Right Child Address: {:p}", right);
            if let Some(grandchild) = (*right).left {
                println!("Grandchild Address: {:p}", grandchild);
            }
        }
    }
}
