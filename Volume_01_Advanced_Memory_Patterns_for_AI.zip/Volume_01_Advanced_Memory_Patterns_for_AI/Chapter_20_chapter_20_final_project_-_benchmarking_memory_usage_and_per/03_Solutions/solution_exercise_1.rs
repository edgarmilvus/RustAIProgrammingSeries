
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

use std::alloc::{alloc_zeroed, dealloc, Layout};
use std::ptr;

struct MonotonicBuffer {
    ptr: *mut u8,
    start: *mut u8,
    capacity: usize,
    offset: usize,
}

impl MonotonicBuffer {
    pub fn new(capacity: usize) -> Self {
        // Create a layout for the total capacity.
        // We use align_of::<u8>() which is 1, but a real implementation might want stricter alignment.
        let layout = Layout::from_size_align(capacity, std::mem::align_of::<u8>()).unwrap();
        
        // SAFETY: We are allocating a block of memory of the given layout.
        // We use alloc_zeroed to ensure memory is initialized, preventing undefined behavior 
        // if the user reads before writing (though typically unsafe).
        let ptr = unsafe { alloc_zeroed(layout) };
        
        if ptr.is_null() {
            panic!("Failed to allocate memory for MonotonicBuffer");
        }

        MonotonicBuffer {
            ptr,
            start: ptr,
            capacity,
            offset: 0,
        }
    }

    pub fn alloc<T>(&mut self, count: usize) -> *mut T {
        let size = std::mem::size_of::<T>() * count;
        let align = std::mem::align_of::<T>();
        
        // Calculate the layout for the requested allocation.
        let layout = Layout::from_size_align(size, align).unwrap();

        // Calculate the offset required to align the current pointer to `align`.
        // The formula `(addr + (align - 1)) & !(align - 1)` aligns `addr` to the next multiple of `align`.
        let current_addr = self.ptr as usize;
        let aligned_addr = (current_addr + align - 1) & !(align - 1);
        let padding = aligned_addr - current_addr;

        // Check for capacity overflow.
        if self.offset + padding + size > self.capacity {
            panic!("MonotonicBuffer out of capacity");
        }

        // SAFETY: 
        // 1. We have verified sufficient capacity.
        // 2. `aligned_addr` is properly aligned for `T` due to the calculation above.
        // 3. We are returning a pointer to a valid memory region within our allocated block.
        let aligned_ptr = unsafe { self.ptr.add(padding) } as *mut T;

        // Update internal state
        self.offset += padding + size;
        // SAFETY: We update self.ptr to point to the next free byte. 
        // We know this arithmetic is valid because we just checked capacity.
        self.ptr = unsafe { self.ptr.add(padding + size) };

        aligned_ptr
    }

    pub fn reset(&mut self) {
        // Reset the pointer and offset to the start of the buffer.
        // We do not deallocate; we just allow overwriting the memory.
        self.ptr = self.start;
        self.offset = 0;
    }
}

impl Drop for MonotonicBuffer {
    fn drop(&mut self) {
        // SAFETY: We allocated this memory in `new` using the standard allocator.
        // We must free it using the same layout.
        let layout = Layout::from_size_align(self.capacity, std::mem::align_of::<u8>()).unwrap();
        unsafe {
            dealloc(self.start, layout);
        }
    }
}
