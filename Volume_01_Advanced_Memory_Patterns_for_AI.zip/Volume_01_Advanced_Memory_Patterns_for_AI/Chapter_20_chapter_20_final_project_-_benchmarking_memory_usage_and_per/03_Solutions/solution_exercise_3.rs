
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.rs
// Description: Solution for Exercise 3
// ==========================================

use std::time::Instant;
use std::ptr;

const TENSOR_SIZE: usize = 1024;

struct TensorPool {
    storage: Vec<u8>,
    free_list: Vec<*mut [f32; TENSOR_SIZE]>,
}

impl TensorPool {
    pub fn new(size: usize) -> Self {
        // Allocate a large block of raw memory
        let mut storage = vec
![0u8; size];
        let storage_ptr = storage.as_mut_ptr()
 as *mut u8;
        
        // Pre-fill the free list
        // We assume `size` is a multiple of the tensor size for simplicity
        let num_slots = size / std::mem::size_of::<[f32; TENSOR_SIZE]>();
        let mut free_list = Vec::with_capacity(num_slots);
        
        for i in 0..num_slots {
            let ptr = unsafe { storage_ptr.add(i * std::mem::size_of::<[f32; TENSOR_SIZE]>()) } as *mut [f32; TENSOR_SIZE];
            free_list.push(ptr);
        }

        TensorPool { storage, free_list }
    }

    pub fn acquire(&mut self) -> Option<*mut [f32; TENSOR_SIZE]> {
        self.free_list.pop()
    }

    pub fn release(&mut self, ptr: *mut [f32; TENSOR_SIZE]) {
        // In a real implementation, we might want to zero out memory here for safety,
        // but for raw speed, we just push it back to the free list.
        self.free_list.push(ptr);
    }
}

// Strategy A: Vec<f32>
fn strategy_a(iterations: usize) {
    let start = Instant::now();
    for _ in 0..iterations {
        // Allocate on heap every iteration
        let _tensor = vec
![0.0f32; TENSOR_SIZE];
        // Drop happens here automatically
    }
    println!("Strategy A (Vec)
: {:?}", start.elapsed());
}

// Strategy B: Box<[f32; 1024]>
fn strategy_b(iterations: usize) {
    let start = Instant::now();
    for _ in 0..iterations {
        // Allocate on heap every iteration
        let _tensor = Box::new([0.0f32; TENSOR_SIZE]);
    }
    println!("Strategy B (Box): {:?}", start.elapsed());
}

// Strategy C: TensorPool
fn strategy_c(iterations: usize) {
    // Pre-allocate pool large enough for all iterations
    let total_bytes = iterations * std::mem::size_of::<[f32; TENSOR_SIZE]>();
    let mut pool = TensorPool::new(total_bytes);
    
    let start = Instant::now();
    for _ in 0..iterations {
        if let Some(ptr) = pool.acquire() {
            // SAFETY: We own the pointer and it points to valid memory in the pool storage.
            // We treat it as a mutable reference for the scope of the "tensor usage".
            unsafe {
                // Simulate usage: zeroing the memory
                ptr::write_bytes(ptr, 0, 1);
            }
            pool.release(ptr);
        } else {
            panic!("Pool exhausted");
        }
    }
    println!("Strategy C (Pool):  {:?}", start.elapsed());
}

pub fn run_benchmark() {
    let iterations = 100_000; // High number to see differences
    
    println!("Running {} iterations...", iterations);
    strategy_a(iterations);
    strategy_b(iterations);
    strategy_c(iterations);
}
