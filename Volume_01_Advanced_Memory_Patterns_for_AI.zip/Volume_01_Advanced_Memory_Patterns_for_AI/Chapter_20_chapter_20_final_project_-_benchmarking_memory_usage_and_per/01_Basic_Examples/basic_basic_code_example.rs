
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

use std::cell::UnsafeCell;
use std::ptr;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::time::Instant;

/// Represents a tensor shape (dimensions) and data type.
/// In a real engine, this would be much more complex.
#[derive(Debug, Clone, Copy)]
struct TensorMeta {
    dims: [usize; 4], // Batch, Channel, Height, Width
    element_count: usize,
}

/// A handle to memory allocated within the Arena.
/// This acts like a smart pointer but without the overhead of heap allocation.
/// It uses a raw pointer and offset to locate data.
#[derive(Debug)]
struct ArenaHandle<'a> {
    ptr: *mut u8,
    len: usize,
    _marker: std::marker::PhantomData<&'a ()>,
}

impl<'a> ArenaHandle<'a> {
    /// Simulates writing data to the tensor memory.
    /// # Safety
    /// This is unsafe because we are writing to a raw pointer.
    /// The caller must ensure the pointer is valid and within bounds.
    unsafe fn write_data(&self, data: &[f32]) {
        assert_eq!(data.len() * 4, self.len); // Assuming f32 (4 bytes)
        let slice = std::slice::from_raw_parts_mut(self.ptr as *mut f32, data.len());
        slice.copy_from_slice(data);
    }

    /// Simulates reading data from the tensor memory.
    unsafe fn read_data(&self) -> Vec<f32> {
        let count = self.len / 4;
        let slice = std::slice::from_raw_parts(self.ptr as *const f32, count);
        slice.to_vec()
    }
}

/// A thread-safe Arena Allocator.
/// Pre-allocates a large chunk of memory and serves allocations by bumping a pointer.
/// Memory is freed all at once when the Arena is dropped or reset.
pub struct Arena {
    buffer: Vec<u8>,
    cursor: AtomicUsize,
}

impl Arena {
    /// Creates a new Arena with a fixed capacity (e.g., 1MB).
    pub fn new(capacity: usize) -> Self {
        let mut buffer = Vec::with_capacity(capacity);
        // Initialize the buffer with zeros to ensure it is backed by physical memory
        // (prevents page fault overhead during first access).
        unsafe {
            buffer.set_len(capacity);
            std::ptr::write_bytes(buffer.as_mut_ptr(), 0, capacity);
        }

        Self {
            buffer,
            cursor: AtomicUsize::new(0),
        }
    }

    /// Allocates a block of memory of `size` bytes.
    /// Returns `None` if the arena is full.
    /// This is a lock-free operation (assuming single-threaded access or atomic operations).
    pub fn allocate(&self, size: usize) -> Option<ArenaHandle> {
        let mut current = self.cursor.load(Ordering::Relaxed);
        let mut next;

        loop {
            // Check for overflow
            if current + size > self.buffer.len() {
                return None; // Out of memory
            }

            next = current + size;

            // Attempt to atomically update the cursor.
            // If another thread beat us to it, `current` will be updated and we retry.
            match self.cursor.compare_exchange_weak(
                current,
                next,
                Ordering::SeqCst, // Sequential consistency for safety
                Ordering::Relaxed,
            ) {
                Ok(_) => break,
                Err(actual) => current = actual,
            }
        }

        // Calculate the pointer address within our buffer
        let ptr = unsafe { self.buffer.as_mut_ptr().add(current) };

        Some(ArenaHandle {
            ptr,
            len: size,
            _marker: std::marker::PhantomData,
        })
    }

    /// Resets the arena cursor to 0.
    /// Effectively "frees" all memory.
    /// # Safety
    /// Calling this while there are active ArenaHandles is Undefined Behavior (UB).
    /// In a real engine, this is done at the end of a batch or request scope.
    pub unsafe fn reset(&self) {
        self.cursor.store(0, Ordering::SeqCst);
    }

    /// Returns the current usage percentage.
    fn usage_percent(&self) -> f32 {
        let used = self.cursor.load(Ordering::Relaxed);
        (used as f32 / self.buffer.len() as f32) * 100.0
    }
}

/// Simulates a neural network layer (e.g., a Linear layer).
/// It holds no memory itself; it asks the arena for workspace memory during execution.
struct Layer {
    name: String,
    weight_size: usize,
}

impl Layer {
    fn new(name: &str, weight_size: usize) -> Self {
        Self {
            name: name.to_string(),
            weight_size,
        }
    }

    /// Performs the forward pass.
    /// It allocates temporary memory for the output activation from the arena.
    /// This memory is reused every time this layer runs.
    fn forward<'a>(
        &self,
        arena: &'a Arena,
        input: &ArenaHandle<'a>,
    ) -> ArenaHandle<'a> {
        // Calculate output size (simplified)
        let output_size = input.len; 

        // Allocate output memory from the arena
        let output_handle = arena.allocate(output_size).expect("Arena full!");
        
        // Simulate computation (memory copy in this case)
        unsafe {
            // In a real scenario, this would be a SIMD-optimized kernel
            ptr::copy_nonoverlapping(input.ptr, output_handle.ptr, input.len);
        }

        println!("[{}] Forward pass allocated {} bytes", self.name, output_size);
        output_handle
    }
}

/// Simulates the inference server loop.
fn run_inference_benchmark() {
    println!("=== Arena Allocator Benchmark ===");
    
    // 1. Setup: Create an Arena (1MB capacity)
    let arena = Arena::new(1024 * 1024); 
    
    // 2. Define Model Architecture
    let layers = vec![
        Layer::new("Conv1", 50_000),
        Layer::new("Dense1", 100_000),
        Layer::new("Output", 10_000),
    ];

    // 3. Warm up (touch memory to avoid page faults in benchmark)
    let _ = arena.allocate(1024);
    unsafe { arena.reset(); }

    // 4. Benchmark Loop
    let start = Instant::now();
    let iterations = 10_000;

    for i in 0..iterations {
        // Scope: Allocations for one request happen here.
        // In a real async system, this might be a task scope.
        
        // Simulate Input Data (Allocate from Arena)
        let input_size = 224 * 224 * 3 * 4; // Standard image size
        let mut current_tensor = arena.allocate(input_size).expect("Arena full");

        // Simulate writing input data
        unsafe {
            // Just writing dummy data
            let slice = std::slice::from_raw_parts_mut(current_tensor.ptr as *mut f32, input_size / 4);
            for val in slice.iter_mut() { *val = 1.0; }
        }

        // Pass data through layers
        for layer in &layers {
            current_tensor = layer.forward(&arena, &current_tensor);
        }

        // At the end of the request, we "free" memory by resetting the arena.
        // This is O(1), unlike individual deallocations.
        unsafe {
            arena.reset();
        }

        if i % 1000 == 0 {
            println!("Request {} processed. Arena Usage: {:.2}%", i, arena.usage_percent());
        }
    }

    let duration = start.elapsed();
    println!("\nBenchmark Results:");
    println!("Total Requests: {}", iterations);
    println!("Total Time: {:?}", duration);
    println!("Throughput: {:.0} req/sec", iterations as f64 / duration.as_secs_f64());
}

fn main() {
    run_inference_benchmark();
}
