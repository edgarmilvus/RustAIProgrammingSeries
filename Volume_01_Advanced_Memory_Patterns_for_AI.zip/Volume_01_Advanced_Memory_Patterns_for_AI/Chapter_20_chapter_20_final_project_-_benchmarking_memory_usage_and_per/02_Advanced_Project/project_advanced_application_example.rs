
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

use rand::Rng;
use std::alloc::{GlobalAlloc, Layout, System};
use std::ptr;
use std::time::Instant;

/// --- 1. Custom Allocator: The Bump Arena ---
///
/// A simple bump allocator that allocates memory linearly from a pre-reserved chunk.
/// It does not support individual deallocation. The entire arena is reset at once.
struct BumpArena {
    buffer: *mut u8,
    capacity: usize,
    offset: usize,
}

impl BumpArena {
    /// Creates a new arena with a fixed capacity.
    fn new(capacity: usize) -> Self {
        // Allocate a raw memory block using the global allocator (System).
        let layout = Layout::from_size_align(capacity, 8).unwrap();
        let buffer = unsafe { System.alloc(layout) };
        
        Self {
            buffer,
            capacity,
            offset: 0,
        }
    }

    /// Resets the arena pointer to the beginning, effectively "freeing" everything.
    /// This is O(1) and extremely fast.
    fn reset(&mut self) {
        self.offset = 0;
    }

    /// Allocates a block of memory for a specific type.
    /// Returns a raw pointer.
    unsafe fn alloc<T>(&mut self) -> *mut T {
        let size = std::mem::size_of::<T>();
        let align = std::mem::align_of::<T>();
        
        // Simple alignment logic (in production, use strict alignment)
        let padding = (align - (self.offset % align)) % align;
        
        // Check for overflow
        if self.offset + padding + size > self.capacity {
            panic!("Arena out of memory");
        }

        let ptr = self.buffer.add(self.offset + padding) as *mut T;
        self.offset += padding + size;
        ptr
    }
}

impl Drop for BumpArena {
    fn drop(&mut self) {
        let layout = Layout::from_size_align(self.capacity, 8).unwrap();
        unsafe { System.dealloc(self.buffer, layout) };
    }
}

/// --- 2. Domain Model: AI Inference ---
///
/// Represents a tensor with shape and raw data. 
/// In a real scenario, this would hold heavy matrix data.
struct Tensor {
    data: *mut f32, // Raw pointer to data (owned by the arena)
    size: usize,
}

impl Tensor {
    /// Simulates processing by accessing memory.
    unsafe fn process(&self) -> f32 {
        // Sum elements to force memory access (simulate compute)
        let mut sum = 0.0;
        for i in 0..self.size {
            sum += *self.data.add(i);
        }
        sum
    }
}

/// --- 3. Simulation Logic ---

/// Simulates processing a request using the Standard Library (Vec).
/// This incurs multiple heap allocations and deallocations.
fn process_with_std(count: usize) -> f32 {
    let mut rng = rand::thread_rng();
    let mut tensors: Vec<Tensor> = Vec::with_capacity(count);
    
    // Allocation Phase: Individual heap allocations
    for _ in 0..count {
        let size = rng.gen_range(10..100);
        let mut data_vec: Vec<f32> = vec
![0.0; size]; // Heap allocation
        // Fill with dummy data
        for val in data_vec.iter_mut()
 {
            *val = rng.gen::<f32>();
        }
        
        // In a real app, we'd need to transfer ownership of the pointer carefully.
        // Here we simulate it by leaking or pinning, but strictly speaking, 
        // `Vec` manages the pointer. We will just use the Vec directly to be safe 
        // for the simulation, but the cost is the same: heap allocs.
        // To be fair to the benchmark, we will just sum the vecs directly.
    }

    // In the standard model, we keep the Vecs alive or drop them individually.
    // Let's simulate a "result" calculation.
    let mut sum = 0.0;
    // We re-create the logic to match the "process" step
    for _ in 0..count {
        let size = rng.gen_range(10..100);
        let data_vec: Vec<f32> = vec
![0.0; size];
        // Access memory
        for v in &data_vec { sum += *v; }
    }
    sum
}

/// Simulates processing using the Custom Arena Allocator.
/// Single allocation, linear access, instant drop.
fn process_with_arena(count: usize, arena: &mut BumpArena)
 -> f32 {
    let mut rng = rand::thread_rng();
    let mut sum = 0.0;

    // Allocation Phase: Bump pointer operations (extremely fast)
    for _ in 0..count {
        let size = rng.gen_range(10..100);
        
        // Allocate raw memory for f32s directly in the arena
        let ptr = unsafe { arena.alloc::<f32>() };
        
        // Initialize and process (Simulate model inference)
        for i in 0..size {
            unsafe {
                ptr.add(i).write(rng.gen::<f32>());
                sum += *ptr.add(i);
            }
        }
    }
    
    // No manual drop of individual tensors needed!
    // The caller will reset the arena.
    sum
}

/// --- 4. The Benchmark Orchestrator ---

fn main() {
    const NUM_REQUESTS: usize = 1000;
    const TENSORS_PER_REQUEST: usize = 50;
    const ARENA_CAPACITY: usize = 1024 * 1024; // 1MB per request

    println!("--- Inference Engine Memory Benchmark ---");
    println!("Simulating {} requests, {} tensors per request.", NUM_REQUESTS, TENSORS_PER_REQUEST);

    // 1. Benchmark Standard Library (Vec/Heap)
    let start = Instant::now();
    for _ in 0..NUM_REQUESTS {
        process_with_std(TENSORS_PER_REQUEST);
    }
    let std_duration = start.elapsed();
    println!("Standard Lib (Vec) Total: {:?}", std_duration);
    println!("Avg per request: {:?}", std_duration / NUM_REQUESTS as u32);

    // 2. Benchmark Custom Arena
    // We reuse a single arena instance to simulate a pool, 
    // or we could create one per request. 
    // Here we create one per request to show the cost of setup vs alloc.
    let start = Instant::now();
    for _ in 0..NUM_REQUESTS {
        let mut arena = BumpArena::new(ARENA_CAPACITY);
        process_with_arena(TENSORS_PER_REQUEST, &mut arena);
        // Implicit drop of arena frees everything at once
    }
    let arena_duration = start.elapsed();
    println!("\nCustom Arena Total: {:?}", arena_duration);
    println!("Avg per request: {:?}", arena_duration / NUM_REQUESTS as u32);

    // Analysis
    let speedup = std_duration.as_nanos() as f64 / arena_duration.as_nanos() as f64;
    println!("\nSpeedup Factor: {:.2}x", speedup);
    println!("Note: Speedup is most dramatic with larger allocations and complex object graphs.");
}
