
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

// Cargo.toml dependencies:
// tokio = { version = "1", features = ["full"] }

use std::pin::Pin;

struct PinnedBuffer {
    data: Vec<u8>,
    ptr: *const u8,
}

impl PinnedBuffer {
    pub fn new(data: Vec<u8>, offset: usize) -> Self {
        // Ensure offset is within bounds to avoid panics or invalid pointers.
        assert!(offset < data.len(), "Offset out of bounds");

        // Create the struct. We cannot set `ptr` to point to `data[offset]` yet
        // because `data` might move when the struct is returned.
        // We must defer the pointer assignment until after construction.
        let mut buffer = PinnedBuffer { data, ptr: std::ptr::null() };

        // SAFETY: We are borrowing `buffer.data` to get a raw pointer.
        // This pointer is valid as long as `buffer.data` is not modified or deallocated.
        // Since `buffer` owns the data, and we are about to pin it, this is safe.
        buffer.ptr = buffer.data.as_ptr().add(offset);

        buffer
    }

    // Helper to pin the struct. In real usage, you might use `Box::pin` or `pin_mut`.
    // This method simulates the act of pinning an existing value.
    pub fn pin_self(self) -> Pin<Box<Self>> {
        Box::pin(self)
    }

    pub fn get_value(&self) -> u8 {
        // SAFETY: The pointer is set in `new` to point within the valid allocation of `self.data`.
        // We rely on the caller ensuring the struct is pinned and `data` is not modified.
        unsafe { *self.ptr }
    }
}

// An async function that accepts a pinned mutable reference.
// Because the argument is `Pin<&mut PinnedBuffer>`, the compiler guarantees
// that the struct will not be moved while this function has access to it.
// This guarantees the raw pointer remains valid.
async fn process_stream(buffer: Pin<&mut PinnedBuffer>) {
    // We use `as_ref()` to get a shared reference to the pinned data,
    // or `get_mut` if we were sure we didn't move it (but we respect the Pin here).
    let value = buffer.get_value();
    println!("Processing value at pinned address: {}", value);
}

fn main() {
    let data = vec
![10, 20, 30, 40, 50];
    
    // 1. Create the buffer
    let buffer = PinnedBuffer::new(data, 2)
; // Points to 30
    
    // 2. Pin the buffer (usually to the heap for async)
    let pinned_buffer = buffer.pin_self();

    // 3. Pass the pinned reference to the async function
    tokio::runtime::Runtime::new().unwrap().block_on(async {
        process_stream(pinned_buffer).await;
    });
}
