
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.rs
// Description: Solution for Exercise 3
// ==========================================

// Cargo.toml dependencies:
// futures = "0.3"

use std::pin::Pin;
use std::future::Future;
use std::task::{Context, Poll};

struct PinBox<F: Future> {
    inner: Box<F>,
}

impl<F: Future> PinBox<F> {
    pub fn new(future: F) -> Self {
        PinBox {
            inner: Box::new(future),
        }
    }

    // Returns a pinned mutable reference to the inner future.
    // This is the projection: taking a Pin<&mut PinBox<F>> to a Pin<&mut F>.
    pub fn as_pin_mut(&mut self) -> Pin<&mut F> {
        // SAFETY: We are guaranteeing that the inner future will not be moved
        // as long as the PinBox exists and is pinned.
        unsafe { Pin::new_unchecked(&mut *self.inner) }
    }

    // Helper to poll the inner future.
    // Note: To poll correctly, the caller must provide a Pin<&mut Self>.
    pub fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<F::Output> {
        // Project PinBox<F> to Pin<&mut F>.
        // This is a standard pin projection for a struct containing a single field.
        let this = unsafe { self.get_unchecked_mut() };
        let inner_pin = unsafe { Pin::new_unchecked(&mut *this.inner) };
        
        inner_pin.poll(cx)
    }
}

// Implement Future for PinBox so it can be awaited directly.
impl<F: Future> Future for PinBox<F> {
    type Output = F::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        self.poll(cx)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::marker::PhantomPinned;
    use futures::task::noop_waker;

    // A future that is !Unpin to test PinBox
    struct UnpinFuture {
        _pin: PhantomPinned,
    }

    impl Future for UnpinFuture {
        type Output = i32;
        fn poll(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<Self::Output> {
            Poll::Ready(42)
        }
    }

    #[test]
    fn test_pin_box() {
        let future = UnpinFuture { _pin: PhantomPinned };
        let mut pin_box = PinBox::new(future);
        
        let waker = noop_waker();
        let mut context = Context::from_waker(&waker);
        
        // We must pin the PinBox itself to poll it.
        let pinned = Pin::new(&mut pin_box);
        
        match pinned.poll(&mut context) {
            Poll::Ready(val) => assert_eq!(val, 42),
            Poll::Pending => panic!("Expected ready"),
        }
    }
}
