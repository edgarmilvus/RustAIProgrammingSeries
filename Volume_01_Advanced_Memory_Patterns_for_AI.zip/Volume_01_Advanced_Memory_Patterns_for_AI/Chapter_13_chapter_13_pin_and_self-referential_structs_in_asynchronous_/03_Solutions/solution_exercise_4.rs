
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.rs
// Description: Solution for Exercise 4
// ==========================================

// Cargo.toml dependencies:
// tokio = { version = "1", features = ["full"] }

use std::marker::PhantomPinned;
use std::pin::Pin;
use std::ptr;

struct PinnedBuffer {
    data: Vec<u8>,
    ptr: *const u8,
    _pin: PhantomPinned, // Makes the struct !Unpin
}

// SAFETY: We implement Send for PinnedBuffer.
// Generally, raw pointers (*const u8) are !Send.
// However, in this specific context, the pointer points to memory owned by `self.data`.
// Since `self.data` (Vec) is Send, moving the struct to another thread is safe
// as long as the pointer remains valid relative to the data.
// We are essentially saying: "I guarantee this pointer is not shared mutable global state."
unsafe impl Send for PinnedBuffer {}

impl PinnedBuffer {
    pub fn new(data: Vec<u8>, offset: usize) -> Self {
        assert!(offset < data.len());
        let mut buffer = PinnedBuffer { data, ptr: std::ptr::null(), _pin: PhantomPinned };
        // SAFETY: We are constructing a self-referential pointer.
        // This is valid as long as the struct isn't moved before pinning (which we handle via PhantomPinned)
        // and the vector doesn't reallocate (which is guaranteed by Pin).
        buffer.ptr = buffer.data.as_ptr().add(offset);
        buffer
    }

    pub fn get_value(&self) -> u8 {
        unsafe { *self.ptr }
    }
}

async fn producer(tx: tokio::sync::mpsc::Sender<PinnedBuffer>) {
    for i in 0..5 {
        let data = vec
![10 + i, 20, 30];
        // Create buffer. Note: We cannot send !Unpin types directly into channels 
        // unless the channel implementation handles pinning or we Box::pin them.
        // Tokio's mpsc channel requires the sent item to be Unpin or wrapped in Pin.
        // However, since PinnedBuffer is !Unpin, we usually can't send it directly 
        // unless we Box it or the channel implementation pins it internally.
        // For this exercise, we will Box::pin it to make it movable across the channel boundary
        // (Box is Send/Sync if the inner type is), then cast back if needed, 
        // OR we rely on Tokio's channel implementation which typically moves the value.
        
        // Correction: Tokio's channels require the item to be `Send`. 
        // Since we marked PinnedBuffer as Send, we can send it.
        // However, moving it into the channel moves it in memory.
        // If we move it, the internal pointer might break if not handled carefully.
        
        // To strictly adhere to Pinning rules for self-referential structs:
        // We should Pin the buffer before sending it into a context where it might be moved.
        // But channels transfer ownership. 
        
        // Let's adjust: The challenge asks to send PinnedBuffer.
        // If we move PinnedBuffer, the pointer (relative to the Vec's heap address) remains valid
        // because the Vec moves with the struct. 
        // The pointer is a relative offset effectively (though stored as absolute).
        // Wait: `ptr` is an absolute address. If we move the struct, `ptr` becomes invalid 
        // unless we update it.
        
        // REVISED STRATEGY FOR EXERCISE 5:
        // Since `PinnedBuffer` is self-referential, moving it breaks the pointer.
        // Therefore, we cannot move it freely.
        // The solution is to Box::pin it immediately, and send the Box.
        // Or, we use a channel that accepts Pin<Box<dyn Future>>.
        
        // However, strictly following the prompt's request to send `PinnedBuffer`:
        // We must acknowledge that moving a self-referential struct is unsafe.
        // The prompt asks to "ensure the PinnedBuffer implements Send".
        // This is a trick question. A self-referential struct with a raw pointer is NOT safe to Send
        // if the pointer is absolute, unless the pointer is updated on move.
        
        // Let's stick to the standard Rust pattern for this:
        // We will send `Box<Pin<PinnedBuffer>>` or just `Pin<Box<PinnedBuffer>>`.
        
        let buffer = PinnedBuffer::new(data, 0);
        let pinned_buffer = Box::pin(buffer);
        
        // We need a channel that accepts Pin<Box<PinnedBuffer>>.
        // Or, we can send the Box, and the receiver pins it.
        
        // Let's modify the channel type in the signature to be generic or specific.
        // For the code below, I will send `Pin<Box<PinnedBuffer>>`.
        
        // Note: The channel in the function signature is specific to PinnedBuffer.
        // To make this work without changing the signature, we rely on the fact that 
        // `PinnedBuffer` (with PhantomPinned) is `!Unpin`, so we can't move it into the channel easily 
        // without pinning it first.
        
        // Let's assume the channel is `Sender<Pin<Box<PinnedBuffer>>>` for safety.
        // But the prompt asks for `Sender<PinnedBuffer>`.
        
        // If we must send `PinnedBuffer` (not Boxed), we have to accept that moving it 
        // breaks the pointer. The only way this works is if we reconstruct the pointer 
        // on the receiver side, which defeats the purpose of "zero-copy" stability.
        
        // ALTERNATIVE INTERPRETATION:
        // The pointer points to `data[offset]`. If we move the struct, `data` moves on the heap.
        // The pointer `ptr` becomes invalid.
        // Therefore, we CANNOT send `PinnedBuffer` directly unless we use `Box::pin`.
        
        // I will implement the solution using `Pin<Box<PinnedBuffer>>` inside the channel
        // to ensure memory safety, as sending a raw self-referential struct across threads is undefined behavior.
        
        // Let's adjust the channel type in the main function to `Sender<Pin<Box<PinnedBuffer>>>`.
        // This is the standard way to handle `!Unpin` types in async channels.
        
        let _ = tx.send(pinned_buffer).await;
        println!("Producer: sent buffer {}", i);
    }
}

async fn consumer(mut rx: tokio::sync::mpsc::Receiver<Pin<Box<PinnedBuffer>>>) {
    while let Some(buffer) = rx.recv().await {
        // buffer is Pin<Box<PinnedBuffer>>
        // We can access the value safely because it is pinned.
        println!("Consumer: received value {}", buffer.get_value());
    }
}

#[tokio::main]
async fn main() {
    // Adjusted channel type to handle Pin<Box<PinnedBuffer>> for safety.
    // Sending raw !Unpin structs across threads is generally unsafe.
    let (tx, rx) = tokio::sync::mpsc::channel::<Pin<Box<PinnedBuffer>>>(10);

    let producer_handle = tokio::spawn(producer(tx));
    let consumer_handle = tokio::spawn(consumer(rx));

    let _ = tokio::join!(producer_handle, consumer_handle);
}
