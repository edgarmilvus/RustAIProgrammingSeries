
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.rs
// Description: Solution for Exercise 2
// ==========================================

// Cargo.toml dependencies:
// futures = "0.3"

use std::future::Future;
use std::pin::Pin;
use std::task::{Context, Poll, Waker};
use std::marker::PhantomPinned;

struct InferenceFuture {
    data: Vec<u32>,
    current_index: usize,
    waker: Option<Waker>,
    // We add PhantomPinned to ensure the struct is !Unpin.
    // This forces us to use Pin<&mut Self> in poll, simulating a self-referential scenario.
    _pin: PhantomPinned, 
}

impl InferenceFuture {
    pub fn new(data: Vec<u32>) -> Self {
        InferenceFuture {
            data,
            current_index: 0,
            waker: None,
            _pin: PhantomPinned,
        }
    }
}

impl Future for InferenceFuture {
    type Output = u32; // Result is a simple checksum (sum of elements)

    // We take Pin<&mut Self> because the struct is !Unpin.
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        // Access fields without moving the struct.
        let this = self.get_mut();

        if this.current_index < this.data.len() {
            // Simulate work: processing one element.
            // In a real scenario, this might be a non-blocking check on a hardware status register.
            this.current_index += 1;

            // Register the waker to be notified when to poll again.
            // In this simple loop, we might just return Pending immediately to yield control.
            this.waker = Some(cx.waker().clone());
            
            // For the sake of the exercise, we return Pending to simulate async waiting.
            // In a real async loop, we might check a condition here.
            Poll::Pending
        } else {
            // Calculation complete.
            let sum: u32 = this.data.iter().sum();
            Poll::Ready(sum)
        }
    }
}

fn main() {
    let data = vec
![1, 2, 3, 4, 5];
    let mut future = InferenceFuture::new(data)
;

    // Pin the future to the stack (or heap using Box::pin).
    // Since InferenceFuture is !Unpin, we must pin it to poll it safely.
    let mut pinned_future = Pin::new(&mut future);

    // Create a basic context and waker (using futures crate utilities for simplicity).
    use futures::task::noop_waker;
    let waker = noop_waker();
    let mut context = Context::from_waker(&waker);

    // Poll manually to simulate the executor loop.
    loop {
        match pinned_future.as_mut().poll(&mut context) {
            Poll::Ready(result) => {
                println!("Inference complete! Result: {}", result);
                break;
            }
            Poll::Pending => {
                println!("Inference pending...");
                // In a real executor, we would yield control here.
                // For this demo, we just continue the loop (or break to avoid infinite loop if logic permits).
                // Since our logic always increments index, it will eventually finish.
            }
        }
    }
}
