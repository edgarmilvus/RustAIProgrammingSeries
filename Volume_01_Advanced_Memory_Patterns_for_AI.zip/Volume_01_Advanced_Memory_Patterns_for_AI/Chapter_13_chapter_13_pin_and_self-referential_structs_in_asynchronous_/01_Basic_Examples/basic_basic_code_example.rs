
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

// Cargo.toml dependencies:
// tokio = { version = "1", features = ["full"] }

use std::pin::Pin;
use std::task::{Context, Poll};
use tokio::pin;

/// Represents a large tensor of floating-point data.
/// In a real scenario, this might be a GPU buffer or a memory-mapped file.
/// For this example, it's a simple vector on the heap.
struct Tensor {
    data: Vec<f32>,
}

impl Tensor {
    fn new(data: Vec<f32>) -> Self {
        Tensor { data }
    }

    /// Returns a slice representing a specific window of the tensor.
    fn window(&self, start: usize, size: usize) -> &[f32] {
        &self.data[start..start + size]
    }
}

/// A self-referential struct representing the state of an inference step.
/// 
/// # Why Pinning is Necessary Here
/// This struct holds a reference (`current_window`) to data inside `tensor`.
/// If this struct were moved in memory, `current_window` would point to invalid memory.
/// `Pin` guarantees that the memory address of this struct remains stable.
struct PinnedInferenceState<'a> {
    tensor: Tensor,
    /// A reference to a slice within `tensor.data`.
    /// This makes the struct self-referential.
    current_window: Option<&'a [f32]>,
    step_index: usize,
}

impl<'a> PinnedInferenceState<'a> {
    /// Creates a new state pinned to the heap.
    /// 
    /// We immediately wrap the struct in `Pin<Box<...>>` to prevent moves.
    /// This is crucial because the struct contains a reference to itself.
    fn new(data: Vec<f32>) -> Pin<Box<Self>> {
        let mut state = Box::pin(PinnedInferenceState {
            tensor: Tensor::new(data),
            current_window: None,
            step_index: 0,
        });

        // SAFETY: We are initializing the self-referential field immediately after creation
        // and before any further moves (which are prevented by Pin).
        // We use a raw pointer cast to bypass the borrow checker for this initialization.
        let self_ptr: *const PinnedInferenceState = &*state;
        
        // We know the struct is pinned, so we can safely create a reference to its interior
        // that will remain valid as long as the Pin exists.
        unsafe {
            let tensor_ptr = &(*self_ptr).tensor;
            let slice = tensor_ptr.window(0, 2); // Initial window size: 2
            let mut_ref = Pin::as_mut(&mut state);
            Pin::get_unchecked_mut(mut_ref).current_window = Some(slice);
        }

        state
    }

    /// Advances the inference state to the next window.
    /// This simulates processing data sequentially without copying.
    fn advance(self: Pin<&mut Self>) {
        // We access the pinned mutable reference.
        // `unsafe` is required to access the inner fields because we are asserting
        // that the self-referential pointer remains valid.
        let this = unsafe { Pin::get_unchecked_mut(self) };
        
        let window_size = 2;
        let next_start = this.step_index + window_size;

        if next_start + window_size <= this.tensor.data.len() {
            this.step_index = next_start;
            // Update the self-referential pointer.
            // Because the struct is pinned, the address of `this.tensor` hasn't changed,
            // so updating the slice reference is safe.
            this.current_window = Some(this.tensor.window(next_start, window_size));
            println!("Advanced to step {}: {:?}", this.step_index, this.current_window);
        } else {
            println!("End of tensor reached.");
            this.current_window = None;
        }
    }

    /// Retrieves the current window data.
    fn get_current(&self) -> Option<&[f32]> {
        self.current_window
    }
}

/// Simulates an asynchronous inference loop.
/// In a real AI server, this would be an async function processing requests.
async fn run_inference_pipeline() {
    println!("--- Starting Inference Pipeline ---");
    
    // Simulate a large input tensor (e.g., a flattened image or audio chunk).
    let input_data: Vec<f32> = vec
![1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0];

    // Create the self-referential struct.
    // It is immediately pinned to the heap.
    let pinned_state = PinnedInferenceState::new(input_data)
;

    // `pin!` macro allows us to treat the pinned box as a pinned reference in the async context.
    // This is essential for awaiting futures that require pinned memory.
    pin!(pinned_state);

    // Loop through the tensor windows sequentially.
    loop {
        // Check if we have data to process.
        if let Some(window) = pinned_state.as_ref().get_current() {
            println!("Processing window: {:?}", window);
            
            // Simulate some async work (e.g., matrix multiplication).
            // tokio::task::yield_now().await;
            
            // Advance the state.
            // We need a mutable pinned reference to call `advance`.
            pinned_state.as_mut().advance();
        } else {
            break;
        }
    }
    
    println!("--- Pipeline Finished ---");
}

#[tokio::main]
async fn main() {
    run_inference_pipeline().await;
}
