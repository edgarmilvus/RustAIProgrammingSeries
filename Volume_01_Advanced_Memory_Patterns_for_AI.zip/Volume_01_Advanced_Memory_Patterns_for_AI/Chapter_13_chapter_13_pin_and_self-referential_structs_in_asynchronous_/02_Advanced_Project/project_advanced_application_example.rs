
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

use std::pin::Pin;
use std::ptr::NonNull;
use std::task::{Context, Poll};
use futures::Stream;
use pin_project::pin_project;

/// Represents a chunk of data to be processed by the AI model.
/// In a real scenario, this might be a tensor or a batch of tokens.
#[derive(Debug, Clone)]
struct DataChunk {
    id: usize,
    payload: Vec<f32>,
}

impl DataChunk {
    fn new(id: usize, size: usize) -> Self {
        Self {
            id,
            payload: vec
![1.0; size], // Simulate large data
        }
    }
}

/// # PinnedInferenceStream
/// 
/// This is a self-referential struct designed for high-performance inference.
/// It holds a large buffer of data and a cursor pointing into that buffer.
/// 
/// # Why Pinning is Necessary
/// If this struct were moved, the `cursor` pointer (which points to `buffer`)
/// would become invalid, leading to undefined behavior. `Pin<P>` ensures the 
/// memory address remains stable.
#[pin_project] // Automatically handles Pin projection for safe implementation
struct PinnedInferenceStream {
    /// The backing store for our data. This stays in one place.
    buffer: Vec<DataChunk>,
    
    /// A pointer to the current element in `buffer`.
    /// This makes the struct self-referential.
    cursor: NonNull<DataChunk>,
    
    /// Tracks if the stream has finished.
    done: bool,
}

impl PinnedInferenceStream {
    /// Creates a new pinned stream. 
    /// 
    /// In a real system, this data might be memory-mapped from disk 
    /// to avoid loading the entire dataset into RAM at once.
    fn new(data: Vec<DataChunk>) -> Pin<Box<Self>> {
        // We must create this on the heap immediately to ensure the address 
        // of `buffer` is stable before we create a pointer to it.
        let mut boxed = Box::new(Self {
            buffer: data,
            // Safety: We ensure the vector is not moved or modified in a way 
            // that would invalidate this pointer after initialization.
            cursor: NonNull::dangling(),
            done: false,
        });

        // Initialize the cursor to point to the first element of the buffer.
        if !boxed.buffer.is_empty() {
            // Safety: We know the buffer is valid and non-empty.
            // We use `as_mut_ptr` to get a raw pointer, then wrap it in NonNull.
            let ptr = boxed.buffer.as_mut_ptr();
            unsafe {
                boxed.cursor = NonNull::new_unchecked(ptr);
            }
        }

        // Pin the box. This prevents the struct from being moved in memory.
        Box::pin(boxed)
    }
}

/// Implementation of the `Stream` trait for our pinned struct.
/// This allows it to be used with `for_each`, `next`, etc., in async contexts.
impl Stream for PinnedInferenceStream {
    type Item = DataChunk;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        // We use `pin_project` to safely access fields without violating pinning guarantees.
        let this = self.project();

        if *this.done {
            return Poll::Ready(None);
        }

        // Calculate the index based on the cursor pointer relative to the buffer start.
        // This is a safe calculation because we know the cursor points into the buffer.
        let current_index = unsafe {
            this.cursor.as_ptr().offset_from(this.buffer.as_ptr()) as usize
        };

        if current_index >= this.buffer.len() {
            *this.done = true;
            return Poll::Ready(None);
        }

        // Simulate the "Inference" work.
        // In a real async system, we might yield here to allow other tasks to run,
        // or perform non-blocking I/O.
        let item = unsafe { this.cursor.as_ref() }.clone();
        
        // Advance the cursor to the next element.
        // This is the "self-referential" action: updating the internal pointer.
        unsafe {
            let next_ptr = this.cursor.as_ptr().add(1);
            *this.cursor = NonNull::new_unchecked(next_ptr);
        }

        // Return the data asynchronously.
        // Note: In a real heavy-compute scenario, we might return Poll::Pending 
        // here to simulate waiting for a GPU or model lock.
        Poll::Ready(Some(item))
    }
}

#[tokio::main]
async fn main() {
    // 1. Setup: Generate a large dataset (simulating a pre-loaded model or dataset).
    // Using a small number here for demonstration, but the logic scales to gigabytes.
    let dataset: Vec<DataChunk> = (0..5)
        .map(|i| DataChunk::new(i, 1024)) // 1024 floats per chunk
        .collect();

    println!("Initializing Pinned Inference Stream with {} chunks...", dataset.len());

    // 2. Pinning: Create the self-referential struct on the heap and pin it.
    let mut inference_stream = PinnedInferenceStream::new(dataset);

    // 3. Execution: Consume the stream asynchronously.
    // The `while let` loop polls the future, which internally uses the stable memory address.
    let mut processed_count = 0;
    while let Some(chunk) = inference_stream.next().await {
        // Simulate processing the inference result.
        // Because the data was pinned, we could have passed pointers to this data
        // to a C FFI or a GPU driver safely without fear of the data moving.
        println!(
            "Processed Inference ID: {}, Data Size: {} bytes",
            chunk.id,
            chunk.payload.len() * std::mem::size_of::<f32>()
        );
        processed_count += 1;
    }

    println!("Pipeline complete. Total chunks processed: {}", processed_count);
}
