
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.rs
// Description: Solution for Exercise 3
// ==========================================

use std::rc::Rc;
use std::cell::RefCell;
use std::io::{self, Write};
use rand::Rng;

#[derive(Debug)]
struct Node {
    id: usize,
    value: f32,
    // Using RefCell to allow mutation of children while wrapped in Rc
    children: RefCell<Vec<Rc<Node>>>,
}

impl Node {
    fn new(id: usize, value: f32) -> Rc<Self> {
        Rc::new(Node {
            id,
            value,
            children: RefCell::new(Vec::new()),
        })
    }
}

// 2. Implement add_child function
fn add_child(parent: &Rc<Node>, id: usize, value: f32) -> Rc<Node> {
    let child = Node::new(id, value);
    // We borrow the children vector mutably to push the new child
    parent.children.borrow_mut().push(Rc::clone(&child));
    child
}

// Helper to print graph structure
fn print_graph(node: &Rc<Node>, indent: usize) {
    let prefix = "  ".repeat(indent);
    println!("{}Node ID: {}, Value: {:.1}", prefix, node.id, node.value);
    for child in node.children.borrow().iter() {
        print_graph(child, indent + 1);
    }
}

fn main() {
    // 3. Start with root node
    let root = Node::new(0, 1.0);
    let mut nodes = vec
![Rc::clone(&root)
]; // Keep a list of active nodes for ID lookup
    let mut next_id = 1;

    println!("Interactive Graph Pruning Tool");
    println!("Commands: 'add <parent_id>' or 'prune <node_id>'");

    loop {
        println!("\n--- Current Graph State ---");
        print_graph(&root, 0);
        
        print!("\n> ");
        io::stdout().flush().unwrap();

        let mut input = String::new();
        io::stdin().read_line(&mut input).unwrap();
        let input = input.trim();

        if input.starts_with("add") {
            let parts: Vec<&str> = input.split_whitespace().collect();
            if parts.len() != 2 {
                println!("Usage: add <parent_id>");
                continue;
            }
            let parent_id = parts[1].parse::<usize>();
            
            if let Ok(pid) = parent_id {
                // Find parent in our list of active nodes
                if let Some(parent) = nodes.iter().find(|n| n.id == pid) {
                    let new_node = add_child(parent, next_id, rand::thread_rng().gen_range(0.0..10.0));
                    nodes.push(Rc::clone(&new_node));
                    next_id += 1;
                    println!("Added child {} to parent {}", new_node.id, pid);
                } else {
                    println!("Parent ID {} not found.", pid);
                }
            } else {
                println!("Invalid ID format.");
            }

        } else if input.starts_with("prune") {
            let parts: Vec<&str> = input.split_whitespace().collect();
            if parts.len() != 2 {
                println!("Usage: prune <node_id>");
                continue;
            }
            let target_id = parts[1].parse::<usize>();
            
            if let Ok(tid) = target_id {
                if tid == 0 {
                    println!("Cannot prune root node.");
                    continue;
                }

                // We need to find the *parent* of the node to be pruned.
                // This is a simplified search. In a real graph, we'd maintain parent pointers.
                let mut parent_opt = None;
                for node in nodes.iter() {
                    let children = node.children.borrow();
                    if children.iter().any(|c| c.id == tid) {
                        parent_opt = Some(Rc::clone(node));
                        break;
                    }
                }

                if let Some(parent) = parent_opt {
                    // Remove the child from the parent's children vector
                    parent.children.borrow_mut().retain(|c| c.id != tid);
                    
                    // Remove from our tracking list
                    nodes.retain(|n| n.id != tid);
                    
                    println!("Pruned node {}", tid);
                    
                    // 4. Safety & Under the Hood Explanation:
                    // When the child is removed from the parent's `children` vector, 
                    // the `Rc` count for that child decreases.
                    // If that child was the only owner (besides the list we are cleaning up),
                    // the node is dropped. If the node being dropped owned other `Rc`s 
                    // (its children), those counts decrease too, potentially cascading 
                    // the drop recursively.
                } else {
                    println!("Node {} not found or is root.", tid);
                }
            } else {
                println!("Invalid ID format.");
            }
        } else {
            println!("Unknown command.");
        }
    }
}
