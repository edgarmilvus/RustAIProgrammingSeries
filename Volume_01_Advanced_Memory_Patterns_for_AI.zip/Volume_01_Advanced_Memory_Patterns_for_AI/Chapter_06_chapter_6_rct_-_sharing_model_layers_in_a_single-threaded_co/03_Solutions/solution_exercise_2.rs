
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.rs
// Description: Solution for Exercise 2
// ==========================================

use std::rc::Rc;

// Reusing the Tensor struct from Exercise 1
#[derive(Debug)]
struct Tensor {
    data: Vec<f32>,
}

impl Tensor {
    fn new(data: Vec<f32>) -> Self {
        Tensor { data }
    }
}

// 1. Define Layer struct
#[derive(Debug)]
struct Layer {
    name: String,
    output: Rc<Tensor>,
}

// 2. Define ComputationGraph struct
struct ComputationGraph {
    layers: Vec<Rc<Layer>>,
}

impl ComputationGraph {
    // 3. Implement build_simple_graph
    fn build_simple_graph() -> Self {
        // Create a root tensor (Input)
        let input_tensor = Rc::new(Tensor::new(vec
![1.0, 1.0])
);

        // Create Layer A (Dense)
        // In a real scenario, this would process input_tensor.
        // Here we simulate an output transformation.
        let layer_a_output = Rc::new(Tensor::new(vec
![2.0, 2.0])
);
        
        let layer_a = Rc::new(Layer {
            name: "Dense Layer A".to_string(),
            output: layer_a_output, // Layer A owns its output
        });

        // Create Layer B (Activation)
        // Layer B takes Layer A's output as input.
        // We simulate this by creating a new output tensor.
        let layer_b_output = Rc::new(Tensor::new(vec
![4.0, 4.0])
);

        let layer_b = Rc::new(Layer {
            name: "Activation Layer B".to_string(),
            output: layer_b_output,
        });

        // Store both layers in the graph vector.
        // The graph owns the layers via Rc.
        // Note: In a real graph, layer_b would hold an Rc to layer_a's output,
        // but structurally, the ComputationGraph owns the Layer structs.
        ComputationGraph {
            layers: vec
![layer_a, layer_b],
        }
    }

    // Helper to print the chain
    fn print_chain(&self)
 {
        println!("--- Computation Graph Flow ---");
        for layer in &self.layers {
            println!(
                "Layer: '{}' | Output Tensor Data: {:?}",
                layer.name, layer.output.data
            );
        }
    }
}

fn main() {
    let graph = ComputationGraph::build_simple_graph();
    graph.print_chain();
}
