
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.rs
// Description: Solution for Exercise 4
// ==========================================

use std::rc::Rc;
use std::collections::HashMap;

// --- Public API Definitions ---

/// A unique identifier for a node in the graph.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct NodeId(usize);

/// Error types for graph operations.
#[derive(Debug)]
pub enum GraphError {
    NodeNotFound(NodeId),
    CycleDetected,
}

/// The main builder struct for the computation graph.
pub struct RcGraph {
    // Internal state to track nodes and their relationships.
    nodes: HashMap<NodeId, Rc<Node>>,
    next_id: usize,
    // Adjacency list to track connections for cycle detection.
    edges: HashMap<NodeId, Vec<NodeId>>,
}

/// Represents a node in the computation graph.
/// This is internal or pub(crate) depending on visibility needs.
struct Node {
    id: NodeId,
    data: f32, // Simplified tensor representation
    children: Vec<Rc<Node>>,
}

impl RcGraph {
    /// Creates a new, empty graph.
    pub fn new() -> Self {
        RcGraph {
            nodes: HashMap::new(),
            next_id: 0,
            edges: HashMap::new(),
        }
    }

    /// Adds a node with the given data to the graph.
    /// Returns a `NodeId` handle for future reference.
    pub fn add_node(&mut self, data: f32) -> NodeId {
        let id = NodeId(self.next_id);
        self.next_id += 1;
        
        let node = Rc::new(Node {
            id,
            data,
            children: Vec::new(),
        });
        
        self.nodes.insert(id, node);
        self.edges.insert(id, Vec::new());
        
        id
    }

    /// Connects a parent node to a child node.
    /// This clones the `Rc` of the child and adds it to the parent's children vector.
    pub fn connect(&mut self, parent_id: NodeId, child_id: NodeId) -> Result<(), GraphError> {
        // 1. Validate existence
        if !self.nodes.contains_key(&parent_id) || !self.nodes.contains_key(&child_id) {
            return Err(GraphError::NodeNotFound(parent_id)); // Simplified error
        }

        // 2. Cycle Detection (Conceptual)
        // Before connecting, we must ensure this doesn't create a cycle.
        // We can perform a Depth First Search (DFS) starting from `child_id`.
        // If we encounter `parent_id` during the traversal, it's a cycle.
        if self.detect_cycle(child_id, parent_id) {
            return Err(GraphError::CycleDetected);
        }

        // 3. Perform the connection
        // We need to get a mutable reference to the parent node.
        // Since Rc<Node> is immutable, we would typically use RefCell internally
        // or reconstruct the node. For this builder pattern, we can temporarily 
        // remove the node, update it, and re-insert, or use interior mutability.
        // Assuming we use RefCell for Node.children (as in Ex 3):
        
        // To modify the graph structure, we need interior mutability or 
        // a specific graph update strategy. 
        // Let's assume `Node` uses `RefCell<Vec<Rc<Node>>>` for children.
        
        if let Some(parent_node) = self.nodes.get(&parent_id) {
            if let Some(child_node) = self.nodes.get(&child_id) {
                // Clone the Rc to the child and push to parent's children
                parent_node.children.borrow_mut().push(Rc::clone(child_node));
                
                // Update internal edge tracking for future cycle checks
                self.edges.get_mut(&parent_id).unwrap().push(child_id);
            }
        }

        Ok(())
    }

    /// Helper to detect cycles before connecting.
    fn detect_cycle(&self, start_node: NodeId, target_node: NodeId) -> bool {
        // DFS implementation to check if `target_node` is reachable from `start_node`
        // If it is, connecting `target_node` -> `start_node` (which is what we are doing)
        // would create a cycle.
        let mut stack = vec
![start_node];
        let mut visited = std::collections::HashSet::new();

        while let Some(current) = stack.pop()
 {
            if current == target_node {
                return true;
            }
            if !visited.insert(current) {
                continue;
            }
            if let Some(children) = self.edges.get(&current) {
                for &child in children {
                    stack.push(child);
                }
            }
        }
        false
    }
}
