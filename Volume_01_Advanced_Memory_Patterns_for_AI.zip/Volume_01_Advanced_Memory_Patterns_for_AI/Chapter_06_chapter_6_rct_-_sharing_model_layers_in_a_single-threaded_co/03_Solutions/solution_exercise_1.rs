
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

use std::rc::Rc;

// 1. Define a struct Tensor that holds a Vec<f32>.
#[derive(Debug)]
struct Tensor {
    data: Vec<f32>,
}

impl Tensor {
    fn new(data: Vec<f32>) -> Self {
        Tensor { data }
    }
}

// 2. Define EmbeddingLayer holding an Rc<Tensor>.
struct EmbeddingLayer {
    weights: Rc<Tensor>,
}

// 3. Define TransformerBlock holding an Rc<Tensor>.
struct TransformerBlock {
    input: Rc<Tensor>,
}

// 4. Define ClassificationHead holding an Rc<Tensor>.
struct ClassificationHead {
    input: Rc<Tensor>,
}

fn main() {
    // 5. Instantiate a Tensor with random values (simulated).
    let tensor_data = vec
![1.0, 2.0, 3.0, 4.0];
    let tensor = Tensor::new(tensor_data)
;

    // Wrap it in an Rc.
    let shared_tensor = Rc::new(tensor);

    // Create the EmbeddingLayer.
    let embedding_layer = EmbeddingLayer {
        weights: Rc::clone(&shared_tensor),
    };

    // Create downstream components with clones of the same Rc.
    let transformer_block = TransformerBlock {
        input: Rc::clone(&shared_tensor),
    };

    let classification_head = ClassificationHead {
        input: Rc::clone(&shared_tensor),
    };

    // Verify that all components point to the same underlying data.
    println!("--- Memory Address Verification ---");
    println!(
        "EmbeddingLayer weights ptr: {:?}",
        Rc::as_ptr(&embedding_layer.weights)
    );
    println!(
        "TransformerBlock input ptr: {:?}",
        Rc::as_ptr(&transformer_block.input)
    );
    println!(
        "ClassificationHead input ptr: {:?}",
        Rc::as_ptr(&classification_head.input)
    );
    
    // Verify data integrity
    println!("\n--- Data Integrity Check ---");
    println!("Shared data: {:?}", shared_tensor.data);
}
