
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

use ndarray::Array2;
use std::cell::RefCell;
use std::rc::Rc;

/// Represents a tensor of floating-point values.
/// In a real system, this would wrap GPU memory or a more complex buffer.
/// Here, we use `ndarray::Array2` for demonstration.
#[derive(Debug, Clone)]
struct Tensor {
    data: Array2<f32>,
}

impl Tensor {
    /// Creates a new tensor filled with zeros.
    fn zeros(rows: usize, cols: usize) -> Self {
        Tensor {
            data: Array2::zeros((rows, cols)),
        }
    }

    /// Simulates an expensive preprocessing operation (e.g., normalization).
    fn normalize(&mut self) {
        self.data.mapv_inplace(|x| x / 255.0);
    }
}

/// A computation layer in our graph.
/// It holds references to input tensors and produces an output tensor.
/// We use `Rc<RefCell<Tensor>>` for inputs to allow mutable access during computation
/// if needed, while maintaining shared ownership.
#[derive(Clone)]
struct Layer {
    name: String,
    /// The input tensors. In a real graph, this might be a vector of inputs.
    inputs: Vec<Rc<RefCell<Tensor>>>,
    /// The output tensor. Wrapped in Rc to be shared with downstream layers.
    output: Option<Rc<RefCell<Tensor>>>,
}

impl Layer {
    /// Creates a new layer without inputs yet.
    fn new(name: &str) -> Rc<RefCell<Self>> {
        Rc::new(RefCell::new(Layer {
            name: name.to_string(),
            inputs: Vec::new(),
            output: None,
        }))
    }

    /// Adds an input to the layer. This modifies the graph structure.
    /// This requires interior mutability via `RefCell`.
    fn add_input(layer: &Rc<RefCell<Self>>, input: Rc<RefCell<Tensor>>) {
        layer.borrow_mut().inputs.push(input);
    }

    /// Executes the layer's logic.
    /// In this simplified example, we simulate a computation by summing
    /// all input tensors (broadcasted) or just passing the first input through.
    fn compute(layer: Rc<RefCell<Self>>) {
        let mut layer_mut = layer.borrow_mut();
        
        // In a real scenario, we would perform matrix multiplication here.
        // For this example, we simulate processing the first input.
        if let Some(first_input) = layer_mut.inputs.first() {
            // We clone the Rc to get a new owner, but the underlying data is shared.
            let input_data = first_input.borrow().data.clone();
            
            // Simulate a computation (e.g., a dense layer).
            let output_data = input_data.mapv(|x| x.sin() + x.cos());
            
            let output_tensor = Tensor { data: output_data };
            
            // Store the result. If an output already exists, we overwrite it (stateful layer).
            // We wrap it in Rc<RefCell<>> to allow downstream layers to share it.
            if let Some(out) = &layer_mut.output {
                out.borrow_mut().data = output_tensor.data;
            } else {
                layer_mut.output = Some(Rc::new(RefCell::new(output_tensor)));
            }
            
            println!("[{}] Computed output shape: {:?}", layer_mut.name, layer_mut.output.as_ref().unwrap().borrow().data.shape());
        } else {
            println!("[{}] No inputs connected.", layer_mut.name);
        }
    }

    /// Retrieves the output tensor for connecting to other layers.
    fn get_output(&self) -> Option<Rc<RefCell<Tensor>>> {
        self.output.as_ref().cloned()
    }
}

/// The main Inference Engine managing the graph.
struct InferenceEngine {
    layers: Vec<Rc<RefCell<Layer>>>,
}

impl InferenceEngine {
    fn new() -> Self {
        InferenceEngine { layers: Vec::new() }
    }

    /// Adds a layer to the engine.
    fn add_layer(&mut self, layer: Rc<RefCell<Layer>>) {
        self.layers.push(layer);
    }

    /// Executes the graph in topological order (simplified here as insertion order).
    fn run(&self) {
        println!("--- Starting Inference Run ---");
        for layer in &self.layers {
            // We clone the Rc to pass ownership to the compute function.
            Layer::compute(layer.clone());
        }
        println!("--- Inference Complete ---\n");
    }
}

fn main() {
    // 1. Initialize the Engine
    let mut engine = InferenceEngine::new();

    // 2. Create Shared Data (The Input)
    // We create a raw input tensor and wrap it in Rc<RefCell> to simulate
    // a data buffer coming from a network request or disk.
    let raw_input = Rc::new(RefCell::new(Tensor::zeros(10, 10)));
    println!("Created Input Tensor: Shared ownership count = {}", Rc::strong_count(&raw_input));

    // 3. Build the Graph using Dynamic Construction
    // Layer A: Preprocessing (Directly modifies the input tensor)
    let preproc_layer = Layer::new("Preprocessing");
    Layer::add_input(&preproc_layer, raw_input.clone());
    
    // Layer B: Feature Extractor (Also shares the raw input, demonstrating sharing)
    let feature_layer = Layer::new("FeatureExtractor");
    Layer::add_input(&feature_layer, raw_input.clone());

    // Layer C: Model A (Depends on Preprocessing)
    let model_a = Layer::new("ModelA");
    
    // Layer D: Model B (Depends on FeatureExtractor)
    let model_b = Layer::new("ModelB");

    // 4. Connect the Graph
    // We need to link the outputs of previous layers to the inputs of subsequent ones.
    // Note: We must compute the previous layer first to generate an output.
    
    // Compute Preprocessing (modifies raw_input in place conceptually, though here we simulate it)
    // In this specific code structure, we simulate the flow by computing layers in order
    // and passing the result down.
    
    // Add layers to engine
    engine.add_layer(preproc_layer.clone());
    engine.add_layer(feature_layer.clone());
    engine.add_layer(model_a.clone());
    engine.add_layer(model_b.clone());

    // Simulate the flow: 
    // In a real DAG, we would traverse edges. Here, we manually wire dependencies
    // after the "upstream" layer computes.
    
    // Run Preprocessing
    Layer::compute(preproc_layer.clone());
    let preproc_output = preproc_layer.borrow().get_output().unwrap();
    
    // Connect Preprocessing output to Model A
    Layer::add_input(&model_a, preproc_output);
    
    // Run Feature Extractor
    Layer::compute(feature_layer.clone());
    let feature_output = feature_layer.borrow().get_output().unwrap();

    // Connect Feature Extractor output to Model B
    Layer::add_input(&model_b, feature_output);

    // 5. Final Execution
    // Now we run the full graph. Note that `ModelA` and `ModelB` are now fully connected.
    engine.run();

    // 6. Demonstrate Memory Management
    // Check reference counts to prove shared ownership.
    // The raw_input is shared by Preprocessing, FeatureExtractor, and potentially 
    // held by the main function.
    println!("Final ownership check on Raw Input: {}", Rc::strong_count(&raw_input));
    
    // Drop the main reference
    drop(raw_input);
    println!("Main reference dropped.");
    
    // The layers still hold references, so the data is not deallocated yet.
    // When `engine` goes out of scope, all layers are dropped, and subsequently
    // the tensors are dropped if no other Rc pointers exist.
}
