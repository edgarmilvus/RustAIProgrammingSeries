
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

// Cargo.toml dependencies (if running locally):
// [dependencies]
// No external crates needed for this example.

use std::rc::Rc;

/// Represents a tensor in our computation graph.
/// In a real scenario, this would hold large numerical data (e.g., Vec<f32>).
/// For this example, we use a simple wrapper around an integer to simulate data.
#[derive(Debug, Clone)]
struct Tensor {
    id: usize,
    data: Vec<f32>,
}

impl Tensor {
    /// Creates a new tensor with mock data.
    fn new(id: usize) -> Self {
        Tensor {
            id,
            data: vec
![1.0; 10], // Simulating a tensor of size 10
        }
    }

    /// Simulates a forward pass operation (e.g., a linear layer)
.
    fn forward(&self, input: &Tensor) -> Tensor {
        println!("Processing Tensor {} -> Tensor {}", input.id, self.id);
        // In reality, this would perform matrix multiplication.
        // Here we just clone the input data to simulate a new output tensor.
        Tensor::new(self.id)
    }
}

/// A node in the computation graph.
/// It holds a reference-counted pointer to a Tensor.
/// This allows multiple nodes to share the same underlying data.
#[derive(Debug)]
struct Layer {
    name: String,
    tensor: Rc<Tensor>,
}

impl Layer {
    /// Creates a new layer wrapping a shared tensor.
    fn new(name: &str, tensor: Rc<Tensor>) -> Self {
        Layer {
            name: name.to_string(),
            tensor,
        }
    }

    /// Processes the shared tensor and returns a new owned Tensor.
    /// Note: It takes a reference to the Rc, not ownership.
    fn compute(&self) -> Tensor {
        println!("Layer '{}' accessing shared tensor ID: {}", self.name, self.tensor.id);
        // Perform computation using the shared tensor.
        // We clone the inner data here to simulate producing a new output.
        // In a real graph, this output might be wrapped in a new Rc.
        Tensor::new(self.tensor.id + 1)
    }
}

/// The main inference function.
/// It constructs a graph where multiple layers share the same input tensor.
fn run_inference_pipeline() {
    println!("--- Starting Inference Pipeline ---");

    // 1. Create the input tensor.
    // This is the large data we want to share.
    let input_tensor = Tensor::new(100);
    println!("Created input tensor with ID: {}", input_tensor.id);

    // 2. Wrap the input tensor in an Rc.
    // This transfers ownership to the smart pointer, allowing shared access.
    let shared_input = Rc::new(input_tensor);
    println!("Input tensor wrapped in Rc. Strong count: {}", Rc::strong_count(&shared_input));

    // 3. Create multiple branches of the computation graph.
    // Each layer needs access to the input tensor. We clone the Rc pointer,
    // not the underlying data. This is cheap (increments a counter).
    
    // Branch A: A convolutional-like layer
    let layer_a = Layer::new("ConvLayer_A", Rc::clone(&shared_input));
    
    // Branch B: A pooling layer
    let layer_b = Layer::new("PoolLayer_B", Rc::clone(&shared_input));
    
    // Branch C: Another parallel branch
    let layer_c = Layer::new("AttentionLayer_C", Rc::clone(&shared_input));

    println!("Created 3 layers sharing the input. Strong count: {}", Rc::strong_count(&shared_input));

    // 4. Execute computations.
    // Even though layers are dropped after use, the shared_input remains valid
    // because we still hold the original `shared_input` Rc in this scope.
    
    let output_a = layer_a.compute();
    let output_b = layer_b.compute();
    let output_c = layer_c.compute();

    println!("Computed outputs: A:{}, B:{}, C:{}", output_a.id, output_b.id, output_c.id);

    // 5. Demonstrate dropping behavior.
    // Drop layer_a. The shared_input count decreases, but data is NOT freed
    // because `shared_input` (the original Rc) still exists.
    drop(layer_a);
    println!("Dropped Layer A. Strong count: {}", Rc::strong_count(&shared_input));

    // 6. Drop the original Rc.
    // Now the count drops to 0 (assuming layers B and C are out of scope or dropped).
    // The memory for the input tensor is deallocated here.
    drop(shared_input);
    println!("Dropped shared input. Memory freed.");
    
    println!("--- Pipeline Finished ---");
}

fn main() {
    run_inference_pipeline();
}
