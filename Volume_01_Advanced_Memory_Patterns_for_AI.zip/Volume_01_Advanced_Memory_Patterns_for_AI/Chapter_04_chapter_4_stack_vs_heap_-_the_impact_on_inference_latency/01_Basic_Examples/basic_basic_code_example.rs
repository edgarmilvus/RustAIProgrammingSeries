
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

// Cargo.toml dependencies:
// [dependencies]
// rand = "0.8"

use std::time::Instant;
use rand::Rng;

/// Represents a fixed-size tensor for the inference layer.
/// We use a stack-allocated array to demonstrate high-speed memory access.
/// In a real scenario, this might be a `ndarray::Array2<f32>`, but for this
/// example, a raw array highlights the stack vs heap distinction clearly.
const HIDDEN_SIZE: usize = 128;

/// A struct simulating a dense layer in a neural network.
/// It holds weights on the heap (simulating a large model) but processes data
/// using stack-allocated buffers where possible.
struct InferenceLayer {
    // Weights are typically large and stored on the heap.
    // Using a Vec allows dynamic sizing, but we will use Arc to share them
    // to avoid cloning during inference steps.
    weights: Vec<f32>,
    bias: Vec<f32>,
}

impl InferenceLayer {
    /// Creates a new layer with random weights.
    fn new(input_size: usize, output_size: usize) -> Self {
        let mut rng = rand::thread_rng();
        // Heap allocation happens here for the weights.
        let weights = (0..input_size * output_size)
            .map(|_| rng.gen_range(-1.0..1.0))
            .collect();
        let bias = (0..output_size).map(|_| rng.gen_range(-1.0..1.0)).collect();
        
        InferenceLayer { weights, bias }
    }

    /// Performs inference using a stack-allocated input buffer.
    /// This minimizes heap allocation during the critical inference path.
    /// 
    /// # Arguments
    /// * `input` - A reference to an array of fixed size (stack-allocated).
    /// 
    /// # Returns
    /// * A `Vec<f32>` representing the output (heap-allocated, as size varies).
    fn forward(&self, input: &[f32; HIDDEN_SIZE]) -> Vec<f32> {
        let output_size = self.bias.len();
        let input_size = input.len();
        
        // Pre-allocate the output vector on the heap.
        // In a high-performance loop, reusing this buffer is crucial to avoid
        // allocation overhead.
        let mut output = vec
![0.0; output_size];

        // Matrix multiplication simulation (simplified).
        // Accessing `self.weights` (heap)
 and `input` (stack).
        for i in 0..output_size {
            let mut sum = self.bias[i];
            for j in 0..input_size {
                // Linear indexing into the flat weights vector.
                let weight_index = i * input_size + j;
                sum += input[j] * self.weights[weight_index];
            }
            // Activation function (ReLU) simulation.
            output[i] = if sum > 0.0 { sum } else { 0.0 };
        }
        
        output
    }
}

/// Simulates the naive inference pipeline where data is constantly cloned.
/// This is common in beginner Rust code but introduces latency.
fn naive_pipeline(layer: &InferenceLayer, inputs: Vec<[f32; HIDDEN_SIZE]>) -> Vec<Vec<f32>> {
    let mut results = Vec::new();
    for input in inputs {
        // Cloning happens implicitly or explicitly here if we aren't careful.
        // The `forward` method takes a slice, but if we had to modify the input
        // or if the input was owned, we might clone.
        let output = layer.forward(&input);
        results.push(output);
    }
    results
}

/// Optimized pipeline using smart pointers and buffer reuse.
/// We use `Arc` to share the layer weights without deep copying.
/// We reuse the output buffer to minimize heap allocations.
fn optimized_pipeline(layer: std::sync::Arc<InferenceLayer>, inputs: Vec<[f32; HIDDEN_SIZE]>) -> Vec<Vec<f32>> {
    let mut results = Vec::with_capacity(inputs.len());
    
    // Pre-allocate a reusable buffer for the output.
    // This is a "scratchpad" on the heap, allocated once.
    let output_size = layer.bias.len();
    let mut reusable_buffer = vec
![0.0; output_size];

    for input in inputs {
        // Reset buffer
        for item in reusable_buffer.iter_mut()
 {
            *item = 0.0;
        }

        // Perform forward pass, writing directly into the reusable buffer.
        // We simulate the logic here to avoid borrowing issues with the struct method.
        let input_size = input.len();
        for i in 0..output_size {
            let mut sum = layer.bias[i];
            for j in 0..input_size {
                let weight_index = i * input_size + j;
                sum += input[j] * layer.weights[weight_index];
            }
            reusable_buffer[i] = if sum > 0.0 { sum } else { 0.0 };
        }

        // Clone the buffer to store the result.
        // In a real zero-copy architecture, we might swap buffers or use a ring buffer.
        results.push(reusable_buffer.clone());
    }
    results
}

fn main() {
    // 1. SETUP: Create the layer and dummy data.
    // The layer weights are allocated on the heap.
    let layer = InferenceLayer::new(HIDDEN_SIZE, 64);
    // Wrap in Arc for shared ownership (cheap to clone, refers to same heap data).
    let layer_arc = std::sync::Arc::new(layer);
    
    // Generate a batch of inputs (simulating a data loader).
    // This is a vector of stack-allocated arrays.
    let batch_size = 1000;
    let mut rng = rand::thread_rng();
    let inputs: Vec<[f32; HIDDEN_SIZE]> = (0..batch_size)
        .map(|_| {
            let mut arr = [0.0f32; HIDDEN_SIZE];
            for i in 0..HIDDEN_SIZE {
                arr[i] = rng.gen();
            }
            arr
        })
        .collect();

    println!("--- Inference Latency Comparison ---");
    println!("Batch Size: {}, Hidden Size: {}", batch_size, HIDDEN_SIZE);

    // 2. RUN NAIVE PIPELINE
    // We clone the Arc to get a reference for this run.
    let start_naive = Instant::now();
    // Note: We must dereference the Arc to pass the reference to the function.
    let _results_naive = naive_pipeline(&*layer_arc, inputs.clone());
    let duration_naive = start_naive.elapsed();
    println!("Naive Pipeline Duration: {:?}", duration_naive);

    // 3. RUN OPTIMIZED PIPELINE
    let start_opt = Instant::now();
    let _results_opt = optimized_pipeline(layer_arc.clone(), inputs);
    let duration_opt = start_opt.elapsed();
    println!("Optimized Pipeline Duration: {:?}", duration_opt);

    // 4. ANALYSIS
    let improvement = duration_naive.as_nanos() as f64 / duration_opt.as_nanos() as f64;
    println!("Optimized speedup factor: {:.2}x", improvement);
    println!("Note: The optimized version minimizes heap allocations during the loop.");
}
