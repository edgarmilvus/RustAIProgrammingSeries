
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

use rand::Rng;
use std::alloc::{alloc_zeroed, dealloc, Layout};
use std::time::Instant;

/// Represents a Tensor with a specific shape (rows, cols) and data.
/// In a real engine, this would be a generic wrapper over pointers.
/// Here, we use a raw pointer and manual layout management to simulate
/// low-level memory operations.
pub struct Tensor {
    pub ptr: *mut f32,
    pub rows: usize,
    pub cols: usize,
    pub layout: Layout,
}

// SAFETY: We are managing the memory manually. 
// In a real implementation, we would implement Drop to ensure safety.
// For this simulation, we rely on the Arena to clean up everything at once.
unsafe impl Send for Tensor {}
unsafe impl Sync for Tensor {}

impl Tensor {
    /// Creates a new tensor on the heap (Standard Strategy).
    /// This simulates the expensive `Vec<f32>` allocation used in naive implementations.
    /// It requires a system allocation call for every intermediate tensor.
    pub fn new_heap(rows: usize, cols: usize) -> Self {
        let layout = Layout::array::<f32>(rows * cols).unwrap();
        // SAFETY: We assume allocation succeeds for the simulation.
        let ptr = unsafe { alloc_zeroed(layout) };
        
        // Simulate filling data (e.g., from a previous layer)
        let slice = unsafe { std::slice::from_raw_parts_mut(ptr, rows * cols) };
        for val in slice.iter_mut() {
            *val = rand::thread_rng().gen_range(0.0..1.0);
        }

        Self { ptr, rows, cols, layout }
    }

    /// Performs a simulated computation (e.g., Matrix Multiplication).
    /// Returns a NEW tensor result, forcing an allocation in the naive approach.
    pub fn matmul_naive(&self, other: &Tensor) -> Tensor {
        // In the naive approach, we allocate the result buffer here on the heap.
        let out_rows = self.rows;
        let out_cols = other.cols;
        let mut result = Tensor::new_heap(out_rows, out_cols);
        
        // Simulate heavy computation (O(N^3) usually)
        // We just write to memory to simulate cache writes.
        let slice = unsafe { std::slice::from_raw_parts_mut(result.ptr, out_rows * out_cols) };
        for i in 0..slice.len() {
            slice[i] = slice[i] + 0.1; // Dummy op
        }
        result
    }

    /// Performs a simulated computation but writes to a pre-allocated pointer.
    /// This is used with the Arena strategy.
    pub fn matmul_arena(&self, other: &Tensor, dest_ptr: *mut f32) {
        let out_rows = self.rows;
        let out_cols = other.cols;
        
        // Write directly to the pre-allocated arena memory.
        // No new allocation happens here.
        let slice = unsafe { std::slice::from_raw_parts_mut(dest_ptr, out_rows * out_cols) };
        for i in 0..slice.len() {
            slice[i] = slice[i] + 0.1; // Dummy op
        }
    }
}

/// A Bump Pointer Arena Allocator.
/// This is the core optimization for inference latency.
/// It allocates a large chunk of memory upfront and simply bumps a pointer
/// for every subsequent allocation.
pub struct Arena {
    ptr: *mut u8,
    layout: Layout,
    offset: usize,
    capacity: usize,
}

impl Arena {
    /// Pre-allocates a large block of memory on the heap.
    /// This is a one-time cost, amortized over all inference steps.
    pub fn new(capacity_bytes: usize) -> Self {
        let layout = Layout::from_size_align(capacity_bytes, 8).unwrap();
        let ptr = unsafe { alloc_zeroed(layout) };
        Self {
            ptr,
            layout,
            offset: 0,
            capacity: capacity_bytes,
        }
    }

    /// "Allocates" memory by simply bumping the offset.
    /// O(1) complexity. Zero fragmentation.
    /// Returns a raw pointer to the region.
    pub fn alloc(&mut self, size_bytes: usize) -> *mut u8 {
        if self.offset + size_bytes > self.capacity {
            panic!("Arena out of memory! Increase capacity.");
        }
        let current_ptr = unsafe { self.ptr.add(self.offset) };
        self.offset += size_bytes;
        current_ptr as *mut u8
    }

    /// Resets the arena, marking all memory as free.
    /// This is extremely fast compared to dropping individual Vecs.
    pub fn reset(&mut self) {
        self.offset = 0;
        // In a real scenario, we might memset to 0 here if needed.
        unsafe {
            std::ptr::write_bytes(self.ptr, 0, self.capacity);
        }
    }
}

impl Drop for Arena {
    fn drop(&mut self) {
        unsafe {
            dealloc(self.ptr, self.layout);
        }
    }
}

/// Simulates the inference pipeline.
/// 1. Loads a "model" (just shapes here).
/// 2. Runs a forward pass.
/// 3. Compares Naive Heap vs. Arena strategies.
fn main() {
    println!("--- High-Performance Inference Engine Simulation ---");
    
    // Configuration: 4 layers, batch size of 32, hidden size of 512.
    // This generates significant memory traffic.
    let batch_size = 32;
    let hidden_size = 512;
    let layers = 4;

    // ---------------------------------------------------------
    // STRATEGY 1: NAIVE HEAP ALLOCATION (Standard Rust Vecs)
    // ---------------------------------------------------------
    println!("\n[1] Running Naive Heap Strategy (Vec<T>)...");
    let start = Instant::now();
    
    // Initial Input
    let mut current_tensor = Tensor::new_heap(batch_size, hidden_size);
    
    for _ in 0..layers {
        // Simulate a weight matrix
        let weight = Tensor::new_heap(hidden_size, hidden_size);
        
        // Allocate new result, drop old one (simulated by reassignment)
        // In reality, this triggers allocator calls for every layer.
        let result = current_tensor.matmul_naive(&weight);
        current_tensor = result; 
    }
    
    let duration_naive = start.elapsed();
    println!("   -> Finished in {:?}", duration_naive);

    // ---------------------------------------------------------
    // STRATEGY 2: ARENA ALLOCATION (Custom Allocator)
    // ---------------------------------------------------------
    println!("\n[2] Running Arena Strategy (Bump Pointer)...");
    let start = Instant::now();

    // Estimate memory needed: 
    // (Batch * Hidden * 4 bytes) * (Input + Weights + Result buffers reused)
    // We need space for Input + (Weights + Result) per layer.
    // Let's be generous: 10MB.
    let mut arena = Arena::new(10 * 1024 * 1024); 

    for _ in 0..layers {
        // 1. Allocate Weight Matrix in Arena
        let weight_ptr = arena.alloc(hidden_size * hidden_size * 4);
        // (In a real engine, we would copy weight data here, or load pointers)
        
        // 2. Allocate Result Buffer in Arena
        let result_ptr = arena.alloc(batch_size * hidden_size * 4);

        // 3. Compute directly into Result Buffer
        // We mock the tensor struct just to hold pointers/shapes
        let weight_tensor = Tensor { ptr: weight_ptr as *mut f32, rows: hidden_size, cols: hidden_size, layout: Layout::new::<f32>() };
        let input_tensor = Tensor { ptr: current_tensor.ptr, rows: batch_size, cols: hidden_size, layout: Layout::new::<f32>() };
        
        input_tensor.matmul_arena(&weight_tensor, result_ptr as *mut f32);

        // 4. Update 'current' pointer to the result for the next layer
        current_tensor.ptr = result_ptr as *mut f32;
    }

    let duration_arena = start.elapsed();
    println!("   -> Finished in {:?}", duration_arena);

    // ---------------------------------------------------------
    // RESULTS ANALYSIS
    // ---------------------------------------------------------
    println!("\n--- Analysis ---");
    let speedup = duration_naive.as_nanos() as f64 / duration_arena.as_nanos() as f64;
    println!("Speedup Factor: {:.2}x", speedup);
    println!("Reasoning:");
    println!("1. Allocator Overhead: Naive strategy calls the system allocator {} times.", layers * 2);
    println!("   Arena calls it ONCE.");
    println!("2. Cache Locality: Arena data is contiguous. Naive data is scattered.");
    println!("3. Fragmentation: Arena produces zero fragmentation.");
}
