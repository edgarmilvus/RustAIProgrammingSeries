
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.rs
// Description: Solution for Exercise 2
// ==========================================

use std::mem;

/// Represents a layer in a model with weights stored on the heap.
/// 
/// Uses `Box<[f32]>` instead of `Vec<f32>` to store the data. 
/// `Box<[T]>` is a "thin pointer" to a heap-allocated slice. It does not store capacity,
/// making it slightly more memory efficient (16 bytes total: pointer + length) than a Vec 
/// (24 bytes: pointer + length + capacity) for fixed-size data.
pub struct DynamicLayer {
    weights: Box<[f32]>,
    rows: usize,
    cols: usize,
}

impl DynamicLayer {
    /// Allocates memory on the heap for the weight matrix.
    /// 
    /// # Arguments
    /// * `rows` - Number of rows in the weight matrix.
    /// * `cols` - Number of columns in the weight matrix.
    pub fn new(rows: usize, cols: usize) -> Self {
        let size = rows * cols;
        // Create a vector and immediately convert it to a boxed slice.
        // This drops the capacity metadata, fixing the size on the heap.
        let data: Vec<f32> = vec
![0.0; size];
        
        DynamicLayer {
            weights: data.into_boxed_slice()
,
            rows,
            cols,
        }
    }

    /// Estimates the total memory usage of the struct and the heap data.
    /// 
    /// # Returns
    /// A tuple containing (Struct Size in bytes, Heap Data Size in bytes).
    pub fn estimate_memory_usage(&self) -> (usize, usize) {
        // Size of the struct itself on the stack (or containing struct)
        // Box<[f32]> is 16 bytes on 64-bit systems (8 for pointer, 8 for length).
        // rows and cols are 8 bytes each.
        let struct_size = mem::size_of_val(self);
        
        // Size of the data on the heap.
        // Note: This is the allocated size, which might be padded, but for f32 it's exact.
        let heap_data_size = self.weights.len() * mem::size_of::<f32>();
        
        (struct_size, heap_data_size)
    }
}

/// Comparison of Box<[f32]> vs Vec<f32>:
/// 
/// 1. **Memory Overhead:**
///    - `Vec<f32>`: 24 bytes (pointer: 8, length: 8, capacity: 8). 
///      It retains capacity to allow efficient appending.
///    - `Box<[f32]>`: 16 bytes (pointer: 8, length: 8). 
///      It is a fixed-size slice. No capacity overhead.
/// 
/// 2. **Allocation Time:**
///    - `Vec<f32>`: Often faster to construct if resizing is needed (amortized O(1) appends).
///      However, creating a Vec of a known size requires a system allocation call.
///    - `Box<[f32]>`: Requires a single allocation call. Converting a Vec to a Box<[f32]> 
///      (via `into_boxed_slice`) may reallocate if the Vec's capacity > length, but usually 
///      it just truncates capacity metadata without moving data.
/// 
/// 3. **Inference Preference:**
///    - For inference, tensor sizes are usually fixed at load time. `Box<[f32]>` is preferred 
///      because it guarantees no reallocation and has slightly smaller memory footprint 
///      (16 vs 24 bytes per tensor metadata), which matters when managing thousands of tensors.
