
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.rs
// Description: Solution for Exercise 3
// ==========================================

/// A simple linear arena allocator for tensors.
/// 
/// Pre-allocates a large chunk of memory on the heap and manages allocations
/// by simply moving an offset pointer forward. This avoids fragmentation
/// and repeated system calls to the global allocator.
pub struct TensorArena {
    /// The backing memory for the arena.
    memory: Box<[f32]>,
    /// The current usage offset in elements (not bytes).
    used: usize,
}

impl TensorArena {
    /// Creates a new arena with a fixed capacity (in number of f32 elements).
    /// 
    /// # Arguments
    /// * `capacity` - Total number of f32 elements the arena can hold.
    pub fn new(capacity: usize) -> Self {
        // Allocate the entire chunk upfront.
        let memory = vec
![0.0; capacity].into_boxed_slice()
;
        
        TensorArena {
            memory,
            used: 0,
        }
    }

    /// Allocates a mutable slice from the arena.
    /// 
    /// # Arguments
    /// * `size` - Number of f32 elements needed.
    /// 
    /// # Returns
    /// `Some(&mut [f32])` if there is enough space, otherwise `None`.
    /// 
    /// # Safety
    /// This method uses unsafe Rust to create a mutable slice from the arena's memory.
    /// We must ensure that the returned slices do not overlap and that the lifetime
    /// is tied to the arena (which we handle via the lifetime elision in the signature).
    pub fn allocate(&mut self, size: usize) -> Option<&mut [f32]> {
        if self.used + size > self.memory.len() {
            return None;
        }
        
        let start = self.used;
        let end = start + size;
        self.used = end;

        // SAFETY: 
        // 1. We know the indices are within bounds (checked above).
        // 2. We are creating a mutable slice from the arena's exclusive mutable reference.
        // 3. The caller cannot outlive the arena because the returned slice's lifetime
        //    is tied to &mut self.
        // 4. We guarantee non-overlapping slices because we advance `self.used` monotonically.
        unsafe {
            let ptr = self.memory.as_mut_ptr();
            Some(std::slice::from_raw_parts_mut(ptr.add(start), size))
        }
    }

    /// Resets the arena for reuse, allowing previous allocations to be overwritten.
    pub fn reset(&mut self) {
        self.used = 0;
    }
}

/// FRAGMENTATION ANALYSIS:
/// 
/// Standard `Vec` allocations for each layer cause fragmentation because:
/// 1. Each `Vec` requests a separate block from the system allocator.
/// 2. As layers are deallocated (dropped), holes are left in the heap.
/// 3. Future allocations may not fit into these holes, leading to wasted space 
///    or requests for new blocks, increasing memory usage and latency.
/// 
/// The `TensorArena` approach:
/// 1. Performs one single allocation at initialization.
/// 2. All "sub-allocations" are just pointer arithmetic within that block.
/// 3. There is no fragmentation because the memory is linear and contiguous.
/// 4. Deallocation is O(1) (just resetting the offset), compared to O(n) for dropping n Vecs.
