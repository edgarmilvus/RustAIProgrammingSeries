
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

/// A fixed-size buffer for token embeddings that resides entirely on the stack.
/// 
/// Total size: 128 tokens * 64 dimensions * 4 bytes (f32) = 32,768 bytes (32KB).
/// This is within typical stack limits (e.g., 1MB on Linux, 1MB on Windows default thread stack),
/// but approaching limits on embedded systems or deeply nested calls.
pub struct TokenEmbeddingBuffer {
    // Using a fixed-size array ensures compile-time size knowledge and stack allocation.
    // The buffer is stored inline within the struct.
    data: [f32; 128 * 64],
}

impl TokenEmbeddingBuffer {
    /// Initializes the buffer with zeros.
    /// 
    /// Note: For large arrays, this involves writing 32KB of memory, which is fast on stack
    /// but still a linear operation.
    pub fn new() -> Self {
        TokenEmbeddingBuffer {
            data: [0.0; 128 * 64],
        }
    }

    /// Returns a slice representing a specific token's embedding.
    /// 
    /// # Arguments
    /// * `token_index` - The index of the token (0..128).
    /// 
    /// # Returns
    /// A slice of 64 f32 values, or None if the index is out of bounds.
    pub fn get_embedding(&self, token_index: usize) -> Option<&[f32]> {
        if token_index >= 128 {
            return None;
        }
        let start = token_index * 64;
        let end = start + 64;
        Some(&self.data[start..end])
    }
}

/// Function to demonstrate passing the struct by value (move).
/// 
/// PERFORMANCE IMPLICATION:
/// Passing `TokenEmbeddingBuffer` by value moves the entire 32KB struct onto the stack 
/// of the callee function. This involves a memory copy (memcpy) of 32KB.
/// While modern CPUs handle this efficiently (often using SIMD registers), it increases
/// stack pressure and can cause a noticeable latency spike if done repeatedly in a hot loop.
/// Additionally, it may trigger stack overflow if the stack frame size becomes too large.
pub fn process_buffer_by_value(buffer: TokenEmbeddingBuffer) {
    // The buffer is now owned by this function. 
    // The 32KB data is copied to this function's stack frame.
    if let Some(embedding) = buffer.get_embedding(0) {
        // Simulate processing...
        let _sum: f32 = embedding.iter().sum();
    }
    // When this function returns, the 32KB is popped off the stack.
}

/// Function to demonstrate passing by reference.
/// 
/// PERFORMANCE IMPLICATION:
/// Passing `&TokenEmbeddingBuffer` only moves a pointer (8 bytes on 64-bit systems).
/// This is extremely fast and avoids stack pressure. The data remains in the caller's
/// stack frame, and the callee accesses it via the pointer.
/// This is the preferred method for large stack-allocated structs to avoid unnecessary copies.
pub fn process_buffer_by_reference(buffer: &TokenEmbeddingBuffer) {
    if let Some(embedding) = buffer.get_embedding(0) {
        // Simulate processing...
        let _sum: f32 = embedding.iter().sum();
    }
    // No stack copy occurs here.
}
