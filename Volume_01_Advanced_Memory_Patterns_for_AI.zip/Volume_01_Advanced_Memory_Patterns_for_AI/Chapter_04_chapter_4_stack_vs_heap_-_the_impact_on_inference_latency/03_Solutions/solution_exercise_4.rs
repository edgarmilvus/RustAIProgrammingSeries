
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.rs
// Description: Solution for Exercise 4
// ==========================================

/// Represents a model where all layer weights are stored in a single,
/// contiguous heap-allocated buffer.
/// 
/// This structure maximizes cache locality by ensuring that data for sequential
/// layers is adjacent in memory, reducing cache misses during forward passes.
pub struct ContiguousModel {
    /// The concatenated weights of all layers.
    data: Box<[f32]>,
    /// Metadata: Starting index of each layer in the `data` buffer.
    layer_offsets: Vec<usize>,
    /// Metadata: Size of each layer (in f32 elements).
    layer_sizes: Vec<usize>,
}

impl ContiguousModel {
    /// Constructs a new contiguous model from a list of layers.
    /// 
    /// # Arguments
    /// * `layers` - A vector of tuples, where each tuple contains (rows, cols) 
    ///              and a vector of weights for that layer.
    pub fn new(layers: Vec<(usize, usize, Vec<f32>)>) -> Self {
        // 1. Calculate total size and offsets.
        let mut total_size = 0;
        let mut layer_offsets = Vec::with_capacity(layers.len());
        let mut layer_sizes = Vec::with_capacity(layers.len());

        for (rows, cols, _) in &layers {
            let size = rows * cols;
            layer_sizes.push(size);
            layer_offsets.push(total_size);
            total_size += size;
        }

        // 2. Allocate the single contiguous buffer.
        let mut data = vec
![0.0; total_size].into_boxed_slice()
;

        // 3. Copy layer data into the contiguous buffer.
        let mut current_offset = 0;
        for (_, _, weights) in layers {
            let size = weights.len();
            // Copy the data from the layer's vector into the main buffer.
            data[current_offset..current_offset + size].copy_from_slice(&weights);
            current_offset += size;
        }

        ContiguousModel {
            data,
            layer_offsets,
            layer_sizes,
        }
    }

    /// Retrieves a slice pointing to a specific layer's weights.
    /// 
    /// # Arguments
    /// * `layer_index` - The index of the layer.
    /// 
    /// # Returns
    /// A slice of the weights for that layer, or None if the index is invalid.
    pub fn get_layer_weights(&self, layer_index: usize) -> Option<&[f32]> {
        if layer_index >= self.layer_offsets.len() {
            return None;
        }

        let start = self.layer_offsets[layer_index];
        let size = self.layer_sizes[layer_index];
        let end = start + size;

        Some(&self.data[start..end])
    }
}

/// MEMORY LAYOUT VISUALIZATION:
/// 
/// 1. SCATTERED LAYOUT (Vec<Box<DynamicLayer>>):
///    [Vec Header] -> [Ptr1, Ptr2, Ptr3, ...]
///                      |       |       |
///                      v       v       v
///                   [Heap]  [Heap]  [Heap]  (Random locations)
///    
///    Problem: Accessing Layer 1, then Layer 2 requires jumping to random heap addresses.
///    This causes "cache misses" because the CPU cannot prefetch the next data.
///
/// 2. CONTIGUOUS LAYOUT (ContiguousModel):
///    [Box<[f32]> Buffer] -> [Layer 1 Data | Layer 2 Data | Layer 3 Data | ...]
///    [Offsets: 0, Size1, Size1+Size2, ...]
///    
///    Benefit: When the CPU loads Layer 1, it automatically pulls adjacent memory lines
///    into the cache. If Layer 2 is accessed immediately, the data is likely already 
///    in the L1/L2 cache, resulting in a "cache hit" and significantly lower latency.
