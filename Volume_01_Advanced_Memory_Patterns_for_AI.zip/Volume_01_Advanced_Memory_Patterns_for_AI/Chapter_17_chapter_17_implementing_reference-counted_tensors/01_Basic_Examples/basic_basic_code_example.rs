
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

use std::fmt;
use std::ops::Deref;
use std::sync::Arc;
use aligned_vec::AVec; // SIMD-aligned vector
use parking_lot::RwLock; // Reader-Writer lock for thread safety

/// Represents the raw, heap-allocated data buffer for a tensor.
/// 
/// In a real scenario, this would be a large block of memory (e.g., 500MB for a model).
/// We use `AVec<f32>` to ensure the memory is aligned to 64-byte boundaries, 
/// which is crucial for AVX-512 SIMD instructions used in matrix multiplication.
struct TensorData {
    buffer: AVec<f32>,
    shape: Vec<usize>,
}

impl TensorData {
    /// Allocates a new tensor buffer with SIMD alignment.
    /// 
    /// # Arguments
    /// * `shape` - The dimensions of the tensor (e.g., [1024, 1024]).
    fn new(shape: Vec<usize>) -> Self {
        let total_elements: usize = shape.iter().product();
        // Allocate aligned memory (64-byte alignment for AVX-512)
        let mut buffer = AVec::with_capacity(64, total_elements);
        
        // Initialize with dummy data (simulating model weights)
        for i in 0..total_elements {
            buffer.push(i as f32 * 0.001);
        }

        TensorData { buffer, shape }
    }

    /// Returns the total number of elements in the tensor.
    fn len(&self) -> usize {
        self.buffer.len()
    }
}

/// A thread-safe, reference-counted wrapper for TensorData.
/// 
/// This struct allows multiple scopes and threads to share the underlying data
/// without deep copying. It uses `Arc` for reference counting and `RwLock`
/// to allow concurrent reads (which is common in inference) while ensuring
/// exclusive access for mutation if needed.
pub struct RcTensor {
    // The shared data. `Arc` manages the lifetime, dropping the data when 
    // the last Arc goes out of scope.
    data: Arc<RwLock<TensorData>>,
}

impl RcTensor {
    /// Creates a new reference-counted tensor.
    pub fn new(shape: Vec<usize>) -> Self {
        let data = TensorData::new(shape);
        RcTensor {
            data: Arc::new(RwLock::new(data)),
        }
    }

    /// Clones the handle, incrementing the reference count.
    /// This is a cheap operation (just copying a pointer and atomic increment).
    /// We explicitly name this `clone_handle` to distinguish it from cloning 
    /// the actual data.
    pub fn clone_handle(&self) -> Self {
        RcTensor {
            data: Arc::clone(&self.data),
        }
    }

    /// Returns the number of active references to this tensor data.
    /// Useful for debugging memory usage in a pipeline.
    pub fn strong_count(&self) -> usize {
        Arc::strong_count(&self.data)
    }

    /// Performs a read operation on the tensor data.
    /// 
    /// In a real inference engine, this would be where matrix multiplication happens.
    /// We acquire a read lock, which allows multiple threads to read simultaneously.
    pub fn read_data(&self) -> ReadGuard {
        let lock = self.data.read();
        ReadGuard { guard: lock }
    }
}

/// A wrapper around the RwLock read guard.
/// This ensures that the lock is held only while the data is being accessed.
pub struct ReadGuard<'a> {
    guard: parking_lot::RwLockReadGuard<'a, TensorData>,
}

impl<'a> Deref for ReadGuard<'a> {
    type Target = TensorData;

    fn deref(&self) -> &Self::Target {
        &self.guard
    }
}

/// Custom Debug implementation to avoid printing massive data buffers.
impl fmt::Debug for RcTensor {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // We need to lock briefly to read the shape, but we don't want to 
        // hold the lock during the formatting output.
        let shape = self.data.read().shape.clone();
        write!(f, "RcTensor(shape={:?}, refs={})", shape, Arc::strong_count(&self.data))
    }
}

/// Simulates a worker thread in an inference server.
/// It takes a tensor handle and performs a computation.
fn inference_worker(tensor: RcTensor, worker_id: usize) {
    println!("[Worker {}] Starting inference. References: {}", worker_id, tensor.strong_count());
    
    // Access the data via the read guard
    let data_guard = tensor.read_data();
    let first_element = data_guard.buffer[0];
    
    // Simulate heavy computation
    println!("[Worker {}] Processing tensor. First element: {}. Shape: {:?}",
             worker_id, first_element, data_guard.shape);
    
    // The guard is dropped here, releasing the read lock.
    // The `tensor` handle is dropped at the end of the function scope.
}

fn main() {
    println!("=== AI Inference Server: Reference-Counted Tensors ===\n");

    // 1. Create the master tensor (e.g., loaded from disk).
    // This represents a large model weight matrix.
    let master_tensor = RcTensor::new(vec![1024, 1024]);
    println!("[Main] Created master tensor: {:?}", master_tensor);

    // 2. Simulate spawning multiple worker threads to handle concurrent requests.
    // We clone the handle for each thread. This increments the atomic reference count.
    let mut handles = vec
![];
    
    for i in 0..3 {
        // Cheap clone of the handle
        let tensor_handle = master_tensor.clone_handle()
;
        
        let handle = std::thread::spawn(move || {
            inference_worker(tensor_handle, i);
        });
        handles.push(handle);
    }

    // 3. Wait for all workers to finish.
    for handle in handles {
        handle.join().unwrap();
    }

    println!("\n[Main] All workers finished.");
    println!("[Main] Master tensor references: {}", master_tensor.strong_count());

    // 4. Drop the master tensor.
    // The underlying data is NOT dropped yet because the workers' handles 
    // have already been dropped in their threads.
    drop(master_tensor);
    
    println!("[Main] Master tensor dropped.");
    println!("=== End of Simulation ===");
}
