
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.rs
// Description: Solution for Exercise 4
// ==========================================

// Cargo.toml dependencies: serde = { version = "1.0", features = ["derive"] }, serde_json = "1.0"

use serde::Deserialize;
use std::collections::{HashMap, VecDeque};
use std::fs;

#[derive(Debug, Deserialize)]
struct TensorNode {
    id: String,
    size_mb: usize,
    consumers: Vec<String>,
}

#[derive(Debug, Deserialize)]
struct GraphConfig {
    tensors: Vec<TensorNode>,
}

struct GraphSimulator {
    nodes: HashMap<String, TensorNode>,
    // Simulates strong reference counts
    ref_counts: HashMap<String, usize>,
}

impl GraphSimulator {
    fn new(config: GraphConfig) -> Self {
        let mut nodes = HashMap::new();
        for node in config.tensors {
            nodes.insert(node.id.clone(), node);
        }

        Self {
            nodes,
            ref_counts: HashMap::new(),
        }
    }

    fn simulate(&mut self, simulate_drop: bool) {
        // 1. Initialize ref counts based on consumers
        // If a node A is a consumer of B, B's ref count increases.
        for (id, node) in &self.nodes {
            // Initialize all to 0
            self.ref_counts.entry(id.clone()).or_insert(0);
            
            // For every consumer of this node, increment the node's count
            for consumer in &node.consumers {
                // If the consumer exists in our graph, increment the producer's count
                if self.nodes.contains_key(consumer) {
                    *self.ref_counts.entry(id.clone()).or_insert(0) += 1;
                }
            }
        }

        // 2. Topological traversal (simplified: just iterate consumers)
        let mut current_memory = 0;
        let mut peak_memory = 0;
        let mut total_allocated = 0;

        // Initial allocation
        for (id, node) in &self.nodes {
            total_allocated += node.size_mb;
            // If it has no consumers (final output), it starts with a count of 0 (or 1 if we consider it "held")
            // But based on logic: if no one consumes it, ref_count remains 0 (immediately droppable)
            // Let's assume the "root" nodes are implicitly held until the end for this simulation.
            if node.consumers.is_empty() {
                 // These are outputs, they stay alive
                 current_memory += node.size_mb;
            }
        }
        peak_memory = current_memory.max(peak_memory);

        println!("--- Simulation Start ---");
        println!("Total Allocated: {} MB", total_allocated);

        // 3. Simulate processing
        // We process nodes in a simple order. In a real DAG, we'd use topological sort.
        // Here, we just iterate and decrement counts.
        
        // Identify "dead branches" if flag is set
        if simulate_drop {
            println!("--- Analyzing Dead Branches (Weak/Unused) ---");
            let mut to_drop = Vec::new();
            
            // A node is dead if it has ref_count 0 and is not a final output
            for (id, count) in &self.ref_counts {
                if *count == 0 {
                    if let Some(node) = self.nodes.get(id) {
                        if !node.consumers.is_empty() {
                            // It's a producer but no one holds a strong ref to it anymore
                            // (Simulated logic: in a real execution, once consumers are done, they drop)
                            to_drop.push(id);
                            println!("Node {} is a dead branch ({} MB freed)", id, node.size_mb);
                        }
                    }
                }
            }
            
            // Visualize the state
            for id in to_drop {
                current_memory -= self.nodes.get(id).unwrap().size_mb;
            }
        }

        println!("Peak Memory Usage: {} MB", peak_memory);
        println!("Final Memory Usage: {} MB", current_memory);
    }
}

fn main() {
    // Example JSON input (would usually be read from file)
    let json_data = r#"
    {
      "tensors": [
        { "id": "A", "size_mb": 1024, "consumers": ["B", "C"] },
        { "id": "B", "size_mb": 512, "consumers": ["D"] },
        { "id": "C", "size_mb": 512, "consumers": ["D"] },
        { "id": "D", "size_mb": 256, "consumers": [] }
      ]
    }
    "#;

    let config: GraphConfig = serde_json::from_str(json_data).expect("Invalid JSON");
    let mut simulator = GraphSimulator::new(config);
    
    // Simulate with drop analysis
    simulator.simulate(true);
}
