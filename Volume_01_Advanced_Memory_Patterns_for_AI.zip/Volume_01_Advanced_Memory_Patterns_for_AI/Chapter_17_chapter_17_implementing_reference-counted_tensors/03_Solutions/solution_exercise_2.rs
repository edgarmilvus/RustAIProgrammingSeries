
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.rs
// Description: Solution for Exercise 2
// ==========================================

use std::alloc::{GlobalAlloc, Layout, System};

struct AlignedAllocator;

unsafe impl GlobalAlloc for AlignedAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        // We need to ensure the alignment is at least 32 bytes.
        // If the requested alignment is less, we force it to 32.
        let align = if layout.align() < 32 { 32 } else { layout.align() };
        
        // Create a new layout with the guaranteed alignment.
        // Note: from_size_align will panic if the alignment isn't a power of two.
        let new_layout = match Layout::from_size_align(layout.size(), align) {
            Ok(l) => l,
            Err(_) => return std::ptr::null_mut(),
        };

        // Delegate to the system allocator.
        System.alloc(new_layout)
    }

    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        // IMPORTANT: We must use the same layout rules for deallocation 
        // as we did for allocation to avoid UB.
        let align = if layout.align() < 32 { 32 } else { layout.align() };
        let new_layout = Layout::from_size_align(layout.size(), align)
            .expect("Failed to reconstruct layout in dealloc");
        
        System.dealloc(ptr, new_layout);
    }
}

// Set the global allocator to our custom implementation.
#[global_allocator]
static ALLOCATOR: AlignedAllocator = AlignedAllocator;

// A modified tensor struct that doesn't need to manage alignment manually
// because the global allocator handles it.
struct AlignedTensor<T> {
    data: *mut T,
    size: usize,
}

impl<T> AlignedTensor<T> {
    pub fn new(size: usize) -> Self {
        let layout = Layout::array::<T>(size).expect("Layout calculation failed");
        
        // The global allocator (AlignedAllocator) is invoked here.
        // It guarantees the pointer returned is at least 32-byte aligned.
        let ptr = unsafe { std::alloc::alloc(layout) as *mut T };
        
        // Initialize to zero (simple implementation)
        unsafe {
            std::ptr::write_bytes(ptr, 0, size);
        }

        AlignedTensor { data: ptr, size }
    }
}

impl<T> Drop for AlignedTensor<T> {
    fn drop(&mut self) {
        let layout = Layout::array::<T>(self.size).unwrap();
        unsafe {
            std::alloc::dealloc(self.data as *mut u8, layout);
        }
    }
}

#[cfg(test)]
mod tests_aligned {
    use super::*;

    #[test]
    fn test_alignment() {
        let tensor = AlignedTensor::<f32>::new(100);
        let addr = tensor.data as usize;
        
        // Assert that the address is divisible by 32.
        assert_eq!(addr % 32, 0);
    }
}
