
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

use std::alloc::{Layout, alloc_zeroed, dealloc};
use std::sync::Arc;
use std::ptr::NonNull;

// The deallocator holds the metadata required to free the memory.
// It stores a NonNull<u8> (type-erased pointer) and the Layout used for allocation.
struct TensorDeallocator {
    ptr: NonNull<u8>,
    layout: Layout,
}

impl Drop for TensorDeallocator {
    fn drop(&mut self) {
        // SAFETY: The pointer and layout match the allocation in AtomicTensor::new.
        // We are the sole owner of this memory (as the Arc reference count drops to 0).
        unsafe {
            dealloc(self.ptr.as_ptr(), self.layout);
        }
    }
}

// The AtomicTensor holds the typed pointer and the shared deallocator.
struct AtomicTensor<T> {
    data: *mut T,
    deallocator: Arc<TensorDeallocator>,
}

// SAFETY: 
// 1. Send: We can send the pointer and Arc to another thread because Arc is Send,
//    and raw pointers are Send (though unsafe to use).
// 2. Sync: We can share immutable references between threads because Arc is Sync,
//    and we do not support interior mutability without atomics (which we aren't using here).
unsafe impl<T: Send + Sync> Send for AtomicTensor<T> {}
unsafe impl<T: Send + Sync> Sync for AtomicTensor<T> {}

impl<T> AtomicTensor<T> {
    pub fn new(size: usize) -> Self {
        // Calculate layout with alignment (e.g., 64 bytes for AVX-512).
        // We use Layout::from_size_align to enforce specific alignment.
        let layout = Layout::from_size_align(size * std::mem::size_of::<T>(), 64)
            .expect("Invalid layout size or alignment");

        // Allocate memory initialized to zero.
        // alloc_zeroed handles the zeroing of bytes.
        let ptr = unsafe { alloc_zeroed(layout) };
        
        // Wrap the raw pointer in NonNull for the deallocator.
        let non_null_ptr = NonNull::new(ptr as *mut u8)
            .expect("Allocation failed: returned null pointer");

        AtomicTensor {
            // Cast the *mut u8 back to *mut T for type-safe access in Rust.
            data: ptr as *mut T,
            deallocator: Arc::new(TensorDeallocator {
                ptr: non_null_ptr,
                layout,
            }),
        }
    }

    pub fn clone(&self) -> Self {
        // Increment the reference count by cloning the Arc.
        // The underlying data pointer remains the same.
        AtomicTensor {
            data: self.data,
            deallocator: Arc::clone(&self.deallocator),
        }
    }
    
    // Helper method to access data for testing (unsafe because we don't check bounds here)
    pub unsafe fn get_unchecked(&self, index: usize) -> &T {
        &*self.data.add(index)
    }
    
    // Helper method for testing writes
    pub unsafe fn get_unchecked_mut(&mut self, index: usize) -> &mut T {
        &mut *self.data.add(index)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::thread;

    #[test]
    fn test_thread_safety() {
        // Create a tensor with space for 100 elements.
        let tensor = AtomicTensor::<i32>::new(100);
        
        // Clone the tensor for the main thread.
        let mut main_tensor = tensor.clone();

        // Spawn a thread that holds a clone of the tensor.
        let handle = thread::spawn(move || {
            // 'tensor' is moved into this thread.
            // We can access it safely.
            unsafe {
                let val = tensor.get_unchecked(10);
                assert_eq!(*val, 0); // Should be zero-initialized
            }
        });

        // Modify data in the main thread.
        unsafe {
            let val = main_tensor.get_unchecked_mut(10);
            *val = 42;
        }

        // Wait for the thread to finish.
        handle.join().unwrap();

        // Verify the change is visible (since they point to the same memory).
        unsafe {
            let val = main_tensor.get_unchecked(10);
            assert_eq!(*val, 42);
        }
    }
}
