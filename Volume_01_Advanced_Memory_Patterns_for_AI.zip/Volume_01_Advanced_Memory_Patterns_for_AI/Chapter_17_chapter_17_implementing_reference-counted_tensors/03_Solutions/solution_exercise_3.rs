
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.rs
// Description: Solution for Exercise 3
// ==========================================

struct TensorView<'a, T> {
    parent: &'a AtomicTensor<T>,
    offset: usize,
    shape: Vec<usize>,
    strides: Vec<usize>,
}

impl<'a, T> TensorView<'a, T> {
    pub fn new(
        parent: &'a AtomicTensor<T>, 
        shape: Vec<usize>, 
        strides: Vec<usize>, 
        offset: usize
    ) -> Self {
        TensorView {
            parent,
            offset,
            shape,
            strides,
        }
    }

    /// Calculates the flat memory index based on multidimensional indices.
    /// Returns None if indices are out of bounds.
    pub fn at(&self, indices: &[usize]) -> Option<&T> {
        if indices.len() != self.shape.len() {
            return None;
        }

        let mut flat_index = self.offset;
        for (i, &dim_idx) in indices.iter().enumerate() {
            if dim_idx >= self.shape[i] {
                return None; // Bounds check
            }
            flat_index += dim_idx * self.strides[i];
        }

        // SAFETY: We have checked bounds, and the parent pointer is valid 
        // as long as 'a is valid.
        unsafe {
            Some(&*self.parent.data.add(flat_index))
        }
    }

    /// Returns a new view with swapped dimensions (transpose).
    /// This only modifies metadata, not data.
    pub fn transpose(&self, dim1: usize, dim2: usize) -> TensorView<'a, T> {
        let mut new_shape = self.shape.clone();
        let mut new_strides = self.strides.clone();

        // Swap shape and stride for the specified dimensions
        new_shape.swap(dim1, dim2);
        new_strides.swap(dim1, dim2);

        TensorView {
            parent: self.parent,
            offset: self.offset,
            shape: new_shape,
            strides: new_strides,
        }
    }
}

// Example usage context (not a test, but illustrative)
fn zero_copy_example() {
    // Assume AtomicTensor is defined from Exercise 1
    // let tensor = AtomicTensor::<i32>::new(100); // 10x10 matrix flattened
    
    // let view = TensorView::new(
    //     &tensor, 
    //     vec
![10, 10], 
    //     vec![10, 1], // C-contiguous strides
    //     0
    // );
    
    // let transposed = view.transpose(0, 1)
; // Swaps shape to [10, 10] and strides to [1, 10]
    
    // Accessing (0, 1) in original view reads index 1.
    // Accessing (0, 1) in transposed view reads index 10.
}
