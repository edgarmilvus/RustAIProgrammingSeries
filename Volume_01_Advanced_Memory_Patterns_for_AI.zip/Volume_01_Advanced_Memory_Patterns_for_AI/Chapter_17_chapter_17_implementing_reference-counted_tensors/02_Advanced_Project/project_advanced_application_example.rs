
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

use std::sync::Arc;
use std::time::Instant;
use std::thread;

/// Represents a raw, heap-allocated tensor buffer.
/// In a real scenario, this would wrap unsafe pointers to CUDA or Vulkan memory.
/// Here, we simulate large data using a Vec<f32>.
struct TensorBuffer {
    data: Vec<f32>,
    id: usize,
}

impl TensorBuffer {
    /// Simulates loading a large model weight from disk.
    /// This is an expensive operation that allocates significant memory.
    fn load(id: usize, size: usize) -> Self {
        println!("[Allocator] Loading Tensor ID {} ({} elements)...", id, size);
        // Initialize with dummy data (simulating weights)
        let data = vec
![0.0; size];
        TensorBuffer { data, id }
    }
}

/// Implements the Drop trait to simulate custom deallocation logic.
/// When this buffer is dropped, we can log memory release or return it to a pool.
impl Drop for TensorBuffer {
    fn drop(&mut self)
 {
        println!("[Allocator] Deallocating Tensor ID {} (Memory Freed).", self.id);
    }
}

/// A reference-counted Tensor wrapper.
/// This struct is cheap to clone; it does not copy the underlying data.
/// It uses `Arc` to manage the lifecycle of the `TensorBuffer`.
#[derive(Clone)]
struct SharedTensor {
    /// The Arc allows multiple owners of the same data buffer.
    buffer: Arc<TensorBuffer>,
    shape: Vec<usize>,
}

impl SharedTensor {
    /// Creates a new tensor, taking ownership of the buffer and wrapping it in an Arc.
    fn new(buffer: TensorBuffer, shape: Vec<usize>) -> Self {
        SharedTensor {
            buffer: Arc::new(buffer),
            shape,
        }
    }

    /// Returns the total number of elements in the tensor.
    fn len(&self) -> usize {
        self.buffer.data.len()
    }

    /// Provides read-only access to the underlying data.
    /// In a real SIMD-optimized scenario, this pointer would be passed to AVX/NEON intrinsics.
    fn data(&self) -> &[f32] {
        &self.buffer.data
    }

    /// Simulates a computation (e.g., Matrix Multiplication).
    /// Since we have shared ownership, we can pass this tensor to threads safely.
    fn compute(&self) -> f32 {
        // Dummy computation: sum of elements
        self.data().iter().sum()
    }
}

/// A mock inference engine that processes requests.
struct InferenceEngine {
    // The engine holds a shared reference to the model weights.
    // In a real server, this might be `Arc<ModelWeights>`.
    model_weights: SharedTensor,
}

impl InferenceEngine {
    fn new(model_weights: SharedTensor) -> Self {
        InferenceEngine { model_weights }
    }

    /// Handles a single inference request.
    /// Because `SharedTensor` uses `Arc`, cloning it here is cheap (just increments a counter).
    fn handle_request(&self, request_id: usize) {
        let start = Instant::now();
        
        // Clone the shared tensor. This creates a new handle to the SAME memory.
        // The underlying TensorBuffer is NOT copied.
        let weights_handle = self.model_weights.clone();
        
        // Spawn a thread to simulate async processing.
        let handle = thread::spawn(move || {
            // Perform computation using the shared weights.
            let result = weights_handle.compute();
            println!(
                "[Request {}] Processed using Tensor ID {} (Result: {:.2}, Time: {:?})",
                request_id,
                weights_handle.buffer.id,
                result,
                start.elapsed()
            );
        });

        let _ = handle.join();
    }
}

fn main() {
    println!("=== High-Performance Inference Server Simulation ===\n");

    // 1. Initialization Phase: Load Model Weights
    // This is the "expensive" phase. We allocate a large buffer (simulating 1GB+ of weights).
    // In a real system, this might come from a custom memory arena or GPU VRAM.
    let model_buffer = TensorBuffer::load(1, 10_000_000); 
    let model_weights = SharedTensor::new(model_buffer, vec![1000, 10000]);

    // 2. Instantiate the Inference Engine
    // The engine takes ownership of the shared weights.
    let engine = InferenceEngine::new(model_weights);

    println!("\n--- Starting Inference Requests ---\n");

    // 3. Handle Concurrent Requests
    // We simulate 5 concurrent requests. Each request gets a cheap clone of the weights.
    // Notice: We do NOT see "Loading Tensor" logs here. Memory is shared.
    let request_ids = vec
![101, 102, 103, 104, 105];
    for id in request_ids {
        engine.handle_request(id)
;
    }

    println!("\n--- All Requests Completed ---\n");

    // 4. Scope Cleanup
    // The `engine` goes out of scope here, dropping its `SharedTensor`.
    // However, the memory is NOT freed yet because `handle_request` threads 
    // might still be holding Arcs (though we joined them above).
    // In a real async runtime (like Tokio), we would await task completion.
    
    println!("Server shutting down...");
}
