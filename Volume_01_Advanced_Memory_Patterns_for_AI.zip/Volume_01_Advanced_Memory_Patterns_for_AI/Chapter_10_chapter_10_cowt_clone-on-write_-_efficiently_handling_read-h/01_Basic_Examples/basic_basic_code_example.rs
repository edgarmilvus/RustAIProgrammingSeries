
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

use std::borrow::Cow;
use std::collections::HashMap;

/// Represents the configuration for an AI Inference Server.
/// In a real scenario, this might contain model paths, batch sizes, and GPU settings.
#[derive(Debug, Clone)]
struct ServerConfig {
    settings: HashMap<String, String>,
}

impl ServerConfig {
    /// Creates a new ServerConfig.
    fn new() -> Self {
        let mut settings = HashMap::new();
        settings.insert("batch_size".to_string(), "32".to_string());
        settings.insert("model_path".to_string(), "/models/v1".to_string());
        ServerConfig { settings }
    }

    /// Retrieves a configuration value.
    /// This is a read-only operation, suitable for `Cow::Borrowed`.
    fn get(&self, key: &str) -> Option<&String> {
        self.settings.get(key)
    }

    /// Updates a configuration value.
    /// This requires mutable access. If we have a `Cow::Borrowed`, this will trigger a clone.
    fn update(&mut self, key: &str, value: &str) {
        self.settings.insert(key.to_string(), value.to_string());
    }
}

/// A struct managing the lifecycle of the server configuration using Clone-on-Write.
struct ConfigManager<'a> {
    /// The configuration is stored as a Cow.
    /// - `Cow::Borrowed`: Points to a static, immutable configuration (zero allocation).
    /// - `Cow::Owned`: Holds a modified copy of the configuration (heap allocated).
    config: Cow<'a, ServerConfig>,
}

impl<'a> ConfigManager<'a> {
    /// Initializes the manager with a static configuration reference.
    /// This is the "zero-copy" path.
    fn new_static(config: &'a ServerConfig) -> Self {
        ConfigManager {
            config: Cow::Borrowed(config),
        }
    }

    /// Simulates a read-heavy workload.
    /// We access the configuration without triggering any cloning.
    fn get_setting(&self, key: &str) -> Option<&String> {
        // `Cow` automatically dereferences to the inner type.
        // No allocation occurs here.
        self.config.get(key)
    }

    /// Simulates a "Hot Reload" or request-specific override.
    /// This is where the "Clone-on-Write" magic happens.
    fn update_setting(&mut self, key: &str, value: &str) {
        // `to_mut()` checks the internal state:
        // 1. If `Cow::Borrowed`: It clones the data, turns it into `Cow::Owned`, 
        //    and returns a mutable reference.
        // 2. If `Cow::Owned`: It simply returns a mutable reference.
        self.config.to_mut().update(key, value);
    }
}

fn main() {
    // 1. Initialization: Load the base configuration (simulating a file load).
    // This is a heavy operation, done once.
    let base_config = ServerConfig::new();
    println!("Base Config Loaded: {:?}", base_config.settings);

    // 2. Create the Manager using the static reference.
    // At this point, `config_manager.config` is `Cow::Borrowed`.
    let mut config_manager = ConfigManager::new_static(&base_config);

    // 3. Read-Heavy Phase (Inference Loop).
    // We access data frequently. No cloning happens here.
    println!("\n--- Read Phase ---");
    if let Some(batch) = config_manager.get_setting("batch_size") {
        println!("Current Batch Size: {}", batch);
    }

    // 4. Write Phase (Hot Reload or User Override).
    // We need to change a setting for a specific context.
    println!("\n--- Write Phase (Triggering Clone) ---");
    config_manager.update_setting("batch_size", "64");

    // 5. Verification.
    // The configuration is now owned by the manager.
    // The original `base_config` remains untouched.
    println!("Updated Batch Size: {:?}", config_manager.get_setting("batch_size"));
    println!("Original Base Config (Unchanged): {:?}", base_config.settings);
}
