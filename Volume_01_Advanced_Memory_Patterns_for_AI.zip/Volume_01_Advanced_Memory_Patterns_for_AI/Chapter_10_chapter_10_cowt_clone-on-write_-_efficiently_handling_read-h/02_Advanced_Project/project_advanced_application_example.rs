
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

use std::borrow::Cow;
use std::sync::{Arc, RwLock};
use std::thread;
use std::time::Duration;

/// Represents the weights of a neural network layer.
/// In a real scenario, this would be a large tensor (e.g., Vec<f32>).
/// For this example, we use a simple vector of floats.
#[derive(Debug, Clone)]
struct LayerWeights {
    weights: Vec<f32>,
    bias: Vec<f32>,
}

impl LayerWeights {
    /// Creates a new set of weights (simulating loading from disk).
    fn load(size: usize) -> Self {
        println!("[System] Loading model weights (size: {})...", size);
        let weights = vec
![1.0; size]; // Simulating loaded data
        let bias = vec
![0.0; size / 10];
        Self { weights, bias }
    }

    /// Performs a forward pass simulation.
    fn forward(&self)
 -> f32 {
        // Simulate heavy computation
        self.weights.iter().sum()
    }
}

/// The core structure managing the model state.
/// We use `Arc` to allow shared ownership across threads.
/// The `Cow` wrapper allows us to defer cloning if we need to modify the weights.
struct InferenceServer {
    // `Cow` allows us to store either a reference to static weights 
    // or a cloned, mutable version.
    // In a real app, the 'Borrowed variant might point to a memory-mapped file.
    model_weights: Arc<RwLock<Cow<'static, LayerWeights>>>,
}

impl InferenceServer {
    fn new(weights: LayerWeights) -> Self {
        // We wrap the weights in `Cow::Owned` to take ownership.
        // In a production system, we might use `Cow::Borrowed` if we have 
        // a static lifetime reference (e.g., from a memory map).
        let cow = Cow::Owned(weights);
        InferenceServer {
            model_weights: Arc::new(RwLock::new(cow)),
        }
    }

    /// Handles an inference request.
    /// This is the "Read-heavy" path. It reads the weights without cloning.
    fn handle_request(&self) -> f32 {
        let lock = self.model_weights.read().unwrap();
        
        // `lock` dereferences to `&LayerWeights`.
        // Since `Cow` implements `Deref`, we can access fields directly.
        let result = lock.forward();
        
        println!("[Inference] Request processed. Result: {:.2}", result);
        result
    }

    /// Handles a specialized request that requires dynamic quantization.
    /// This is the "Write" path. It triggers cloning only when necessary.
    fn handle_quantized_request(&self, threshold: f32) {
        println!("[System] Handling quantized request (threshold: {})...", threshold);
        
        // We acquire a write lock.
        let mut lock = self.model_weights.write().unwrap();
        
        // CRITICAL: `Cow` checks if we are borrowing or owning.
        // 1. If `Borrowed`, `to_mut()` clones the data to make it owned and mutable.
        // 2. If already `Owned`, it simply returns a mutable reference.
        let mutable_weights = lock.to_mut();
        
        // We modify the weights in place (simulating dynamic quantization).
        // This modification happens on the cloned copy if it was borrowed.
        for w in mutable_weights.weights.iter_mut() {
            if *w > threshold {
                *w = 1.0; // Binarize
            } else {
                *w = 0.0;
            }
        }
        
        println!("[System] Weights quantized in memory. Ready for specialized inference.");
    }
}

fn main() {
    // 1. Initialization: Load the model once.
    // This is expensive, so we do it before the server starts.
    let initial_weights = LayerWeights::load(100);
    let server = InferenceServer::new(initial_weights);

    // 2. Simulate standard inference traffic (Read-heavy).
    // Multiple threads can read concurrently without triggering clones.
    let server_clone = server.clone();
    let t1 = thread::spawn(move || {
        server_clone.handle_request();
    });

    let server_clone = server.clone();
    let t2 = thread::spawn(move || {
        server_clone.handle_request();
    });

    t1.join().unwrap();
    t2.join().unwrap();

    // 3. Simulate a specialized request (Write-triggered Clone).
    // This request modifies the weights. 
    // If `Cow` wasn't used, we might have had to clone eagerly at initialization.
    // With `Cow`, the clone happens lazily right here.
    let server_clone = server.clone();
    let t3 = thread::spawn(move || {
        // The threshold triggers a modification.
        server_clone.handle_quantized_request(0.5);
        
        // Verify the modification by running inference again
        server_clone.handle_request();
    });

    t3.join().unwrap();
    
    println!("[System] Server simulation complete.");
}

// Boilerplate to allow cloning the server handle for threads
impl Clone for InferenceServer {
    fn clone(&self) -> Self {
        Self {
            model_weights: Arc::clone(&self.model_weights),
        }
    }
}
