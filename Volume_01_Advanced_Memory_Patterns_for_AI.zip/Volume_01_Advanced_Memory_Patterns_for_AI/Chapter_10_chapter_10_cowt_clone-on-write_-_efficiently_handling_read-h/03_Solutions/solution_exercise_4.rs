
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.rs
// Description: Solution for Exercise 4
// ==========================================

use std::borrow::Cow;

#[derive(Debug)]
struct ImageMetadata<'a> {
    camera_id: Cow<'a, str>,
    timestamp: String, // Timestamps are usually unique, so String is fine
    tags: Vec<Cow<'a, str>>,
}

fn process_batch<'a>(raw_data: Vec<(&'a str, &'a str, Vec<&'a str>)>) -> Vec<ImageMetadata<'a>> {
    raw_data.into_iter().map(|(raw_cam, raw_ts, raw_tags)| {
        // Optimization Logic for Camera ID
        let camera_id = if raw_cam == "CAM_001" {
            Cow::Borrowed("CAM_001") // Reuse static memory
        } else {
            Cow::Owned(raw_cam.to_string()) // Unique ID, allocate
        };

        // Optimization Logic for Tags
        let tags: Vec<Cow<str>> = raw_tags.into_iter().map(|tag| {
            if tag == "standard" {
                Cow::Borrowed("standard")
            } else {
                Cow::Owned(tag.to_string())
            }
        }).collect();

        ImageMetadata {
            camera_id,
            timestamp: raw_ts.to_string(), // Always unique in this simulation
            tags,
        }
    }).collect()
}

fn main() {
    // Simulated batch: 3 images
    // Image 1 & 2 share CAM_001 and "standard" tag.
    // Image 3 has a unique camera and tag.
    let raw_batch = vec
![
        ("CAM_001", "12:00:01", vec
!["standard", "daylight"])
,
        ("CAM_001", "12:00:02", vec
!["standard"])
,
        ("UUID_CAM_99", "12:00:03", vec
!["night", "low_light"])
,
    ];

    let processed = process_batch(raw_batch);

    // Verification
    for meta in &processed {
        println!("Meta: {:?}, Tags: {:?}", meta.camera_id, meta.tags);
    }

    // Memory Layout Visualization (Described as requested)
    /*
    NAIVE APPROACH (String everywhere):
    Heap 1: "CAM_001" (Image 1)
    Heap 2: "CAM_001" (Image 2)  <-- DUPLICATION
    Heap 3: "UUID_CAM_99" (Image 3)
    Heap 4: "standard" (Image 1)
    Heap 5: "daylight" (Image 1)
    Heap 6: "standard" (Image 2) <-- DUPLICATION
    Heap 7: "night" (Image 3)
    Heap 8: "low_light" (Image 3)

    COW APPROACH:
    Static Data Segment: "CAM_001", "standard"
    
    Image 1:
      camera_id: Pointer to "CAM_001" (Static)
      tags: [Pointer to "standard", Heap: "daylight"]
      
    Image 2:
      camera_id: Pointer to "CAM_001" (Static) <-- SHARED
      tags: [Pointer to "standard"] <-- SHARED
      
    Image 3:
      camera_id: Heap: "UUID_CAM_99"
      tags: [Heap: "night", Heap: "low_light"]
    */
}
