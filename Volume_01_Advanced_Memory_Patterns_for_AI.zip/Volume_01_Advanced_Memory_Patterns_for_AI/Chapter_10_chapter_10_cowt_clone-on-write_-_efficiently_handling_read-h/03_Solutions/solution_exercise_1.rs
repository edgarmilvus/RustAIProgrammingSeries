
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

use std::borrow::Cow;
use std::thread;

struct ModelConfig<'a> {
    model_name: Cow<'a, str>,
    optimizer_type: Cow<'a, str>,
    batch_size: u32, // Keeping primitives as values is usually fine
}

impl<'a> ModelConfig<'a> {
    // In a real scenario, the 'yaml parameter would likely be a slice of a loaded file.
    // Here we simulate parsing by constructing the struct directly.
    pub fn load_from_yaml(_yaml: &'a str) -> Self {
        // Simulation: The YAML loader detects that "ResNet-50" and "Adam" 
        // are standard values, so we use Cow::Borrowed with 'static lifetimes 
        // (or the lifetime of the file buffer).
        ModelConfig {
            model_name: Cow::Borrowed("ResNet-50"),
            optimizer_type: Cow::Borrowed("Adam"),
            batch_size: 32,
        }
    }

    pub fn override_batch_size(&mut self, new_size: u32) {
        // This is the key optimization. 
        // If self.batch_size is currently Borrowed (shared), to_mut() clones it 
        // into an Owned variant. If it's already Owned, it returns the mutable reference directly.
        // Since batch_size is a primitive u32, we can just assign it. 
        // But if it were a Cow<String>, we would do: self.batch_size.to_mut().push_str(...);
        
        // Let's adapt the requirement to a String field to demonstrate Cow::to_mut() clearly:
        // Let's pretend we have a field `notes: Cow<'a, str>` instead of batch_size for this specific logic.
        // However, sticking to the skeleton:
        // For primitives, assignment is enough. For Cow<String> fields:
        
        // Example logic for a String field:
        // self.optimizer_type.to_mut().push_str(" (Modified)");
        
        // For the requested u32 field:
        self.batch_size = new_size;
    }
    
    // Helper to demonstrate shared state
    pub fn get_batch_size(&self) -> u32 {
        self.batch_size
    }
}

fn main() {
    // 1. Load config (Zero copy from the source string)
    let yaml_source = "model: ResNet-50\nopt: Adam"; 
    let config = ModelConfig::load_from_yaml(&yaml_source);
    let shared_config = std::sync::Arc::new(config);

    // 2. Simulate multi-threaded read
    let mut handles = vec
![];
    for i in 0..4 {
        let cfg_ref = shared_config.clone()
;
        handles.push(thread::spawn(move || {
            println!("Thread {}: Config name is {}", i, cfg_ref.model_name);
        }));
    }

    // 3. Dynamic override scenario
    // We simulate one thread needing a modification.
    // We cannot modify the Arc directly, so we clone the Arc, get a mutable reference,
    // and trigger the Cow logic.
    let mut mutable_config = (*shared_config).clone(); // This clone is shallow because of Cow!
    mutable_config.override_batch_size(64); 

    for h in handles {
        h.join().unwrap();
    }
    
    println!("Original batch size: {}", shared_config.get_batch_size());
    println!("Modified batch size: {}", mutable_config.get_batch_size());
}
