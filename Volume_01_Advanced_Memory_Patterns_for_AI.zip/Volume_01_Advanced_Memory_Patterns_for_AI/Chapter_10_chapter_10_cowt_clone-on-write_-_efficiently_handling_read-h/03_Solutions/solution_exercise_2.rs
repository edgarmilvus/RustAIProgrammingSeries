
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.rs
// Description: Solution for Exercise 2
// ==========================================

use std::borrow::Cow;

fn process_corpus(corpus: &str) -> Vec<Cow<'_, str>> {
    corpus.lines()
        .map(|line| {
            if line.contains("[IMPORTANT]") {
                // We need to own this line because we might modify it later
                // or because it needs to outlive the original corpus string.
                Cow::Owned(line.to_string())
            } else {
                // We can borrow this line directly from the corpus slice.
                Cow::Borrowed(line)
            }
        })
        .collect()
}

fn analyze_text(text: &Cow<'_, str>) -> usize {
    // Cow implements Deref, so we can treat it exactly like &str
    text.len()
}

// Interactive Challenge Extension
// We define a wrapper that can store the data internally or just a reference.
// However, to make it truly generic over Into<Cow>, we usually process data 
// immediately or store the Cow itself.

struct TextProcessor<'a> {
    data: Cow<'a, str>,
}

impl<'a> TextProcessor<'a> {
    pub fn new<T: Into<Cow<'a, str>>>(input: T) -> Self {
        TextProcessor {
            data: input.into(),
        }
    }

    pub fn analyze(&self) -> usize {
        self.data.len()
    }
}

fn main() {
    let corpus = "Line 1: Normal\nLine 2: [IMPORTANT] Critical Data\nLine 3: Normal";
    let processed = process_corpus(corpus);

    // Memory comparison logic (Conceptual)
    // processed[0] is Borrowed: 0 allocation.
    // processed[1] is Owned: 1 allocation (heap allocation for the string).
    // processed[2] is Borrowed: 0 allocation.
    
    for item in &processed {
        println!("Analyzed length: {}", analyze_text(item));
    }

    // Testing the generic wrapper
    let p1 = TextProcessor::new("Static Literal"); // Borrowed
    let p2 = TextProcessor::new(String::from("Dynamic String")); // Owned
    
    println!("P1: {}, P2: {}", p1.analyze(), p2.analyze());
}
