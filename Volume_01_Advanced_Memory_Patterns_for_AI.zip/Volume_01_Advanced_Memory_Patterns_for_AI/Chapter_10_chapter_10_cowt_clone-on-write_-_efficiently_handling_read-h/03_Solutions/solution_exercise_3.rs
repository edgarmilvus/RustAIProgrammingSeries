
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.rs
// Description: Solution for Exercise 3
// ==========================================

use std::borrow::Cow;
use std::collections::HashMap;
use std::hash::Hash;

// To support generic K and V that can be borrowed from literals, 
// we need specific trait bounds. 
// For this solution, we will implement it specifically for String keys/values 
// as that is the most common use case for 'static Cows in caching.
// A fully generic implementation requires complex trait bounds (ToOwned, Hash, Eq, etc.).

pub struct Cache {
    // We store the Cow internally.
    // Key: Cow<'static, str>
    // Value: Cow<'static, str>
    // Note: In a real generic library, we'd use HashMap<Cow<'static, K>, Cow<'static, V>>
    // but HashMap requires keys to implement Hash and Eq on the borrowed form.
    // Cow implements these traits if the inner type does.
    data: HashMap<Cow<'static, str>, Cow<'static, str>>,
}

impl Cache {
    pub fn new() -> Self {
        Cache {
            data: HashMap::new(),
        }
    }

    // The insert signature allows passing &'static str or String.
    // &'static str -> Into<Cow<'static, str>> -> Cow::Borrowed
    // String -> Into<Cow<'static, str>> -> Cow::Owned
    pub fn insert<K, V>(&mut self, key: K, value: V)
    where
        K: Into<Cow<'static, str>>,
        V: Into<Cow<'static, str>>,
    {
        self.data.insert(key.into(), value.into());
    }

    pub fn get(&self, key: &str) -> Option<&str> {
        // We need to look up using &str. HashMap<Cow, Cow> supports this 
        // because Cow implements Borrow<str>.
        self.data.get(key).map(|c| c.as_ref())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_cache_efficiency() {
        let mut cache = Cache::new();

        // 1. Static insertion (Zero allocation for value)
        // "DEBUG" is a &'static str literal.
        // It gets wrapped in Cow::Borrowed.
        cache.insert("log_level", "DEBUG");

        // 2. Dynamic insertion (Allocation occurs)
        // format! creates a String, which moves into Cow::Owned.
        let session_id = format!("session-{}", 1001);
        cache.insert("session_id", session_id);

        // 3. Retrieval
        assert_eq!(cache.get("log_level"), Some("DEBUG"));
        assert_eq!(cache.get("session_id"), Some("session-1001"));
        
        // 4. Verify internal state
        // The "log_level" value should be Borrowed, "session_id" should be Owned.
        // (Accessing private fields for test verification is not standard practice, 
        // but useful here to prove the concept).
    }
}
