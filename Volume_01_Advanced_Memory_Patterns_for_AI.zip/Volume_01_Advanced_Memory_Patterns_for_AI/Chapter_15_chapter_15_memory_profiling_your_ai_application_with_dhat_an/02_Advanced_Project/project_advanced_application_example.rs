
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

//! # AI Memory Profiling Example
//!
//! This binary demonstrates how to profile memory usage in a high-performance
//! AI inference pipeline using a custom Arena Allocator and the `dhat` crate.

use std::alloc::{GlobalAlloc, Layout, System};
use std::ptr;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::time::Instant;

// -----------------------------------------------------------------------------
// 1. Custom Arena Allocator Implementation
// -----------------------------------------------------------------------------

/// A simple, thread-unsafe Arena (Linear Allocator) for demonstration.
///
/// # How it works
/// 1. It reserves a large block of memory (the "arena") on initialization.
/// 2. Allocation simply moves a pointer forward (bump pointer).
/// 3. Deallocation is a no-op (O(1)), relying on the arena being reset in bulk.
/// 4. This avoids the overhead of the system allocator during the hot loop.
struct ArenaAllocator {
    arena: *mut u8,
    capacity: usize,
    offset: AtomicUsize,
}

impl ArenaAllocator {
    /// Creates a new arena with a fixed capacity.
    unsafe fn new(capacity: usize) -> Self {
        let layout = Layout::from_size_align(capacity, 8).unwrap();
        let arena = System.alloc(layout);
        
        if arena.is_null() {
            panic!("Failed to allocate arena");
        }

        Self {
            arena,
            capacity,
            offset: AtomicUsize::new(0),
        }
    }

    /// Resets the arena, making all memory available again.
    /// This is used between inference batches.
    unsafe fn reset(&self) {
        self.offset.store(0, Ordering::SeqCst);
    }

    /// Returns the total bytes currently allocated in this arena.
    fn usage(&self) -> usize {
        self.offset.load(Ordering::Relaxed)
    }
}

unsafe impl GlobalAlloc for ArenaAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let current_offset = self.offset.load(Ordering::SeqCst);
        
        // Align the bump pointer
        let align_offset = current_offset.wrapping_add(layout.align() - 1) & !(layout.align() - 1);
        let new_offset = align_offset + layout.size();

        if new_offset > self.capacity {
            // Arena exhausted: fall back to System allocator or panic
            // In a real scenario, we might allocate a new chunk.
            return std::ptr::null_mut();
        }

        // Update the offset atomically. If this fails (CAS loop needed for real concurrency),
        // we would retry. For this single-threaded example, SeqCst ensures safety.
        self.offset.store(new_offset, Ordering::SeqCst);

        // Return pointer to the start of the allocated block
        self.arena.add(align_offset)
    }

    unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {
        // In an arena allocator, we usually don't free individual items.
        // We free the whole arena at once via `reset()`.
        // However, to satisfy the GlobalAlloc trait, we implement a no-op here.
    }
}

// -----------------------------------------------------------------------------
// 2. The AI Inference Pipeline
// -----------------------------------------------------------------------------

/// Represents a Tensor (simplified for this example).
struct Tensor {
    data: Vec<f32>, // Note: In a real arena, this would be a slice, not a Vec.
    shape: Vec<usize>,
}

impl Tensor {
    /// Simulates creating a tensor.
    /// In a real scenario, `data` would be allocated directly into the arena.
    fn new(shape: Vec<usize>) -> Self {
        let size = shape.iter().product();
        // We use Vec here for simplicity, but the allocator tracks these allocations.
        let mut data = Vec::with_capacity(size);
        // Simulate filling data
        for _ in 0..size {
            data.push(1.0);
        }
        Tensor { data, shape }
    }
}

/// The core struct managing the inference workload.
struct InferencePipeline {
    batch_size: usize,
    model_size_mb: usize,
}

impl InferencePipeline {
    fn new(batch_size: usize, model_size_mb: usize) -> Self {
        Self {
            batch_size,
            model_size_mb,
        }
    }

    /// Runs the inference loop.
    /// This simulates the "hot path" where memory allocation happens rapidly.
    fn run(&self) {
        println!("Starting Inference Pipeline...");
        let start = Instant::now();

        // Simulate multiple batches
        for batch_idx in 0..5 {
            // 1. Load Data (Simulated)
            // This would typically hit the ArenaAllocator if we were using it for buffers.
            let inputs = Tensor::new(vec![self.batch_size, 3, 224, 224]);
            
            // 2. Forward Pass (Simulated)
            // Heavy computation would happen here. We just sleep to simulate time.
            // Memory allocated for intermediate layers would ideally live in the arena.
            let _intermediate = Tensor::new(vec![self.batch_size, 512]);
            
            // 3. Post-processing
            let _outputs = Tensor::new(vec![self.batch_size, 1000]);

            // 4. Reset Arena (if using arena for intermediate tensors)
            // unsafe { GLOBAL_ARENA.reset(); } 
            
            println!("Batch {} processed.", batch_idx + 1);
        }

        let duration = start.elapsed();
        println!("Pipeline finished in {:?}", duration);
    }
}

// -----------------------------------------------------------------------------
// 3. Global Allocator Setup & Main
// -----------------------------------------------------------------------------

// We define our global allocator. 
// In a real application, this might be conditional on a feature flag or environment variable.
#[global_allocator]
static GLOBAL: ArenaAllocator = unsafe { ArenaAllocator::new(1024 * 1024 * 10) }; // 10 MB Arena

fn main() {
    // Initialize the dhat profiler.
    // This intercepts all global allocations (including those in our Arena setup).
    let _profiler = dhat::Profiler::new_heap();

    println!("Memory Profiling initialized. Running with 10MB Arena...");

    // Initialize the pipeline
    let pipeline = InferencePipeline::new(32, 5); // Batch size 32, dummy model size

    // Run the pipeline
    // Note: The `dhat` profiler will track allocations made by `System.alloc` 
    // (inside our Arena's `new`) and any fallback allocations.
    pipeline.run();

    // Manual reset of the arena to demonstrate cleanup
    // In a real server, this happens at the end of a request.
    unsafe { GLOBAL.reset(); }

    println!("Arena reset. Usage: {} bytes", GLOBAL.usage());

    // dhat automatically reports statistics when the _profiler goes out of scope (drops).
    // To view the report, run: `cargo run --release` (recommended for accurate timing).
}
