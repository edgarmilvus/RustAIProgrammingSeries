
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

// Cargo.toml dependencies:
// [dependencies]
// dhat = "0.3"

use dhat::Dhat;

fn main() {
    // Initialize the dhat profiler.
    // It will automatically generate a report when `_dhat` goes out of scope.
    let _dhat = Dhat::start_heap_profiling();

    // Simulate loading 100 chunks of 10MB each.
    // Total raw data: 100 * 10MB = 1000MB.
    let raw_data = load_data_chunks(100);

    // Simulate preprocessing.
    // This converts raw bytes to f32 (4x size increase typically).
    // Total processed data: ~4000MB.
    let processed_data = preprocess(raw_data);

    // Use the data to prevent compiler optimizations from removing the code.
    println!("Processed {} chunks.", processed_data.len());
}

// Simulates reading large binary files from disk.
fn load_data_chunks(count: usize) -> Vec<Vec<u8>> {
    let mut chunks = Vec::with_capacity(count);
    for i in 0..count {
        // Allocate 10MB of data per chunk.
        // In a real scenario, this comes from disk I/O.
        let chunk = vec
![i as u8; 10 * 1024 * 1024];
        chunks.push(chunk)
;
    }
    chunks
}

// Simulates converting raw bytes (e.g., u8 images) to normalized f32 tensors.
fn preprocess(raw: Vec<Vec<u8>>) -> Vec<Vec<f32>> {
    raw.into_iter()
        .map(|chunk| {
            // Allocation: New vector for f32s.
            // Size is roughly 4x the input u8 size.
            chunk.into_iter().map(|b| b as f32 / 255.0).collect()
        })
        .collect()
}
