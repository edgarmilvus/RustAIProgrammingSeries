
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.rs
// Description: Solution for Exercise 2
// ==========================================

use std::sync::Mutex;
use std::thread;
use std::time::Duration;

// Global state to simulate a leaky cache.
// This vector will grow indefinitely.
static LEAKY_CACHE: Mutex<Vec<Vec<u8>>> = Mutex::new(Vec::new());

fn main() {
    // Simulate loading a large model (initial baseline memory).
    // 1000 vectors of 1000 f32s (approx 4MB).
    let _model: Vec<Vec<f32>> = vec
![vec![0.0; 1000]; 1000];

    println!("Starting inference loop...");

    for i in 0..1000 {
        // Simulate processing a request.
        // Allocate a buffer (1KB).
        let request_data: Vec<u8> = vec![i as u8; 1024];

        // LEAK: Push to global cache without clearing.
        // In a real app, this might be a logging buffer or a forgotten cache.
        let mut cache = LEAKY_CACHE.lock()
.unwrap();
        cache.push(request_data);

        // Simulate inference work/delay.
        // This slows down execution so the timeline graph is readable.
        thread::sleep(Duration::from_millis(10));
    }

    println!("Inference finished.");
}
