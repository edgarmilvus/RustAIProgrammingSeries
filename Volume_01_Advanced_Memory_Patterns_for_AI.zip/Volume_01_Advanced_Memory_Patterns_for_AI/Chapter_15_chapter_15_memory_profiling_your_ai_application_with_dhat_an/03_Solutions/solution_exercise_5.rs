
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.rs
// Description: Solution for Exercise 5
// ==========================================

use std::sync::Mutex;

static LEAK_DETECTOR: Mutex<Vec<Vec<u8>>> = Mutex::new(Vec::new());

fn process_data(data: &[u8]) {
    // Large allocation: 1024x the input length
    let mut buffer = vec
![0u8; data.len() * 1024];
    buffer[0] = 1; // Use buffer to prevent optimization

    // Conditional leak: Only if length is odd
    if data.len()
 % 2 != 0 {
        let mut cache = LEAK_DETECTOR.lock().unwrap();
        cache.push(buffer); // Move buffer into static cache
    }
    // If length is even, buffer drops here and memory is freed
}

fn main() {
    let inputs = vec
![
        vec![1, 2, 3],    // Odd length (3) -> Leak
        vec![1, 2, 3, 4], // Even length (4) -> No Leak
        vec![5, 6, 7],    // Odd length (3) -> Leak
    ];

    for input in inputs {
        process_data(&input)
;
    }
}
