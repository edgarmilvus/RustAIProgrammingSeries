
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.rs
// Description: Solution for Exercise 4
// ==========================================

use std::alloc::{alloc, dealloc, Layout};

// Constants for slab configuration
const SMALL_SIZE: usize = 1024; // Threshold for small vs large
const SLAB_CAPACITY: usize = 100; // Number of small slots

/// Optimized allocator using Arena for large blocks and Slab for small blocks.
pub struct OptimizedAllocator {
    // Arena for large allocations
    arena: Vec<u8>,
    arena_offset: usize,
    
    // Slab for small allocations
    slab: Vec<u8>,
    slab_bitmap: Vec<bool>, // Tracks used/free slots
    slot_size: usize,
}

impl OptimizedAllocator {
    pub fn new(arena_size: usize, slot_size: usize) -> Self {
        Self {
            arena: vec
![0; arena_size],
            arena_offset: 0,
            slab: vec![0; SLAB_CAPACITY * slot_size],
            slab_bitmap: vec![false; SLAB_CAPACITY],
            slot_size,
        }
    }

    /// Allocates memory. Routes small requests to slab, large to arena.
    pub fn allocate(&mut self, size: usize) -> Option<*mut u8> {
        if size <= self.slot_size {
            // Small allocation: Use Slab
            // Find a free slot
            if let Some(index) = self.slab_bitmap.iter()
.position(|&used| !used) {
                self.slab_bitmap[index] = true;
                let ptr = self.slab.as_mut_ptr() as usize + (index * self.slot_size);
                return Some(ptr as *mut u8);
            } else {
                println!("Slab full! Falling back to arena or failing.");
                return None;
            }
        } else {
            // Large allocation: Use Arena
            if self.arena_offset + size > self.arena.len() {
                return None; // Out of memory in arena
            }
            let ptr = self.arena.as_mut_ptr() as usize + self.arena_offset;
            self.arena_offset += size;
            return Some(ptr as *mut u8);
        }
    }

    /// Deallocates memory (simplified for this example).
    /// In a real slab, we just mark the bitmap as false.
    /// For the arena, we typically don't reclaim individual blocks (bump allocator logic).
    pub fn deallocate(&mut self, ptr: *mut u8, size: usize) {
        if size <= self.slot_size {
            // Calculate which slot this pointer belongs to
            let base = self.slab.as_mut_ptr() as usize;
            let offset = ptr as usize - base;
            let index = offset / self.slot_size;
            
            if index < SLAB_CAPACITY {
                self.slab_bitmap[index] = false;
            }
        }
        // Arena deallocations are ignored in this simple bump allocator model
    }
}

// Usage Example (for context)
fn main() {
    let mut allocator = OptimizedAllocator::new(1024 * 1024, 64); // 1MB arena, 64B slots

    // Allocate a small buffer (goes to slab)
    let small_ptr = allocator.allocate(50).unwrap();
    
    // Allocate a large buffer (goes to arena)
    let large_ptr = allocator.allocate(2048).unwrap();

    // Deallocate small (marks slab slot free)
    unsafe {
        allocator.deallocate(small_ptr, 50);
    }
}
