
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.rs
// Description: Solution for Exercise 3
// ==========================================

// In lib.rs or a new module profiling.rs

use dhat::{Dhat, DhatAlloc};
use std::fs::File;
use std::io::{self, Write};

/// A wrapper around `dhat` providing scoped memory profiling for library users.
pub struct MemoryProfiler {
    // We hold the Dhat instance to keep the profiler alive.
    _inner: Dhat,
}

impl MemoryProfiler {
    /// Starts the heap profiler.
    /// Note: Only one profiler can be active at a time per process.
    pub fn start() -> Self {
        let inner = Dhat::start_heap_profiling();
        MemoryProfiler { _inner: inner }
    }

    /// Stops the profiler and dumps the report to the specified path.
    pub fn stop_and_dump(&self, _path: &str) {
        // In a real implementation, we might need to manually trigger 
        // dhat's report generation or rely on Drop. 
        // Since Dhat reports on Drop, we can't easily "stop and dump" 
        // without dropping the instance. 
        // For this exercise, we acknowledge that Dhat's design 
        // typically dumps on drop.
        println!("Profiler stopped. (Report generated on drop)");
    }

    /// Creates a scoped profiler that runs for the lifetime of the returned guard.
    /// This is ideal for measuring specific operations like `dataset.map`.
    pub fn scope(name: &str) -> ScopedProfiler {
        ScopedProfiler::new(name)
    }
}

/// A guard that starts profiling on creation and stops/dumps on drop.
pub struct ScopedProfiler {
    _inner: Dhat, // Holds the profiler active
    name: String,
}

impl ScopedProfiler {
    fn new(name: &str) -> Self {
        // Switch to the global allocator used by dhat
        // Note: This requires the `dhat-alloc` feature or global allocator setup.
        // For simplicity in a library context, we assume the user has set up 
        // the global allocator or we are using the Dhat wrapper correctly.
        
        // In a real library, we might need to ensure we are the only profiler.
        let inner = Dhat::start_heap_profiling();
        
        Self {
            _inner: inner,
            name: name.to_string(),
        }
    }
}

impl Drop for ScopedProfiler {
    fn drop(&mut self) {
        // When this guard goes out of scope, `_inner` is dropped.
        // Dhat automatically generates the report at this point.
        // In a more complex implementation, we might rename the output file 
        // based on `self.name`.
        println!("Profiling scope '{}' ended. Report generated.", self.name);
    }
}

// --- Usage Example ---

// Mock Dataset struct for the example
pub struct Dataset;
impl Dataset {
    pub fn map<F>(&self, _f: F) { /* ... */ }
}

pub fn usage_example() {
    let dataset = Dataset;
    
    // User code: Profile the map operation
    {
        let _profiler = MemoryProfiler::scope("dataset_map_operation");
        
        // Perform the operation
        dataset.map(|x| x); 
    } // _profiler drops here, generating the report for this scope.
}
