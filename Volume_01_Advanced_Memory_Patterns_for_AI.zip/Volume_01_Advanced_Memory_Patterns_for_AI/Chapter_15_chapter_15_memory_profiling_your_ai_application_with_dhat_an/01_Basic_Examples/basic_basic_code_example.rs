
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

use dhat::{Dhat, DhatAlloc};
use rand::Rng;
use std::time::Instant;

/// We override the global allocator with `DhatAlloc`.
/// This is the magic switch that enables heap profiling.
/// Every `Box`, `Vec`, or explicit allocation in the program will be tracked.
#[global_allocator]
static ALLOCATOR: DhatAlloc = DhatAlloc;

/// Represents a single batch of data in our AI pipeline.
/// In a real scenario, this might hold tensor data.
struct DataBatch {
    id: usize,
    /// A large vector of floats simulating high-dimensional data (e.g., 1024-dim embeddings).
    data: Vec<f32>,
}

impl DataBatch {
    /// Creates a new batch with randomized data.
    fn new(id: usize, size: usize) -> Self {
        let mut rng = rand::thread_rng();
        // Allocation 1: The Vec allocates memory on the heap.
        let data: Vec<f32> = (0..size).map(|_| rng.gen::<f32>()).collect();
        
        DataBatch { id, data }
    }

    /// Simulates a memory-intensive transformation (e.g., normalization).
    /// This method allocates a temporary buffer, increasing heap pressure.
    fn normalize(&mut self) {
        // Allocation 2: A temporary vector is created for the calculation.
        // This is a common pattern that can cause spikes in memory usage.
        let mean = self.data.iter().sum::<f32>() / self.data.len() as f32;
        let std_dev = (self.data.iter().map(|x| (x - mean).powi(2)).sum::<f32>() / self.data.len() as f32).sqrt();
        
        // In-place modification to avoid keeping the temporary buffer alive.
        // However, the calculation above still allocated temporary iterators/values.
        for x in self.data.iter_mut() {
            *x = (*x - mean) / std_dev;
        }
    }
}

/// Simulates the AI training/inference loop.
/// 
/// # Arguments
/// * `batch_size` - How many items to process at once.
/// * `data_dim` - The dimensionality of the data vectors.
fn run_pipeline(batch_size: usize, data_dim: usize) {
    let total_items = 10_000;
    let mut processed_count = 0;
    
    // Allocation 3: A vector to hold processed results (simulating a metrics buffer).
    // In a real app, this might be a log buffer or a gradient accumulator.
    let mut metrics_buffer = Vec::with_capacity(total_items / batch_size);

    println!("Starting data pipeline processing {} items...", total_items);

    while processed_count < total_items {
        // Allocation 4: Creating the batch itself.
        // The `DataBatch` struct lives on the stack, but `data` lives on the heap.
        let mut batch = DataBatch::new(processed_count, data_dim);
        
        // Perform the computation.
        batch.normalize();

        // Simulate saving metrics.
        // Allocation 5: Pushing to the metrics buffer.
        metrics_buffer.push(batch.id);

        // Allocation 6 (PITFALL): 
        // We might accidentally keep 'heavy' data alive longer than needed.
        // Here, we clone the ID just to show a pattern, but imagine if we 
        // accidentally kept a reference to `batch.data` here.
        let _id_copy = batch.id;

        processed_count += batch_size;
        
        // Allocation 7: The `batch` variable goes out of scope here.
        // The `Vec<f32>` inside it is dropped, freeing the heap memory.
        // However, `dhat` tracks the peak usage during this scope.
    }

    // Allocation 8: The metrics buffer persists until the function ends.
    println!("Processed {} batches. Metrics count: {}", processed_count / batch_size, metrics_buffer.len());
}

fn main() {
    // Initialize the heap profiler.
    // This sets up the hooks for tracking allocations.
    let _dhat = Dhat::start_heap_profiling();

    let start = Instant::now();

    // Run the simulation with specific parameters.
    // 1000 items per batch, 1024 floats per item.
    // This creates significant heap activity.
    run_pipeline(1000, 1024);

    let duration = start.elapsed();
    println!("Pipeline finished in {:?}", duration);

    // The `_dhat` variable is dropped here.
    // Upon drop, `dhat` generates the heap profile report to stderr.
    // This report is what we will analyze in the next section.
}
