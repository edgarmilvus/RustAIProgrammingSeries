
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.rs
// Description: Solution for Exercise 3
// ==========================================

use std::cell::RefCell;

pub struct WeightMatrix {
    data: RefCell<Vec<f32>>,
}

impl WeightMatrix {
    pub fn new(data: Vec<f32>) -> Self {
        Self { data: RefCell::new(data) }
    }

    pub fn normalize(&self) {
        // PHASE 1: Calculate Statistics (Read Access)
        let (mean, std_dev) = {
            // borrow() returns a Ref<T> guard.
            // We limit its scope with a block.
            let data_ref = self.data.borrow();
            
            if data_ref.is_empty() {
                return;
            }

            let sum: f32 = data_ref.iter().sum();
            let mean = sum / data_ref.len() as f32;
            
            let variance = data_ref.iter()
                .map(|value| (value - mean).powi(2))
                .sum::<f32>() / data_ref.len() as f32;
            let std_dev = variance.sqrt();

            (mean, std_dev)
        }; // 'data_ref' is dropped here, releasing the immutable borrow.

        // PHASE 2: Mutate Data (Write Access)
        // If we didn't drop the guard above, this next line would panic.
        let mut data_mut = self.data.borrow_mut();

        // Avoid division by zero
        if std_dev > 0.0 {
            for val in data_mut.iter_mut() {
                *val = (*val - mean) / std_dev;
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_normalize() {
        let wm = WeightMatrix::new(vec
![2.0, 4.0, 6.0])
;
        wm.normalize();
        // Mean = 4.0, StdDev = sqrt((4+0+4)/3) = sqrt(2.66) approx 1.63
        // (2-4)/1.63 = -1.22
        let result = wm.data.borrow();
        assert!((result[0] + 1.224).abs() < 0.01);
    }
}
