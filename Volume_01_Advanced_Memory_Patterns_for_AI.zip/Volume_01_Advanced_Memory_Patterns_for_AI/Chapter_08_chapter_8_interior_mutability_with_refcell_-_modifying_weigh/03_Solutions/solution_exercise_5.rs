
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.rs
// Description: Solution for Exercise 5
// ==========================================

use std::cell::{Cell, RefCell};

// --- Version A: Using RefCell (Overkill for Copy types) ---
pub struct OptimizerConfigRefCell {
    learning_rate: RefCell<f32>,
    momentum: RefCell<f32>,
    batch_size: RefCell<usize>,
}

impl OptimizerConfigRefCell {
    pub fn decay_learning_rate(&self) {
        // Requires getting a mutable reference guard
        let mut lr = self.learning_rate.borrow_mut();
        *lr *= 0.9; // Decay by 10%
    }

    pub fn get_lr(&self) -> f32 {
        *self.learning_rate.borrow()
    }
}

// --- Version B: Using Cell (Optimized for Copy types) ---
pub struct OptimizerConfigCell {
    learning_rate: Cell<f32>,
    momentum: Cell<f32>,
    batch_size: Cell<usize>,
}

impl OptimizerConfigCell {
    pub fn decay_learning_rate(&self) {
        // No borrow() needed. Cell provides safe mutation via &self.
        let current = self.learning_rate.get();
        self.learning_rate.set(current * 0.9);
    }

    pub fn get_lr(&self) -> f32 {
        self.learning_rate.get()
    }
}

// --- Comparison / Analysis ---
/*
 * 1. Efficiency: 
 *    - Cell is more efficient for Copy types (f32, usize). 
 *    - RefCell uses a "borrow flag" to track active borrows at runtime (checking for 
 *      active mutable/immutable borrows). This adds a small runtime overhead.
 *    - Cell simply copies the value in and out. No runtime borrow checking overhead.
 * 
 * 2. Access:
 *    - Cell allows getting the value via .get() immediately.
 *    - RefCell returns a Guard object (Ref or RefMut). The value is only accessible 
 *      while that guard is alive.
 * 
 * 3. Non-Copy Types (String, Vec):
 *    - Cell cannot hold non-Copy types because .get() would require copying the 
 *      entire data structure, which is expensive or impossible for heap-allocated data.
 *    - RefCell is required for non-Copy types because it allows moving data in and out 
 *      or borrowing references to it without copying.
 */
