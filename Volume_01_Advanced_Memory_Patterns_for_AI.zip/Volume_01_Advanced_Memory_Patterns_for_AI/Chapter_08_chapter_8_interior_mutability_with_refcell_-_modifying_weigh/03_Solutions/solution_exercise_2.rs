
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.rs
// Description: Solution for Exercise 2
// ==========================================

use std::cell::RefCell;
use std::rc::Rc;

#[derive(Debug, Clone)]
pub struct NodeData {
    pub value: f32,
}

pub struct Node {
    pub data: Rc<RefCell<NodeData>>,
    pub children: Vec<Rc<Node>>,
}

impl Node {
    pub fn new(value: f32) -> Rc<Self> {
        Rc::new(Node {
            data: Rc::new(RefCell::new(NodeData { value })),
            children: Vec::new(),
        })
    }

    pub fn add_child(parent: &Rc<Node>, child: Rc<Node>) {
        // Since parent is Rc, we can clone it to push to children
        // Note: In a real scenario, we might want to avoid circular references
        // to prevent memory leaks (unless using Weak pointers).
        Rc::get_mut(parent)
            .unwrap() // Safe here because we are building the graph
            .children
            .push(child);
    }

    /// Propagates value to children.
    /// Takes &self, requiring interior mutability for children.
    pub fn propagate(&self) {
        // 1. Read own value (Immutably)
        let own_value = self.data.borrow().value;

        // 2. Iterate children
        for child in &self.children {
            // 3. Mutate child data
            // borrow_mut() creates a RefMut guard. 
            // This works because 'self' is borrowed immutably, 
            // but 'self' does not own 'child.data', it only holds a reference to it.
            child.data.borrow_mut().value += own_value;
            
            // Recursively propagate
            child.propagate();
        }
    }
}

// Note: To visualize with Graphviz, one would iterate the nodes 
// and print "Parent -> Child" lines.
