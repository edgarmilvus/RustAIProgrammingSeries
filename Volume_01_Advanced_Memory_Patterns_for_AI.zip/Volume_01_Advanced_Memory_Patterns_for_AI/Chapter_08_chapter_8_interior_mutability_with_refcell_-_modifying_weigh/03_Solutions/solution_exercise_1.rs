
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

// Dependencies:
// [dependencies]
// rand = "0.8"

use std::cell::RefCell;

pub struct Weights {
    // We use RefCell to allow mutable access to the vector
    // even when the Weights struct is borrowed immutably.
    data: RefCell<Vec<f32>>,
}

impl Weights {
    /// Initializes weights with a fixed small value (0.1) for determinism.
    pub fn new(dim: usize) -> Self {
        let data = vec
![0.1; dim];
        Self {
            data: RefCell::new(data)
,
        }
    }

    /// Updates the internal weights by adding the gradient.
    /// Takes &self, but modifies internal data via RefCell::borrow_mut().
    pub fn update(&self, gradient: &[f32]) {
        // We request a mutable borrow of the inner data.
        // This will panic if an immutable borrow is currently active.
        let mut weights = self.data.borrow_mut();
        
        assert_eq!(weights.len(), gradient.len(), "Gradient length must match weights length");

        for (w, g) in weights.iter_mut().zip(gradient.iter()) {
            *w += *g;
        }
    }

    /// Helper to inspect data for testing
    pub fn get_data(&self) -> Vec<f32> {
        self.data.borrow().clone()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_interior_mutability() {
        // The layer owns the weights, but we want to share it immutably.
        let weights = Weights::new(3);
        
        // Create an immutable reference (simulating shared access)
        let immutable_ref = &weights;
        
        // We can update via the immutable reference!
        let gradient = vec
![0.5, 0.5, 0.5];
        immutable_ref.update(&gradient)
;

        let result = weights.get_data();
        assert_eq!(result, vec
![0.6, 0.6, 0.6]);
    }
}
