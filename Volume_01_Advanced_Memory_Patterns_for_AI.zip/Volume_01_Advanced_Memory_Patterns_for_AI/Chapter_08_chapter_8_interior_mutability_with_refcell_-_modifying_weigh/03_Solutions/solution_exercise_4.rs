
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.rs
// Description: Solution for Exercise 4
// ==========================================

use std::cell::RefCell;
use std::rc::Rc;

// --- Library ---

pub struct Layer {
    pub weights: Rc<RefCell<Vec<f32>>>,
}

pub struct Model {
    pub layers: Vec<Layer>,
}

impl Model {
    // Simulates loading from a binary file
    pub fn load() -> Self {
        // Dummy data: 2 layers, layer 0 has 3 weights
        let l0_weights = Rc::new(RefCell::new(vec
![1.0, 1.0, 1.0])
);
        let l1_weights = Rc::new(RefCell::new(vec
![2.0, 2.0])
);
        
        Model {
            layers: vec
![
                Layer { weights: l0_weights }
,
                Layer { weights: l1_weights },
            ],
        }
    }

    // Applies a patch: sets all weights in a layer to a value.
    // Takes &self, simulating the immutable requirement.
    pub fn patch_layer(&self, layer_idx: usize, value: f32) -> Result<(), String> {
        if layer_idx >= self.layers.len() {
            return Err("Layer index out of bounds".to_string());
        }

        // Access the specific layer
        let layer = &self.layers[layer_idx];
        
        // Interior mutability allows modification
        let mut weights = layer.weights.borrow_mut();
        for w in weights.iter_mut() {
            *w = value;
        }

        Ok(())
    }

    pub fn get_layer_sum(&self, layer_idx: usize) -> f32 {
        let layer = &self.layers[layer_idx];
        let weights = layer.weights.borrow();
        weights.iter().sum()
    }
}

// --- CLI Main (Simulated) ---

/*
fn main() {
    let args: Vec<String> = env::args().collect();
    let model = Model::load(); // Immutable load

    // Command: patch <index> <value>
    if args[1] == "patch" {
        let idx: usize = args[2].parse().unwrap();
        let val: f32 = args[3].parse().unwrap();
        
        // We can call patch_layer on an immutable reference
        match model.patch_layer(idx, val) {
            Ok(_) => println!("Layer {} patched successfully.", idx),
            Err(e) => println!("Error: {}", e),
        }
    }
    // Command: status <index>
    else if args[1] == "status" {
        let idx: usize = args[2].parse().unwrap();
        let sum = model.get_layer_sum(idx);
        println!("Layer {} weight sum: {:.1}", idx, sum);
    }
}
*/
