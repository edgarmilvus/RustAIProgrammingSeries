
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

use std::cell::RefCell;
use std::rc::Rc;
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;

/// Represents a single neuron or node in the computational graph.
/// It holds a weight vector. We use `RefCell` to allow mutation of the weights
/// even when the `Node` is held immutably by the graph structure.
#[derive(Debug)]
struct Node {
    id: usize,
    weights: RefCell<Vec<f32>>,
}

impl Node {
    /// Creates a new node with initialized weights.
    fn new(id: usize, weight_size: usize) -> Rc<Self> {
        // Initialize with dummy weights (e.g., all 0.5)
        let weights = vec
![0.5; weight_size];
        Rc::new(Node {
            id,
            weights: RefCell::new(weights)
,
        })
    }

    /// Performs a forward pass calculation (mock inference).
    /// This requires an immutable borrow of the Node, but `RefCell` allows
    /// runtime interior mutability if needed (though here we just read).
    fn forward(&self, input: &[f32]) -> f32 {
        let weights = self.weights.borrow(); // Immutable borrow
        input.iter().zip(weights.iter()).map(|(i, w)| i * w).sum()
    }

    /// Updates the weights based on a gradient.
    /// This is the critical interior mutability pattern. We take `&self` (immutable reference)
    /// but mutate the inner data via `borrow_mut()`.
    fn update_weights(&self, gradients: &[f32]) {
        // `borrow_mut()` returns a RefMut guard. 
        // It panics if a borrow is already active (prevents data races at runtime).
        let mut weights = self.weights.borrow_mut();
        
        assert_eq!(weights.len(), gradients.len(), "Gradient dimension mismatch");
        
        for (w, g) in weights.iter_mut().zip(gradients.iter()) {
            *w -= 0.01 * g; // Simple gradient descent step
        }
        
        println!("[Node {}] Weights updated via interior mutation.", self.id);
    }
}

/// Represents a connection between two nodes in the DAG.
/// In a real system, this might hold an adjacency matrix or edge list.
/// Here, we simply store references to source and destination nodes.
struct Edge {
    source: Rc<Node>,
    dest: Rc<Node>,
}

/// The computational graph. 
/// It owns the edges, but the nodes are shared via `Rc`.
/// The graph itself is immutable once built, but the nodes are mutable.
struct ComputationalGraph {
    edges: Vec<Edge>,
    // We might also keep a list of input nodes for reference
    input_nodes: Vec<Rc<Node>>,
}

impl ComputationalGraph {
    fn new() -> Self {
        ComputationalGraph {
            edges: Vec::new(),
            input_nodes: Vec::new(),
        }
    }

    /// Adds a node to the graph (as an input source).
    fn add_input_node(&mut self, node: Rc<Node>) {
        self.input_nodes.push(node);
    }

    /// Connects two existing nodes.
    fn connect(&mut self, source: Rc<Node>, dest: Rc<Node>) {
        self.edges.push(Edge { source, dest });
    }

    /// Runs inference across the graph.
    /// Note: This iterates edges. In a real DAG, we'd use topological sort.
    fn run_inference(&self, input_data: &[f32]) {
        println!("--- Running Inference ---");
        for edge in &self.edges {
            // We borrow nodes immutably here.
            let output = edge.dest.forward(input_data);
            println!("Node {} processed input: {:.4}", edge.dest.id, output);
        }
    }

    /// Updates weights in the graph.
    /// This simulates a training step. We iterate through edges (nodes)
    /// and apply the update. Because `Node` uses `RefCell`, we can call
    /// `update_weights` using only an immutable reference to the graph.
    fn propagate_update(&self, gradients: &[f32]) {
        println!("--- Propagating Updates (Async) ---");
        for edge in &self.edges {
            // We only have `&self` here, yet we mutate the node's weights.
            // This is the power of interior mutability.
            edge.dest.update_weights(gradients);
        }
    }
}

/// A mock parameter server that manages the graph and handles update requests.
/// In a real system, this would listen on a socket or message queue.
struct ParameterServer {
    graph: Arc<ComputationalGraph>, // Shared ownership across threads
}

impl ParameterServer {
    fn new(graph: ComputationalGraph) -> Self {
        ParameterServer {
            graph: Arc::new(graph),
        }
    }

    /// Starts the server loops: one for inference, one for updates.
    /// We use threads to demonstrate that `Rc<RefCell<T>>` is not `Send`,
    /// so we wrap the graph in `Arc` (Atomic Reference Counted) for thread safety,
    /// but the internal nodes rely on `Rc` and `RefCell` for local mutation logic.
    fn start(self) {
        // Clone the Arc to move into the inference thread
        let inference_graph = self.graph.clone();
        
        // Clone the Arc to move into the update thread
        let update_graph = self.graph.clone();

        // Thread 1: Simulates high-throughput inference requests
        let inference_handle = thread::spawn(move || {
            let input = vec
![1.0, 2.0, 3.0];
            for _ in 0..3 {
                inference_graph.run_inference(&input)
;
                thread::sleep(Duration::from_millis(500));
            }
        });

        // Thread 2: Simulates an external training loop sending updates
        let update_handle = thread::spawn(move || {
            // Wait a bit for inference to start
            thread::sleep(Duration::from_millis(250));
            
            let gradients = vec
![0.1, 0.2, 0.3];
            for i in 0..3 {
                println!("Update Cycle {} received...", i + 1)
;
                // This calls into the graph, which calls into nodes, mutating RefCells.
                update_graph.propagate_update(&gradients);
                thread::sleep(Duration::from_millis(1000));
            }
        });

        inference_handle.join().unwrap();
        update_handle.join().unwrap();
    }
}

fn main() {
    // 1. Construct the graph topology
    let mut graph = ComputationalGraph::new();

    // 2. Create nodes. We use Rc so they can be shared across the graph structure.
    let n1 = Node::new(1, 3);
    let n2 = Node::new(2, 3);
    let n3 = Node::new(3, 3);

    // 3. Add nodes and edges
    graph.add_input_node(n1.clone());
    graph.connect(n1.clone(), n2.clone());
    graph.connect(n2.clone(), n3.clone());

    // 4. Initialize the Parameter Server
    let server = ParameterServer::new(graph);

    // 5. Run the server (spawns threads)
    // Note: We cannot pass `Rc` across threads directly. 
    // The `Arc` inside `ParameterServer` handles the thread-safe sharing of the container,
    // while `Rc<RefCell<T>>` handles the interior mutation logic within each thread's context.
    server.start();
}
