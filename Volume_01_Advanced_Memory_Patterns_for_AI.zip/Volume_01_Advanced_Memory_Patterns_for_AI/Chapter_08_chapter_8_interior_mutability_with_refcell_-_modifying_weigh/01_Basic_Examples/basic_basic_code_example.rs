
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

use std::cell::RefCell;
use std::rc::Rc;

/// Represents the parameters (weights) of a neural network layer.
/// In a real scenario, this might hold a large `Vec<f32>` or a tensor.
/// We wrap the data in a `RefCell` to allow mutation even when the struct is borrowed immutably.
#[derive(Debug)]
struct Weights {
    data: Vec<f32>,
}

impl Weights {
    /// Initialize weights with zeros.
    fn new(size: usize) -> Self {
        Weights {
            data: vec
![0.0; size],
        }
    }

    /// A method to simulate updating weights (e.g., during training or calibration)
.
    /// This requires a mutable reference to `self`.
    fn update(&mut self, new_values: &[f32]) {
        for (i, &val) in new_values.iter().enumerate() {
            if i < self.data.len() {
                self.data[i] = val;
            }
        }
    }

    /// Perform a forward pass calculation (simplified).
    /// This only requires an immutable reference.
    fn forward(&self, input: f32) -> f32 {
        self.data.iter().sum::<f32>() * input
    }
}

/// A node in the computation graph.
/// In this simplified model, a node holds a reference to weights.
/// Note: The `weights` field holds a `RefCell` wrapped in an `Rc`.
/// - `Rc`: Allows multiple nodes to share ownership of the same weights.
/// - `RefCell`: Allows mutating those weights even if the node itself is immutable.
#[derive(Debug)]
struct Layer {
    name: String,
    weights: Rc<RefCell<Weights>>,
}

impl Layer {
    /// Creates a new layer with its own unique weights.
    fn new(name: &str, weight_size: usize) -> Self {
        Layer {
            name: name.to_string(),
            weights: Rc::new(RefCell::new(Weights::new(weight_size))),
        }
    }

    /// Creates a new layer that shares weights with an existing layer.
    /// This is useful for "tied weights" architectures (e.g., autoencoder encoders/decoders).
    fn share_weights(name: &str, shared_weights: &Rc<RefCell<Weights>>) -> Self {
        Layer {
            name: name.to_string(),
            weights: Rc::clone(shared_weights),
        }
    }

    /// Simulates an inference step.
    /// The layer is passed as immutable (`&self`), but it can still access its weights.
    fn run_inference(&self, input: f32) -> f32 {
        // 1. Borrow the inner Weights immutably at runtime.
        //    `borrow()` returns a `Ref<T>` guard.
        let weights_ref = self.weights.borrow();
        
        // 2. Access data through the guard.
        let result = weights_ref.forward(input);
        
        println!(
            "[Inference] Layer '{}' calculated output: {:.4}",
            self.name, result
        );
        result
    }

    /// Simulates a calibration step where weights are updated.
    /// This method takes `&self` (immutable layer), but modifies internal weights.
    fn calibrate(&self, gradients: &[f32]) {
        println!("[Calibration] Updating weights for layer '{}'", self.name);

        // 1. Borrow the inner Weights mutably at runtime.
        //    This returns a `RefMut<T>` guard.
        //    PANICS if a borrow is already active (e.g., if `run_inference` held the guard).
        let mut weights_mut = self.weights.borrow_mut();

        // 2. Mutate the data through the guard.
        weights_mut.update(gradients);
    }
}

/// The computation graph (DAG).
/// This struct holds the layers. In a real scenario, this might be immutable
/// after initialization, but we need to update weights.
struct InferenceGraph {
    layers: Vec<Layer>,
}

impl InferenceGraph {
    fn new() -> Self {
        InferenceGraph { layers: Vec::new() }
    }

    fn add_layer(&mut self, layer: Layer) {
        self.layers.push(layer);
    }

    /// Runs the full graph. 
    /// Note: `&self` is immutable, yet we will trigger internal updates later.
    fn run(&self, input: f32) {
        println!("\n--- Starting Graph Inference ---");
        let mut current_val = input;
        for layer in &self.layers {
            current_val = layer.run_inference(current_val);
        }
        println!("--------------------------------\n");
    }

    /// Updates all layers. 
    /// In a real training loop, this would happen after calculating gradients.
    fn update_all_weights(&self, new_weights: &[f32]) {
        println!("--- Updating Graph Weights ---");
        for layer in &self.layers {
            // Even though `self` is immutable here, `layer.calibrate` 
            // uses interior mutability to modify the shared weights.
            layer.calibrate(new_weights);
        }
        println!("-----------------------------\n");
    }
}

fn main() {
    // 1. Initialize the graph.
    let mut graph = InferenceGraph::new();

    // 2. Create a "Shared" weight matrix.
    // We create it manually to pass to multiple layers.
    let shared_weights = Rc::new(RefCell::new(Weights::new(3)));

    // 3. Add layers.
    // Layer A has its own unique weights.
    graph.add_layer(Layer::new("Layer_A_Unique", 3));
    
    // Layer B shares weights with a separate definition, but we'll also add a layer that ties to `shared_weights`.
    // Let's add a layer that uses the shared weights.
    graph.add_layer(Layer::share_weights("Layer_B_Shared", &shared_weights));

    // 4. Run Inference (Immutable Graph)
    // The graph structure is not changing, only the internal data.
    graph.run(1.0);

    // 5. Update Weights (Interior Mutability in action)
    // We pass new values. The graph `run` method took `&self`, 
    // yet we are modifying the internal state now.
    let new_values = vec
![0.5, 1.0, 1.5];
    graph.update_all_weights(&new_values)
;

    // 6. Run Inference again to verify changes
    // The output should reflect the new weights (0.5 + 1.0 + 1.5 = 3.0 * 1.0 = 3.0)
    graph.run(1.0);

    // 7. Demonstrate Shared Mutability
    // If we modify `shared_weights` directly, `Layer_B_Shared` sees the change immediately.
    println!("--- Direct Modification of Shared Weights ---");
    {
        // We must enter a scope to borrow mutably
        let mut shared_guard = shared_weights.borrow_mut();
        shared_guard.update(&[10.0, 20.0, 30.0]);
    } // Guard drops here, releasing the borrow

    // Run again. Layer A (unique) keeps old values. Layer B (shared) uses new values.
    graph.run(1.0);
}
