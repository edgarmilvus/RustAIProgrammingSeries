
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

// src/main.rs
//! # High-Performance Inference Server with Custom Tensor Arena
//!
//! This application demonstrates a custom arena allocator optimized for AI inference workloads.
//! It simulates a scenario where a neural network processes multiple inputs in a batch, requiring
//! temporary tensors for intermediate layers. Instead of performing expensive heap allocations
//! for each tensor (which causes cache misses and allocator contention), we pre-allocate a large
//! contiguous memory block (the Arena) and sub-allocate from it.
//!
//! Key Features:
//! 1. **Zero-Cost Abstraction**: `TensorView` acts as a lightweight handle to memory within the arena.
//! 2. **Fragmentation-Free**: All allocations are linear; resetting the arena frees everything instantly.
//! 3. **Alignment Aware**: Ensures SIMD-friendly memory alignment for vectorized operations.
//!
//! **Architecture Overview:**
//!
//! 

::: {style="text-align: center"}
![This diagram illustrates the architecture of an Alignment Aware system, highlighting how SIMD-friendly memory alignment is enforced to optimize vectorized operations.](images/b1_c11_s3_diag1.png){width=80% caption="This diagram illustrates the architecture of an Alignment Aware system, highlighting how SIMD-friendly memory alignment is enforced to optimize vectorized operations."}
:::



use std::alloc::{alloc_zeroed, dealloc, Layout};
use std::mem::size_of;
use std::ptr::NonNull;
use std::sync::atomic::{AtomicUsize, Ordering};

// ==============================================================================================
// 1. The Core Memory Arena
// ==============================================================================================

/// A raw, unsafe memory arena that manages a contiguous block of heap memory.
///
/// # Safety
/// This struct does not implement `Drop` intentionally to allow moving ownership
/// of the underlying memory buffer. It relies on `TensorArena` to handle deallocation.
struct RawArena {
    ptr: *mut u8,
    capacity: usize,
    current_offset: AtomicUsize,
}

impl RawArena {
    /// Creates a new arena with a fixed capacity.
    ///
    /// # Arguments
    /// * `capacity` - Total bytes to allocate upfront.
    fn new(capacity: usize) -> Self {
        // We use the Global Allocator to request a large chunk of memory.
        // `alloc_zeroed` is used here to simulate pre-initialized memory (often preferred in AI
        // contexts to avoid NaN issues with uninitialized memory, though slightly slower).
        let layout = Layout::from_size_align(capacity, 64).unwrap(); // 64-byte alignment for AVX-512
        let ptr = unsafe { alloc_zeroed(layout) };

        if ptr.is_null() {
            panic!("Failed to allocate arena memory of size {} bytes", capacity);
        }

        Self {
            ptr,
            capacity,
            current_offset: AtomicUsize::new(0),
        }
    }

    /// Allocates a block of memory of specific size and alignment.
    ///
    /// # Safety
    /// The caller must ensure the returned pointer is valid for the requested layout
    /// and that the arena does not overflow.
    unsafe fn alloc(&self, layout: Layout) -> Option<*mut u8> {
        let current = self.current_offset.load(Ordering::Relaxed);
        
        // Calculate the aligned offset.
        // Formula: (current + (align - 1)) & !(align - 1)
        let align_mask = layout.align() - 1;
        let aligned_offset = (current + align_mask) & !align_mask;
        
        let new_offset = aligned_offset + layout.size();

        // Check for overflow/capacity breach.
        if new_offset > self.capacity {
            return None;
        }

        // Attempt to update the offset atomically.
        // In a multi-threaded context, this ensures thread safety without a mutex.
        match self.current_offset.compare_exchange_weak(
            current,
            new_offset,
            Ordering::SeqCst, // Sequential consistency for safety in this example
            Ordering::Relaxed,
        ) {
            Ok(_) => {
                // Return pointer relative to the base
                Some(self.ptr.add(aligned_offset))
            }
            Err(_) => {
                // Another thread allocated concurrently, retry (simple spin-lock behavior)
                // In production, you might use a backoff strategy or a lock-free retry loop.
                self.alloc(layout)
            }
        }
    }

    /// Resets the arena to the beginning.
    /// This effectively "frees" all memory without deallocating the backing buffer.
    fn reset(&self) {
        self.current_offset.store(0, Ordering::SeqCst);
    }
}

impl Drop for RawArena {
    fn drop(&mut self) {
        if !self.ptr.is_null() {
            let layout = Layout::from_size_align(self.capacity, 64).unwrap();
            unsafe { dealloc(self.ptr, layout) };
        }
    }
}

// ==============================================================================================
// 2. RAII Wrapper and Tensor Views
// ==============================================================================================

/// A handle to memory allocated within a `TensorArena`.
///
/// This acts as a "Smart Pointer" for the arena memory. It encapsulates the raw pointer,
/// type information, and dimensions. It ensures that the memory is accessed safely
/// within bounds.
pub struct TensorView<T> {
    ptr: NonNull<T>,
    len: usize,
    // We hold a reference to the arena to ensure the memory isn't dropped while views exist.
    // In a high-performance scenario, this might be an `Arc<RawArena>` or a lifetime parameter.
    // For this example, we use a reference to demonstrate scope management.
    _arena: *const RawArena, 
}

impl<T> TensorView<T> {
    /// Creates a new view over the allocated memory.
    unsafe fn new(ptr: *mut T, len: usize, arena: *const RawArena) -> Self {
        Self {
            ptr: NonNull::new_unchecked(ptr),
            len,
            _arena: arena,
        }
    }

    /// Returns a slice to the underlying data for safe read access.
    pub fn as_slice(&self) -> &[T] {
        unsafe { std::slice::from_raw_parts(self.ptr.as_ptr(), self.len) }
    }

    /// Returns a mutable slice for safe write access.
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        unsafe { std::slice::from_raw_parts_mut(self.ptr.as_ptr(), self.len) }
    }
}

// Prevent sending raw pointers across threads without care, though `RawArena` is atomic.
unsafe impl<T: Send> Send for TensorView<T> {}
unsafe impl<T: Sync> Sync for TensorView<T> {}

/// The high-level Arena Allocator interface.
/// 
/// This struct manages the lifecycle of the arena, ensuring RAII principles.
pub struct TensorArena {
    raw: RawArena,
}

impl TensorArena {
    /// Creates a new arena with a specific capacity (e.g., 16 MB).
    pub fn new(capacity_bytes: usize) -> Self {
        Self {
            raw: RawArena::new(capacity_bytes),
        }
    }

    /// Allocates a tensor of type `T` with a specific length.
    ///
    /// # Type Parameters
    /// * `T` - The scalar type (e.g., f32, f64).
    ///
    /// # Returns
    /// A `TensorView<T>` if allocation succeeds, otherwise `None`.
    pub fn alloc_tensor<T>(&self, len: usize) -> Option<TensorView<T>> {
        let layout = Layout::array::<T>(len).ok()?;
        
        // Ensure the layout alignment is sufficient for SIMD (e.g., 32 bytes for AVX).
        // We override the alignment if the type is smaller than typical SIMD requirements.
        let layout = layout.align_to(64).unwrap_or(layout);

        let ptr = unsafe { self.raw.alloc(layout) }? as *mut T;
        
        Some(unsafe { TensorView::new(ptr, len, &self.raw as *const RawArena) })
    }

    /// Resets the entire arena, invalidating all active views.
    /// 
    /// # Safety
    /// The caller must ensure no `TensorView` is used after calling this method.
    pub fn reset(&self) {
        self.raw.reset();
    }
}

// ==============================================================================================
// 3. Application Logic: Neural Network Inference Simulation
// ==============================================================================================

/// Simulates a heavy computation (e.g., Matrix Multiplication).
/// In a real scenario, this would use SIMD intrinsics (std::simd) or GPU kernels.
fn simulate_matmul(input: &[f32], weights: &[f32], output: &mut [f32], dims: (usize, usize)) {
    let (rows, cols) = dims;
    // Naive O(N^3) implementation for demonstration
    for i in 0..rows {
        for j in 0..cols {
            let mut sum = 0.0;
            for k in 0..cols { // Assuming square matrices for simplicity
                sum += input[i * cols + k] * weights[k * cols + j];
            }
            output[i * cols + j] = sum;
        }
    }
}

/// Simulates an activation function (e.g., ReLU).
fn simulate_relu(input: &mut [f32]) {
    for val in input.iter_mut() {
        if *val < 0.0 {
            *val = 0.0;
        }
    }
}

/// The main inference engine that utilizes the `TensorArena`.
struct InferenceEngine {
    arena: TensorArena,
    weights: Vec<f32>, // Weights usually live in a persistent memory region
}

impl InferenceEngine {
    pub fn new(arena_capacity: usize) -> Self {
        Self {
            arena: TensorArena::new(arena_capacity),
            weights: (0..1024).map(|i| (i % 10) as f32).collect(), // Dummy weights
        }
    }

    /// Processes a batch of inputs using the arena for intermediates.
    /// 
    /// # Flow
    /// 1. Allocate Input View (Copy data from external source).
    /// 2. Allocate Intermediate Layer 1 View.
    /// 3. Compute (MatMul).
    /// 4. Allocate Intermediate Layer 2 View.
    /// 5. Compute (Activation).
    /// 6. Allocate Output View.
    /// 7. Return Output.
    /// 8. Reset Arena (Clean up all intermediates automatically).
    pub fn run_inference(&mut self, input_data: &[f32]) -> Option<Vec<f32>> {
        const DIM: usize = 32; // 32x32 tensors

        // 1. Allocate Input Tensor in Arena
        // We copy input data into the arena to keep all data locality high.
        let mut t_input = self.arena.alloc_tensor::<f32>(DIM * DIM)?;
        t_input.as_mut_slice().copy_from_slice(input_data);

        // 2. Allocate Layer 1 (Intermediate)
        let mut t_l1 = self.arena.alloc_tensor::<f32>(DIM * DIM)?;

        // 3. Compute Layer 1
        // We borrow slices from the views to perform the operation.
        simulate_matmul(
            t_input.as_slice(), 
            &self.weights, 
            t_l1.as_mut_slice(), 
            (DIM, DIM)
        );

        // 4. Allocate Layer 2 (Intermediate)
        let mut t_l2 = self.arena.alloc_tensor::<f32>(DIM * DIM)?;

        // 5. Compute Layer 2 (Activation)
        // We can modify the previous layer's output directly if we own it, 
        // but here we simulate passing it to a new layer.
        t_l2.as_mut_slice().copy_from_slice(t_l1.as_slice());
        simulate_relu(t_l2.as_mut_slice());

        // 6. Allocate Output
        let t_out = self.arena.alloc_tensor::<f32>(DIM * DIM)?;
        
        // 7. Finalize
        // In a real app, we might copy this result out to the user.
        let result = t_out.as_slice().to_vec();

        // 8. CLEANUP
        // By resetting the arena, we invalidate all views (t_input, t_l1, t_l2, t_out).
        // The memory is now ready for the next request instantly.
        self.arena.reset();

        Some(result)
    }
}

fn main() {
    println!("Initializing High-Performance Inference Engine...");
    
    // Initialize engine with a 16MB arena.
    // This is enough for many concurrent inferences without touching the global allocator.
    let mut engine = InferenceEngine::new(16 * 1024 * 1024);

    // Generate dummy input data (32x32)
    let input_data: Vec<f32> = (0..1024).map(|i| (i % 5) as f32).collect();

    println!("Running Inference Batch...");
    let start = std::time::Instant::now();

    // Simulate processing a high-throughput stream of requests
    for i in 0..1000 {
        let result = engine.run_inference(&input_data);
        
        if i == 0 {
            // Print first result to verify correctness
            if let Some(res) = result {
                println!("First result sample: {:.2?}", &res[0..5]);
            }
        }
    }

    let duration = start.elapsed();
    println!("Processed 1000 inferences in {:?}", duration);
    println!("Average time per inference: {:?}", duration / 1000);
    println!("Arena allocations were zero-cost after the first warm-up.");
}
