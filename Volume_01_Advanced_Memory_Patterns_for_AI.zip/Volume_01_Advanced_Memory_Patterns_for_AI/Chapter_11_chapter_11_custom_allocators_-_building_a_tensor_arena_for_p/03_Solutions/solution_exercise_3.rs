
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.rs
// Description: Solution for Exercise 3
// ==========================================

use std::alloc::{GlobalAlloc, Layout};
use std::cell::RefCell;

// --- GlobalAlloc Implementation ---
// Note: This implementation is inherently unsafe because GlobalAlloc requires
// thread-safe synchronization, which our simple TensorArena does not provide.
// We mark it as unsafe and rely on the user to ensure it's only used in a
// single-threaded or properly synchronized context (like our thread-local guard).
unsafe impl GlobalAlloc for TensorArena {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        let align = layout.align();

        // We need mutable access to the arena's offset, but `alloc` takes `&self`.
        // This is a major limitation. In a real-world scenario, we would use an
        // AtomicUsize for the offset or a Mutex. For this exercise, we use a
        // RefCell in our thread-local wrapper to get interior mutability.
        // Here, we'll assume the caller handles the mutability, but for a true
        // GlobalAlloc, we'd need a different design (e.g., a separate state struct).
        
        // Since we cannot modify `self.offset` in `&self`, this implementation
        // is a placeholder to show the logic. A production-ready version would
        // require a thread-safe interior (e.g., `AtomicUsize`).
        // For the purpose of this exercise, we will demonstrate the usage pattern
        // via the `run_with_arena` helper, which uses `RefCell` for mutability.
        
        // Placeholder: return a null pointer to indicate failure in this unsafe context
        // without a proper interior mutable state.
        std::ptr::null_mut()
    }

    unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {
        // Arena allocators do not support individual deallocation.
        // Memory is reclaimed en masse via `reset`.
    }
}

// --- Thread-Local Arena ---
thread_local! {
    static ARENA: RefCell<TensorArena> = RefCell::new(TensorArena::new(1024 * 1024)); // 1MB arena
}

/// A helper function to run a closure with a thread-local arena.
/// This pattern is safer than implementing GlobalAlloc for a non-thread-safe type.
pub fn run_with_arena<F>(f: F)
where
    F: FnOnce(),
{
    // The closure `f` is executed while the arena is borrowed.
    // All allocations happen within this closure's scope.
    ARENA.with(|arena_cell| {
        // We reset the arena at the start of the scope to ensure a clean state.
        arena_cell.borrow_mut().reset();
        
        // In a real scenario, we would set this arena as the global allocator here.
        // However, doing so is complex and requires a `&'static` reference.
        // Instead, we pass the arena handle to the closure or use a scoped allocator.
        // For this exercise, we'll assume the closure uses the arena via a handle.
        
        // To make it usable, we need to pass the arena handle to the closure.
        // Let's redefine the signature slightly for practicality.
    });
}

// A more practical version of `run_with_arena` that passes the arena handle.
pub fn run_with_arena_handle<F>(f: F)
where
    F: FnOnce(&RefCell<TensorArena>),
{
    ARENA.with(|arena_cell| {
        // Reset for a clean slate
        arena_cell.borrow_mut().reset();
        
        // Execute the user's logic
        f(arena_cell);
        
        // The arena is automatically reset when the RefCell borrow ends,
        // but we can explicitly reset it here for clarity.
        arena_cell.borrow_mut().reset();
    });
}

/// Example computation function that uses the arena.
/// This function would be called from within `run_with_arena_handle`.
pub fn compute_layer(arena: &RefCell<TensorArena>) {
    let mut arena_borrow = arena.borrow_mut();
    
    // Allocate tensors using the arena's safe method.
    // In a true GlobalAlloc scenario, we would use std::alloc::alloc(Layout).
    let input_ptr = arena_borrow.allocate::<f32>(256);
    let weights_ptr = arena_borrow.allocate::<f32>(512);
    let output_ptr = arena_borrow.allocate::<f32>(128);

    println!("Allocated tensors at offsets relative to arena base.");
    println!("Arena offset after allocations: {}", arena_borrow.offset);
}
