
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.rs
// Description: Solution for Exercise 4
// ==========================================

// This solution is a complete, runnable binary.
// To run: `cargo run -- alloc u32 100 alloc f32 50 reset alloc u8 200`
// To generate Graphviz: `cargo run -- alloc u32 100 alloc f32 50 reset alloc u8 200 --dot`

use std::env;
use std::mem::{align_of, size_of};

// --- Simulation Engine ---

#[derive(Debug, Clone)]
struct Block {
    start: usize,
    end: usize,
    label: String,
    block_type: BlockType,
}

#[derive(Debug, Clone, PartialEq)]
enum BlockType {
    Padding,
    Allocated,
    Free,
}

struct ArenaSimulator {
    capacity: usize,
    offset: usize,
    layout_log: Vec<Block>, // To store the history of blocks for visualization
}

impl ArenaSimulator {
    fn new(capacity: usize) -> Self {
        Self {
            capacity,
            offset: 0,
            layout_log: Vec::new(),
        }
    }

    fn allocate(&mut self, type_str: &str, count: usize) {
        let (size, align, type_name) = match type_str {
            "u8" => (size_of::<u8>(), align_of::<u8>(), "u8"),
            "u32" => (size_of::<u32>(), align_of::<u32>(), "u32"),
            "f32" => (size_of::<f32>(), align_of::<f32>(), "f32"),
            "f64" => (size_of::<f64>(), align_of::<f64>(), "f64"),
            _ => {
                eprintln!("Unknown type: {}", type_str);
                return;
            }
        };

        let data_size = size * count;
        let align = align;

        // Calculate padding
        let aligned_offset = (self.offset + align - 1) & !(align - 1);
        let padding = aligned_offset - self.offset;

        // Check capacity
        if aligned_offset + data_size > self.capacity {
            eprintln!("Allocation failed: not enough capacity.");
            return;
        }

        // Log padding block if any
        if padding > 0 {
            self.layout_log.push(Block {
                start: self.offset,
                end: aligned_offset - 1,
                label: format!("Padding: {} bytes", padding),
                block_type: BlockType::Padding,
            });
        }

        // Log allocated block
        self.layout_log.push(Block {
            start: aligned_offset,
            end: aligned_offset + data_size - 1,
            label: format!("Allocated: {}[{}]", type_name, count),
            block_type: BlockType::Allocated,
        });

        // Update offset
        self.offset = aligned_offset + data_size;
    }

    fn reset(&mut self) {
        // Log the free space that was just created
        if self.offset > 0 {
            self.layout_log.push(Block {
                start: 0,
                end: self.offset - 1,
                label: format!("Freed up to: {} bytes", self.offset),
                block_type: BlockType::Free, // This is a simplification; in reality, it's just reset.
            });
        }
        self.offset = 0;
    }

    fn generate_ascii(&self) -> String {
        let mut output = String::new();
        output.push_str(&format!("Arena State (Capacity: {} bytes, Current Offset: {})\n", self.capacity, self.offset));
        
        for block in &self.layout_log {
            let symbol = match block.block_type {
                BlockType::Padding => "P",
                BlockType::Allocated => "A",
                BlockType::Free => "F",
            };
            output.push_str(&format!("[{}:{}-{} ({} bytes)] ", symbol, block.start, block.end, block.end - block.start + 1));
        }
        output.trim().to_string()
    }

    fn generate_dot(&self) -> String {
        let mut dot = String::new();
        dot.push_str("digraph ArenaLayout {\n");
        dot.push_str("    node [shape=box];\n");
        dot.push_str("    subgraph cluster_arena {\n");
        dot.push_str(&format!("        label = \"TensorArena (Capacity: {})\";\n", self.capacity));
        dot.push_str("        style=filled;\n");
        dot.push_str("        color=lightgrey;\n");

        for (i, block) in self.layout_log.iter().enumerate() {
            let fill_color = match block.block_type {
                BlockType::Padding => "white",
                BlockType::Allocated => "lightblue",
                BlockType::Free => "lightgreen",
            };
            dot.push_str(&format!("        node_{} [label=\"{}\\n{} bytes\", fillcolor={}];\n", 
                i, block.label, block.end - block.start + 1, fill_color));
        }

        // Create invisible edges to maintain order
        if !self.layout_log.is_empty() {
            let edge_chain: Vec<String> = (0..self.layout_log.len()).map(|i| format!("node_{}", i)).collect();
            dot.push_str(&format!("        {} [style=invis];\n", edge_chain.join(" -> ")));
        }

        dot.push_str("    }\n");
        dot.push_str("}\n");
        dot
    }
}

// --- CLI and Main Logic ---

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() {
        println!("Usage: cargo run -- [commands...]");
        println!("Commands: alloc <type> <count> | reset");
        println!("Example: cargo run -- alloc u32 100 alloc f32 50 reset alloc u8 200");
        return;
    }

    let mut simulator = ArenaSimulator::new(1024); // 1KB arena for demo
    let mut use_dot = false;

    let mut iter = args.iter();
    while let Some(cmd) = iter.next() {
        match cmd.as_str() {
            "alloc" => {
                let type_str = iter.next().unwrap_or_else(|| {
                    eprintln!("Error: 'alloc' requires a type.");
                    std::process::exit(1);
                });
                let count: usize = iter.next().unwrap_or_else(|| {
                    eprintln!("Error: 'alloc' requires a count.");
                    std::process::exit(1);
                }).parse().unwrap_or_else(|_| {
                    eprintln!("Error: count must be a number.");
                    std::process::exit(1);
                });
                simulator.allocate(type_str, count);
            }
            "reset" => {
                simulator.reset();
            }
            "--dot" => {
                use_dot = true;
            }
            _ => {
                eprintln!("Unknown command: {}", cmd);
            }
        }
    }

    if use_dot {
        println!("{}", simulator.generate_dot());
    } else {
        println!("{}", simulator.generate_ascii());
    }
}
