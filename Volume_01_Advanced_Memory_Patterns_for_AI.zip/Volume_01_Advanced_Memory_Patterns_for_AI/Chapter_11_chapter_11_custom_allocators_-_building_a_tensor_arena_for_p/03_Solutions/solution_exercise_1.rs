
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

use std::mem::{align_of, size_of};

pub struct TensorArena {
    buffer: Vec<u8>,
    offset: usize,
}

impl TensorArena {
    /// Creates a new arena with a fixed capacity.
    pub fn new(capacity: usize) -> Self {
        // We use `with_capacity` to allocate memory without initializing it to zero,
        // which is more performant. We then set the length to the capacity so we
        // can treat the entire block as initialized for our raw pointer operations.
        let mut buffer = Vec::with_capacity(capacity);
        buffer.resize(capacity, 0);
        
        Self { buffer, offset: 0 }
    }

    /// Allocates a block of memory for `count` elements of type `T`.
    /// Returns a raw pointer to the start of the block.
    pub fn allocate<T>(&mut self, count: usize) -> *mut T {
        let size = size_of::<T>() * count;
        let align = align_of::<T>();

        // Calculate the padding needed to align the current offset.
        // We align the current offset to the required alignment of T.
        let aligned_offset = (self.offset + align - 1) & !(align - 1);
        let padding = aligned_offset - self.offset;
        let total_bytes = padding + size;

        // Check for capacity overflow.
        if aligned_offset + size > self.buffer.len() {
            panic!(
                "Arena overflow: requested {} bytes (align {}), but only {} bytes remain.",
                total_bytes,
                align,
                self.buffer.len() - self.offset
            );
        }

        // Update the arena's offset.
        self.offset = aligned_offset + size;

        // Get a pointer to the aligned memory location.
        let ptr = self.buffer.as_mut_ptr().add(aligned_offset) as *mut T;
        
        // Note: In a real-world scenario, we might want to track allocations
        // for debugging, but for this exercise, we just return the pointer.
        ptr
    }

    /// Resets the arena, marking all memory as free for the next use.
    pub fn reset(&mut self) {
        self.offset = 0;
    }
}
