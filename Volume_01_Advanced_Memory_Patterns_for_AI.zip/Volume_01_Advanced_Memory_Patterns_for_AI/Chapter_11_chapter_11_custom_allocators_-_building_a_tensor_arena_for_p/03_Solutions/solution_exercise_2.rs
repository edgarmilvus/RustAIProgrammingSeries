
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.rs
// Description: Solution for Exercise 2
// ==========================================

// Assuming the TensorArena struct from Exercise 1 is defined above.

pub struct ArenaScope<'a> {
    arena: &'a mut TensorArena,
    start_offset: usize,
}

impl<'a> ArenaScope<'a> {
    /// Allocates memory through the underlying arena.
    /// This is a convenience wrapper.
    pub fn allocate<T>(&mut self, count: usize) -> *mut T {
        self.arena.allocate::<T>(count)
    }
}

impl<'a> Drop for ArenaScope<'a> {
    /// When the scope is dropped, reset the arena's offset to its state
    /// at the beginning of the scope.
    fn drop(&mut self) {
        self.arena.offset = self.start_offset;
    }
}

impl TensorArena {
    /// Creates a new scope that borrows the arena mutably.
    pub fn scope(&mut self) -> ArenaScope<'_> {
        ArenaScope {
            arena: self,
            start_offset: self.offset,
        }
    }
}

// --- Demonstration Function ---
pub fn run_inference_pass(arena: &mut TensorArena) {
    println!("Starting inference pass...");
    let initial_offset = arena.offset;
    println!("Arena offset at start: {}", initial_offset);

    {
        // Create a scope for this layer's execution.
        let mut scope = arena.scope();
        println!("Scope created. Offset inside scope: {}", scope.arena.offset);

        // Allocate tensors for the layer.
        // In a real scenario, these would be used for computation.
        let _input_tensor = scope.allocate::<f32>(1024);  // e.g., 1D input
        let _weights_tensor = scope.allocate::<f32>(2048); // e.g., weights matrix
        let _output_tensor = scope.allocate::<f32>(512);  // e.g., 1D output

        println!("Allocated tensors inside scope. New offset: {}", scope.arena.offset);
        
        // The scope ends here as it goes out of scope.
    }

    println!("Scope dropped. Arena offset reset to: {}", arena.offset);
    
    // Verify the offset was reset.
    assert_eq!(arena.offset, initial_offset);
    println!("Verification successful: Arena offset is back to initial state.");
}
