
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

/// Cargo.toml dependencies:
/// [dependencies]
/// aligned = "0.4" (Optional, but good for strict alignment. For this example, we handle alignment manually.)

use std::alloc::{alloc_zeroed, dealloc, Layout};
use std::ptr::NonNull;
use std::sync::atomic::{AtomicUsize, Ordering};

/// Represents a view into memory allocated in the arena.
/// This mimics a lightweight Tensor handle.
#[derive(Debug, Clone, Copy)]
pub struct TensorView {
    pub ptr: *mut u8,
    pub size_bytes: usize,
    pub alignment: usize,
}

/// A high-performance linear arena allocator.
/// 
/// # Context
/// Used in AI inference engines to allocate intermediate tensors 
/// (e.g., activation maps) with zero allocation overhead during the forward pass.
pub struct TensorArena {
    /// The raw pointer to the start of the allocated memory block.
    buffer: *mut u8,
    /// The total capacity of the arena in bytes.
    capacity: usize,
    /// The current allocation head, tracked atomically for thread safety.
    /// In a single-threaded context, a simple `Cell<usize>` would suffice.
    head: AtomicUsize,
    /// The layout used to allocate the main buffer (needed for deallocation).
    layout: Layout,
}

impl TensorArena {
    /// Creates a new arena with a fixed capacity.
    ///
    /// # Arguments
    /// * `capacity_bytes` - The total size of the memory pool.
    ///
    /// # Safety
    /// This function performs a raw system allocation.
    pub fn new(capacity_bytes: usize) -> Self {
        // Align to 64 bytes (common cache line size for modern CPUs).
        let alignment = 64;
        let layout = Layout::from_size_align(capacity_bytes, alignment)
            .expect("Invalid layout size or alignment");
        
        // SAFETY: We are allocating a single large block. 
        // `alloc_zeroed` ensures memory is initialized to 0, preventing 
        // undefined behavior if we accidentally read uninitialized padding.
        let buffer = unsafe { alloc_zeroed(layout) };

        Self {
            buffer,
            capacity: capacity_bytes,
            head: AtomicUsize::new(0),
            layout,
        }
    }

    /// Allocates a contiguous block of memory for a tensor.
    ///
    /// # Arguments
    /// * `size_bytes` - The size of the tensor in bytes.
    /// * `alignment` - The alignment requirement (e.g., 32 for AVX-512).
    ///
    /// Returns `Some(TensorView)` if space is available, otherwise `None`.
    pub fn allocate(&self, size_bytes: usize, alignment: usize) -> Option<TensorView> {
        // 1. Calculate the layout for this specific allocation.
        // Note: We use the requested alignment, not the arena's base alignment.
        let layout = Layout::from_size_align(size_bytes, alignment).ok()?;

        // 2. Atomically fetch the current head and calculate the new head.
        // We use Relaxed ordering because this allocator is typically used 
        // in a single-threaded context (per thread arenas) or at initialization.
        // If used concurrently by multiple threads, Acquire/Release semantics 
        // would be required to ensure visibility of the memory to other cores.
        let mut current_head = self.head.load(Ordering::Relaxed);

        // 3. Calculate the aligned offset.
        // `align_offset` returns the number of bytes needed to advance `ptr` 
        // to satisfy the alignment.
        let ptr = unsafe { self.buffer.add(current_head) };
        let offset = ptr.align_offset(alignment);
        let aligned_head = current_head + offset;

        // 4. Check for overflow (out of memory).
        let new_head = aligned_head + size_bytes;
        if new_head > self.capacity {
            return None; // Arena is full
        }

        // 5. Update the head pointer atomically.
        // We only update if the value hasn't changed since we read it (Compare-and-Swap).
        // For this simple linear allocator, we assume sequential allocation 
        // or that we are in a critical section.
        self.head.store(new_head, Ordering::Relaxed);

        // 6. Return the view.
        Some(TensorView {
            ptr: unsafe { self.buffer.add(aligned_head) },
            size_bytes,
            alignment,
        })
    }

    /// Resets the arena, effectively "freeing" all memory.
    /// This is O(1) and allows the arena to be reused for a new inference step.
    pub fn reset(&self) {
        self.head.store(0, Ordering::Relaxed);
    }
}

impl Drop for TensorArena {
    fn drop(&mut self) {
        // SAFETY: We are deallocating the exact block we allocated in `new`.
        unsafe {
            dealloc(self.buffer, self.layout);
        }
    }
}

// --- Usage Example ---

fn main() {
    // 1. Initialize a 1MB arena for a high-performance inference engine.
    // In a real scenario, this might be per-thread to avoid locking.
    let arena = TensorArena::new(1024 * 1024); 

    // 2. Allocate a "Batch" tensor (e.g., 32x224x224 f32 values).
    // Size: 32 * 224 * 224 * 4 bytes = ~6MB. 
    // This will fail because our arena is only 1MB.
    let batch_size = 32 * 224 * 224 * 4;
    let batch_view = arena.allocate(batch_size, 32);
    println!("Batch Allocation: {:?}", batch_view.is_some()); // false

    // 3. Allocate a smaller "Hidden Layer" tensor (e.g., 512x512 f32).
    // Size: 512 * 512 * 4 bytes = 1MB.
    let layer_size = 512 * 512 * 4;
    let layer_view = arena.allocate(layer_size, 32).expect("Arena full");
    println!("Layer Allocation: ptr={:p}, size={} bytes", layer_view.ptr, layer_view.size_bytes);

    // 4. Allocate a "Bias" vector (e.g., 512 f32).
    // Size: 512 * 4 bytes = 2KB.
    let bias_view = arena.allocate(512 * 4, 32).expect("Arena full");
    println!("Bias Allocation: ptr={:p}, size={} bytes", bias_view.ptr, bias_view.size_bytes);

    // 5. Reset the arena for the next inference request.
    // This does not deallocate memory; it just resets the cursor.
    arena.reset();
    println!("Arena reset. Current head: {}", arena.head.load(Ordering::Relaxed));

    // 6. Re-allocate (memory is reused).
    let new_view = arena.allocate(1024, 64).expect("Failed to reallocate");
    println!("Re-allocated: ptr={:p}", new_view.ptr);
    
    // When `arena` goes out of scope here, the entire 1MB buffer is freed.
}
