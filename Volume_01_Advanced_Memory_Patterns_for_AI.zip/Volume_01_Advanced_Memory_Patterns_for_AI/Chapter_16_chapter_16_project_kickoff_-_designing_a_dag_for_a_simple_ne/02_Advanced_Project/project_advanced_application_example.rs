
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

/// main.rs
/// A demonstration of a memory-efficient inference engine using a DAG,
/// smart pointers, and a custom arena allocator.

use std::cell::RefCell;
use std::rc::Rc;
use std::alloc::{Layout, GlobalAlloc, System};
use std::ptr;

// =============================================================================
// 1. Custom Arena Allocator
// =============================================================================

/// A simple bump-pointer arena allocator.
/// 
/// This allocator grabs a large chunk of memory upfront and "bumps" a pointer
/// forward for every allocation. It does not free individual allocations; 
/// memory is reset all at once. This is ideal for the lifetime of a single
/// inference request where many intermediate tensors are created and discarded
/// together.
struct Arena {
    buffer: *mut u8,
    capacity: usize,
    offset: usize,
}

impl Arena {
    const ARENA_SIZE: usize = 1024 * 1024; // 1 MB arena

    fn new() -> Self {
        let layout = Layout::from_size_align(Self::ARENA_SIZE, 8).unwrap();
        let buffer = unsafe { System.alloc(layout) };
        
        Arena {
            buffer,
            capacity: Self::ARENA_SIZE,
            offset: 0,
        }
    }

    /// Allocates a block of memory of specific size and alignment.
    /// Returns a raw pointer if successful, otherwise null.
    unsafe fn alloc(&mut self, layout: Layout) -> *mut u8 {
        let current_align = self.buffer as usize % layout.align();
        let padding = if current_align == 0 { 0 } else { layout.align() - current_align };
        
        let new_offset = self.offset + layout.size() + padding;
        
        if new_offset > self.capacity {
            return ptr::null_mut(); // Out of memory in arena
        }

        let ptr = self.buffer.add(self.offset + padding);
        self.offset = new_offset;
        ptr
    }

    /// Resets the arena, making all memory available again.
    /// This effectively "frees" everything allocated in this session.
    unsafe fn reset(&mut self) {
        self.offset = 0;
    }
}

impl Drop for Arena {
    fn drop(&mut self) {
        unsafe {
            let layout = Layout::from_size_align(Self::ARENA_SIZE, 8).unwrap();
            System.dealloc(self.buffer, layout);
        }
    }
}

// =============================================================================
// 2. Tensor Abstraction
// =============================================================================

/// Represents a tensor's data and metadata.
/// In a real system, this would be a generic struct over numeric types.
#[derive(Debug, Clone)]
struct TensorData {
    shape: Vec<usize>,
    data: Vec<f32>, // In a real arena impl, this would be a slice into the arena
}

impl TensorData {
    fn new(shape: Vec<usize>) -> Self {
        let size = shape.iter().product();
        TensorData {
            shape,
            data: vec
![0.0; size], // Simplified: using heap Vec for demo logic
        }
    }
}

/// A smart pointer wrapper for Tensors.
/// 
/// We use `Rc` for shared ownership (multiple nodes read the same input)
/// and `RefCell` to allow mutability when initializing data (weights/inputs)
/// while being immutable during the graph execution phase.
type TensorPtr = Rc<RefCell<TensorData>>;

fn create_tensor(shape: Vec<usize>) -> TensorPtr {
    Rc::new(RefCell::new(TensorData::new(shape)
)
}

// =============================================================================
// 3. DAG Node Definitions
// =============================================================================

/// Represents a node in the computational graph.
/// 
/// The `Node` holds `Rc<RefCell<Tensor>>` references to its inputs and output.
/// This creates the dependency graph structure.
enum Node {
    /// Input node: Source of data (e.g., from a request payload)
    Input { output: TensorPtr },
    /// Operation node: Performs computation
    Op {
        op_type: String,
        inputs: Vec<TensorPtr>,
        output: TensorPtr,
    },
}

impl Node {
    /// Executes the node's logic.
    /// In a real scenario, this would dispatch to optimized kernels (SIMD).
    fn compute(&self) {
        match self {
            Node::Input { .. } => {} // Inputs are already populated
            Node::Op { op_type, inputs, output } => {
                // Simulate computation
                let input_borrow = inputs[0].borrow();
                let mut output_borrow = output.borrow_mut();
                
                // Dummy logic: e.g., ReLU or simple pass-through
                if op_type == "ReLU" {
                    for (i, val) in input_borrow.data.iter().enumerate() {
                        output_borrow.data[i] = val.max(0.0);
                    }
                    println!("  [Compute] ReLU applied.");
                } else {
                    // MatMul simulation (simplified for brevity)
                    for (i, val) in input_borrow.data.iter().enumerate() {
                        output_borrow.data[i] = val * 1.0; // Pass through
                    }
                    println!("  [Compute] {} applied.", op_type);
                }
            }
        }
    }
}

// =============================================================================
// 4. Inference Engine
// =============================================================================

/// The engine manages the DAG and the execution lifecycle.
struct InferenceEngine {
    graph: Vec<Node>,
    arena: Arena,
}

impl InferenceEngine {
    fn new() -> Self {
        InferenceEngine {
            graph: Vec::new(),
            arena: Arena::new(),
        }
    }

    /// Builds the graph topology.
    /// 
    /// In a real system, this would parse a model file (e.g., ONNX) and 
    /// instantiate nodes. Here we manually wire the DAG.
    fn build_graph(&mut self) -> TensorPtr {
        // 1. Create Inputs
        let input = create_tensor(vec
![4, 4])
; // Batch 4, Features 4
        
        // 2. Create Weights (Simulated as inputs for this demo)
        let w1 = create_tensor(vec
![4, 4])
;
        
        // 3. Layer 1: MatMul
        let l1_out = create_tensor(vec
![4, 4])
;
        self.graph.push(Node::Op {
            op_type: "MatMul".to_string(),
            inputs: vec
![input.clone()
, w1.clone()], // Shared ownership
            output: l1_out.clone(),
        });

        // 4. Layer 2: ReLU
        let l2_out = create_tensor(vec
![4, 4])
;
        self.graph.push(Node::Op {
            op_type: "ReLU".to_string(),
            inputs: vec
![l1_out.clone()
], // Depends on previous layer
            output: l2_out.clone(),
        });

        l2_out // Return the final output pointer
    }

    /// Executes the graph.
    /// 
    /// Logic:
    /// 1. Allocate memory in the arena (simulated here by pre-allocating Vecs).
    /// 2. Traverse the graph (topological sort is implicit here by insertion order).
    /// 3. Compute nodes.
    /// 4. Reset arena for next request.
    fn run_inference(&mut self) -> TensorPtr {
        println!("Starting Inference Cycle...");
        
        // In a real arena implementation, we would allocate backing memory here:
        // let mem_slice = unsafe { self.arena.alloc(...) };
        
        // Build graph (usually done once, but reset for demo)
        let output = self.build_graph();

        // Execute DAG
        for node in &self.graph {
            node.compute();
        }

        println!("Inference Complete.");
        
        // Cleanup: Reset arena for next request
        // This invalidates raw pointers, but our Rc<RefCell> logic 
        // ensures we handle the high-level lifetimes safely.
        unsafe { self.arena.reset(); }

        output
    }
}

// =============================================================================
// 5. Main Execution (Simulation of Server Loop)
// =============================================================================

fn main() {
    // Initialize the engine
    let mut engine = InferenceEngine::new();

    // Simulate a request loop
    for request_id in 1..=3 {
        println!("\n--- Request #{} ---", request_id);
        
        // Run inference
        let result_ptr = engine.run_inference();
        
        // Access result
        let result = result_ptr.borrow();
        println!("Result shape: {:?}", result.shape);
        println!("Result sample: {:.2}", result.data[0]);
    }
}
