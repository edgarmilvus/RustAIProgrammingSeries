
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.rs
// Description: Solution for Exercise 4
// ==========================================

use serde::{Deserialize, Serialize};
use std::fs;
use std::io::{self, Write};
use clap::Parser;

// 1. Define the Graph structures
#[derive(Serialize, Deserialize, Debug)]
struct Node {
    id: u32,
    name: String,
}

#[derive(Serialize, Deserialize, Debug)]
struct Edge {
    src: u32,
    dst: u32,
}

#[derive(Serialize, Deserialize, Debug)]
struct Graph {
    nodes: Vec<Node>,
    edges: Vec<Edge>,
}

impl Graph {
    /// Converts the graph structure to a Graphviz DOT string.
    pub fn to_dot(&self) -> String {
        let mut output = String::new();
        
        // Graph header
        output.push_str("digraph G {\n");
        output.push_str("  rankdir=TB;\n"); // Top-to-Bottom layout
        
        // Nodes
        for node in &self.nodes {
            output.push_str(&format!("  {} [label=\"{}\"];\n", node.id, node.name));
        }
        
        // Edges
        for edge in &self.edges {
            output.push_str(&format!("  {} -> {};\n", edge.src, edge.dst));
        }
        
        output.push_str("}\n");
        output
    }
}

// 2. CLI Argument Parsing using Clap
#[derive(Parser, Debug)]
#[command(author, version, about, long_about = None)]
struct Args {
    /// Path to the JSON file containing the graph definition
    #[arg(short, long)]
    input: String,
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args = Args::parse();

    // Read file
    let contents = fs::read_to_string(args.input)?;

    // Parse JSON
    let graph: Graph = serde_json::from_str(&contents)?;

    // Generate DOT
    let dot_output = graph.to_dot();

    // Print to stdout
    println!("{}", dot_output);

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_dot_generation() {
        let graph = Graph {
            nodes: vec![
                Node { id: 1, name: "Input".to_string() },
                Node { id: 2, name: "MatMul".to_string() },
            ],
            edges: vec![Edge { src: 1, dst: 2 }],
        };

        let dot = graph.to_dot();
        assert!(dot.contains("digraph G {"));
        assert!(dot.contains("1 [label=\"Input\"];"));
        assert!(dot.contains("1 -> 2;"));
    }
}
