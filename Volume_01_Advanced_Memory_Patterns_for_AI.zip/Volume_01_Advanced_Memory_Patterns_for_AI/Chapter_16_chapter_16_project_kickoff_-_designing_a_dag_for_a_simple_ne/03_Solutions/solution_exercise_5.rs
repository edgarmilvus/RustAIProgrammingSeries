
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.rs
// Description: Solution for Exercise 5
// ==========================================

use std::collections::{HashSet, HashMap};
use std::rc::Rc;
use std::cell::RefCell;

// Assuming TensorNode is defined as in Exercise 1
#[derive(Debug)]
pub struct TensorNode {
    data: Vec<f32>,
    children: Vec<Rc<RefCell<TensorNode>>>,
    parents: Vec<Weak<RefCell<TensorNode>>>,
}

// Helper to identify nodes uniquely (using address for simplicity in this context)
// In a real graph, nodes should have unique IDs.
fn get_id(node: &Rc<RefCell<TensorNode>>) -> usize {
    node.as_ptr() as usize
}

pub fn is_acyclic(start_node: Rc<RefCell<TensorNode>>) -> bool {
    // Visited set: tracks all nodes we have fully processed.
    let mut visited = HashSet::new();
    // Recursion stack: tracks nodes in the current DFS path.
    let mut recursion_stack = HashSet::new();

    fn dfs(
        node: &Rc<RefCell<TensorNode>>,
        visited: &mut HashSet<usize>,
        recursion_stack: &mut HashSet<usize>,
    ) -> bool {
        let node_id = get_id(node);

        // If node is already in recursion stack, we found a back edge (cycle).
        if recursion_stack.contains(&node_id) {
            return false;
        }

        // If node is visited but not in stack, it's already processed safely.
        if visited.contains(&node_id) {
            return true;
        }

        // Mark as visited in current path
        recursion_stack.insert(node_id);

        // Traverse children
        let children = node.borrow().children.clone(); // Clone to avoid holding borrow across recursion
        for child in children {
            if !dfs(&child, visited, recursion_stack) {
                return false;
            }
        }

        // Remove from current path and mark as fully processed
        recursion_stack.remove(&node_id);
        visited.insert(node_id);

        true
    }

    dfs(&start_node, &mut visited, &mut recursion_stack)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_linear_chain_is_acyclic() {
        let a = Rc::new(RefCell::new(TensorNode { data: vec
![1.0], children: vec![], parents: vec![]
 }));
        let b = Rc::new(RefCell::new(TensorNode { data: vec
![2.0], children: vec![], parents: vec![]
 }));
        let c = Rc::new(RefCell::new(TensorNode { data: vec
![3.0], children: vec![], parents: vec![]
 }));

        // A -> B -> C
        a.borrow_mut().children.push(Rc::clone(&b));
        b.borrow_mut().children.push(Rc::clone(&c));

        assert!(is_acyclic(a));
    }

    #[test]
    fn test_cycle_detection() {
        let a = Rc::new(RefCell::new(TensorNode { data: vec
![1.0], children: vec
![], parents: vec![] }));
        let b = Rc::new(RefCell::new(TensorNode { data: vec
![2.0], children: vec
![], parents: vec![] }));

        // Create a cycle: A -> B -> A
        // Note: We bypass the safe `connect` method to force a cycle for testing.
        a.borrow_mut().children.push(Rc::clone(&b));
        b.borrow_mut().children.push(Rc::clone(&a));

        assert!(!is_acyclic(a));
    }
}
