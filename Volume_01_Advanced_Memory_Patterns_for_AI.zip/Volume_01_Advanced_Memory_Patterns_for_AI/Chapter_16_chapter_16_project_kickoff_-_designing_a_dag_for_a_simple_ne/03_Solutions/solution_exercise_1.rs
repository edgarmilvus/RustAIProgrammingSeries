
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

use std::rc::{Rc, Weak};
use std::cell::RefCell;

#[derive(Debug)]
pub struct TensorNode {
    data: Vec<f32>,
    // Children: Nodes that depend on this node (Strong references)
    children: Vec<Rc<RefCell<TensorNode>>>,
    // Parents: Nodes this node depends on (Weak references to prevent cycles)
    parents: Vec<Weak<RefCell<TensorNode>>>,
}

impl TensorNode {
    /// Creates a new leaf node (input data) with no dependencies or consumers.
    pub fn new(data: Vec<f32>) -> Rc<RefCell<Self>> {
        Rc::new(RefCell::new(TensorNode {
            data,
            children: Vec::new(),
            parents: Vec::new(),
        }))
    }

    /// Establishes a dependency: `parent` feeds into `child`.
    /// The child stores a Weak reference to the parent.
    /// The parent stores a Strong reference to the child.
    pub fn connect(parent: &Rc<RefCell<TensorNode>>, child: &Rc<RefCell<TensorNode>>) {
        // Add parent reference to child (as Weak)
        child.borrow_mut().parents.push(Rc::downgrade(parent));

        // Add child reference to parent (as Strong)
        parent.borrow_mut().children.push(Rc::clone(child));
    }

    /// Calculates the maximum depth of the DAG from this node (longest path to a leaf).
    pub fn compute_depth(node: &Rc<RefCell<TensorNode>>) -> usize {
        let borrowed_node = node.borrow();
        
        // Base case: If no children, depth is 1 (counting itself)
        if borrowed_node.children.is_empty() {
            return 1;
        }

        // Recursive step: 1 + max depth of all children
        1 + borrowed_node
            .children
            .iter()
            .map(|child| Self::compute_depth(child))
            .max()
            .unwrap_or(0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_dag_structure_and_depth() {
        // Create nodes: A -> B -> C
        let a = TensorNode::new(vec![1.0]);
        let b = TensorNode::new(vec![2.0]);
        let c = TensorNode::new(vec![3.0]);

        TensorNode::connect(&a, &b);
        TensorNode::connect(&b, &c);

        // Check depth
        assert_eq!(TensorNode::compute_depth(&a), 3);
        assert_eq!(TensorNode::compute_depth(&b), 2);
        assert_eq!(TensorNode::compute_depth(&c), 1);
    }

    #[test]
    fn test_memory_cleanup() {
        let a = TensorNode::new(vec![1.0]);
        let b = TensorNode::new(vec![2.0]);
        
        // A depends on B (Wait, logic in connect: Parent -> Child. 
        // If A depends on B, B is parent, A is child? 
        // Usually in flow: Data flows Parent -> Child.
        // If A *needs* B, then B is parent, A is child.
        // Let's verify counts.
        
        // Let's say B is input, A is operation on B.
        // B (Parent) -> A (Child)
        TensorNode::connect(&b, &a);

        // Strong counts: 
        // b: 1 (local var) + 1 (in a.parents as Weak doesn't count, but a.children holds strong ref? No. 
        // Wait, `connect` logic:
        // Child stores Weak to Parent. Parent stores Strong to Child.
        // So `b` holds strong ref to `a`.
        // `a` holds weak ref to `b`.
        
        // Counts:
        // `b` (local): 1
        // `b` inside `a` (Weak): 0 (weak doesn't increment strong count)
        // `b` inside `a.children` (Wait, `b` is parent, `a` is child. `b.children` contains `a`).
        // `a` (local): 1
        // `a` inside `b.children`: 1
        
        assert_eq!(Rc::strong_count(&b), 1); // Only local 'b' holds strong ref
        assert_eq!(Rc::strong_count(&a), 2); // Local 'a' + b.children
        
        // Drop 'a'
        drop(a);
        // Now 'b' should have strong count 1 (only local 'b')
        assert_eq!(Rc::strong_count(&b), 1);
        
        // Drop 'b'
        drop(b);
        // All counts should be 0 (memory freed)
    }
}
