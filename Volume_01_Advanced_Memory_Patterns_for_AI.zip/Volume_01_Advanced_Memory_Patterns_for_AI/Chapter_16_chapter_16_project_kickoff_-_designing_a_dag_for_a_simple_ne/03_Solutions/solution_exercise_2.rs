
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.rs
// Description: Solution for Exercise 2
// ==========================================

use std::alloc::{alloc, dealloc, Layout};
use std::ptr;

pub struct Arena {
    ptr: *mut u8,
    capacity: usize,
    offset: usize,
}

impl Arena {
    /// Creates a new Arena with a specific byte capacity.
    /// The memory is allocated on the heap.
    pub fn new(capacity: usize) -> Self {
        // Safety: Layout is non-zero size (capacity > 0 assumed, or handle 0 case).
        // We use alignment 8 for general purpose data.
        let layout = Layout::from_size_align(capacity, 8).unwrap();
        let ptr = unsafe { alloc(layout) };
        
        Arena {
            ptr,
            capacity,
            offset: 0,
        }
    }

    /// Allocates space for a value of type T and returns a raw pointer.
    pub fn alloc<T>(&mut self, value: T) -> *mut T {
        let layout = Layout::new::<T>();
        let align = layout.align();
        
        // Align the current offset to the required alignment
        // Formula: (offset + (align - 1)) & !(align - 1)
        let aligned_offset = (self.offset + align - 1) & !(align - 1);
        
        // Check for overflow
        if aligned_offset + layout.size() > self.capacity {
            panic!("Arena out of memory");
        }
        
        let ptr = unsafe { self.ptr.add(aligned_offset) } as *mut T;
        
        // Safety: 
        // 1. Pointer is within allocated bounds (checked above).
        // 2. Pointer is properly aligned (calculated above).
        // 3. We are writing to memory we own.
        unsafe {
            ptr::write(ptr, value);
        }
        
        // Update offset for next allocation
        self.offset = aligned_offset + layout.size();
        
        ptr
    }

    /// Resets the arena offset to 0, allowing memory to be reused.
    /// Does not deallocate the underlying buffer.
    pub fn reset(&mut self) {
        self.offset = 0;
    }
}

impl Drop for Arena {
    fn drop(&mut self) {
        // Safety: The pointer was allocated with the same layout in `new`.
        // We must ensure the layout matches (size = capacity, align = 8).
        let layout = Layout::from_size_align(self.capacity, 8).unwrap();
        unsafe {
            dealloc(self.ptr, layout);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_arena_alloc() {
        let mut arena = Arena::new(1024);
        
        let val = 42u32;
        let ptr = arena.alloc(val);
        
        // Safety: We know the pointer is valid and we just wrote to it.
        unsafe {
            assert_eq!(*ptr, 42);
        }
        
        // Check offset updated
        assert!(arena.offset > 0);
    }

    #[test]
    fn test_alignment() {
        let mut arena = Arena::new(1024);
        
        // Allocate a u8 (align 1)
        arena.alloc(1u8);
        // Allocate a u64 (align 8) - should skip bytes to align
        let ptr = arena.alloc(99u64);
        
        unsafe {
            assert_eq!(*ptr, 99);
        }
    }
}
