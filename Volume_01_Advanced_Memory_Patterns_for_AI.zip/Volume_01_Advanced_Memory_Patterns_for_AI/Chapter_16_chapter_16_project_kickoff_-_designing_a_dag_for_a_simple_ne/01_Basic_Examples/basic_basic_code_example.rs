
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

// Cargo.toml dependencies:
// [dependencies]
// anymap = "1.0.0-beta.2" // Optional, but useful for complex tensor storage. 
// For this specific example, we stick to std to keep it self-contained.

use std::rc::Rc;
use std::cell::RefCell;
use std::collections::{HashMap, VecDeque};

/// Represents the unique identifier for a node in the DAG.
/// In a production system, this might be a UUID or a composite key.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
struct NodeId(usize);

/// Represents a Tensor in our system.
/// For this "Hello World" example, we use a simple Vector of f32s.
/// In a real system, this would point to a buffer in a custom memory arena.
#[derive(Debug, Clone)]
struct Tensor {
    data: Vec<f32>,
    shape: Vec<usize>,
}

impl Tensor {
    fn new(data: Vec<f32>) -> Self {
        let shape = vec![data.len()];
        Tensor { data, shape }
    }
}

/// The atomic unit of computation in our DAG.
/// It holds its ID, a human-readable name, and a list of dependencies (parents).
/// We use `Rc` for shared ownership and `RefCell` to allow modifying the 
/// dependency list after creation (building the graph).
#[derive(Debug)]
struct Node {
    id: NodeId,
    name: String,
    /// Pointers to nodes that this node depends on (inputs).
    parents: RefCell<Vec<Rc<Node>>>,
    /// The operation this node represents. 
    /// In a full implementation, this would be an enum or a trait object.
    operation: String,
}

impl Node {
    fn new(id: NodeId, name: &str, operation: &str) -> Rc<Self> {
        Rc::new(Node {
            id,
            name: name.to_string(),
            parents: RefCell::new(Vec::new()),
            operation: operation.to_string(),
        })
    }

    /// Adds a dependency (an input edge) to this node.
    fn add_parent(self: &Rc<Self>, parent: Rc<Node>) {
        self.parents.borrow_mut().push(parent);
    }
}

/// The Graph struct manages the nodes and the execution context.
/// It acts as a high-level controller for the memory lifecycle of the computation.
struct Graph {
    nodes: HashMap<NodeId, Rc<Node>>,
    next_id: usize,
    /// Simulates a memory pool for tensors. 
    /// In a real system, this would be a bump-pointer allocator or a slab allocator.
    tensor_store: HashMap<NodeId, Tensor>,
}

impl Graph {
    fn new() -> Self {
        Graph {
            nodes: HashMap::new(),
            next_id: 0,
            tensor_store: HashMap::new(),
        }
    }

    /// Creates a new node and registers it in the graph.
    fn create_node(&mut self, name: &str, operation: &str) -> Rc<Node> {
        let id = NodeId(self.next_id);
        self.next_id += 1;
        let node = Node::new(id, name, operation);
        self.nodes.insert(id, Rc::clone(&node));
        node
    }

    /// "Executes" the graph.
    /// Since this is a structural example, we perform a Topological Sort (via BFS)
    /// to determine the order of operations.
    /// In a real execution engine, this would trigger actual tensor math.
    fn execute(&self, start_node: Rc<Node>) -> Vec<NodeId> {
        let mut execution_order = Vec::new();
        let mut visited = HashMap::new();
        let mut queue = VecDeque::new();

        queue.push_back(start_node);

        while let Some(current) = queue.pop_front() {
            if visited.contains_key(&current.id) {
                continue;
            }

            // Check if all parents are processed (simplified check for DAG)
            // In a strict topological sort, we track in-degrees.
            // Here we rely on the queue order for a simple DAG.
            
            visited.insert(current.id, true);
            execution_order.push(current.id);

            // In a real execution, we would fetch tensors from parents here
            // and perform the operation (e.g., matrix multiplication).
            // For this demo, we just print the intent.
            println!(
                "Executing Node [{}:{}] with operation '{}'",
                current.id.0, current.name, current.operation
            );

            // Note: In a real DAG, we would look for children, not parents.
            // But for building execution order from inputs, we typically 
            // traverse forward. Here we simulate the flow by having the 
            // caller pass the final node, but we actually need to resolve 
            // dependencies. 
            // To keep this simple: We assume the graph is linear or we 
            // just print the node. A true topological sort requires 
            // an adjacency list of children.
        }
        
        execution_order
    }

    /// A more robust execution that handles dependencies correctly.
    /// It performs a topological sort starting from input nodes.
    fn execute_proper(&self, output_node: &Rc<Node>) -> Vec<NodeId> {
        let mut order = Vec::new();
        let mut visited = HashMap::new();
        
        // Recursive helper for DFS
        fn visit(node: &Rc<Node>, visited: &mut HashMap<NodeId, bool>, order: &mut Vec<NodeId>) {
            if visited.contains_key(&node.id) {
                return;
            }
            // Visit parents first (dependencies)
            for parent in node.parents.borrow().iter() {
                visit(parent, visited, order);
            }
            visited.insert(node.id, true);
            order.push(node.id);
        }

        visit(output_node, &mut visited, &mut order);
        order
    }
}

/// Simulates the "Memory Arena" allocation for a tensor.
/// In the context of the book, this would allocate memory from a pre-reserved block
/// to avoid heap fragmentation and improve cache locality.
fn allocate_tensor_in_arena(data: Vec<f32>) -> Tensor {
    // In a real implementation, we would calculate an offset in a byte buffer.
    // e.g., let ptr = arena.allocate::<f32>(data.len());
    // std::ptr::copy_nonoverlapping(data.as_ptr(), ptr, data.len());
    Tensor::new(data)
}

fn main() {
    // 1. Initialize the Graph Context
    let mut graph = Graph::new();

    // 2. Create Nodes (The "What")
    // We define the structure of the network: Input -> Weight -> Multiply -> Bias -> Output
    let input_node = graph.create_node("Input_X", "Placeholder");
    let weight_node = graph.create_node("Weight_W", "Parameter");
    let bias_node = graph.create_node("Bias_b", "Parameter");
    
    // The multiplication node depends on Input and Weight
    let mul_node = graph.create_node("Mul_Z", "MatMul");
    mul_node.add_parent(Rc::clone(&input_node));
    mul_node.add_parent(Rc::clone(&weight_node));

    // The addition node depends on the result of Mul and Bias
    let output_node = graph.create_node("Output_Y", "Add");
    output_node.add_parent(Rc::clone(&mul_node));
    output_node.add_parent(Rc::clone(&bias_node));

    // 3. Allocate Data (The "Where")
    // We populate the "Arena" (our HashMap store) with dummy data.
    // Notice we are moving data into the store, simulating ownership transfer to the graph.
    graph.tensor_store.insert(input_node.id, allocate_tensor_in_arena(vec
![1.0, 2.0, 3.0])
);
    graph.tensor_store.insert(weight_node.id, allocate_tensor_in_arena(vec
![0.5, 0.5, 0.5])
);
    graph.tensor_store.insert(bias_node.id, allocate_tensor_in_arena(vec
![0.1, 0.1, 0.1])
);
    
    // Intermediate and output tensors are pre-allocated (or lazily allocated in real systems)
    graph.tensor_store.insert(mul_node.id, allocate_tensor_in_arena(vec
![0.0, 0.0, 0.0])
);
    graph.tensor_store.insert(output_node.id, allocate_tensor_in_arena(vec
![0.0, 0.0, 0.0])
);

    println!("--- Graph Structure Built ---");
    println!("Output Node ID: {:?}", output_node.id);

    // 4. Execute the Graph
    // We determine the order of operations using a Topological Sort.
    println!("\n--- Starting Execution (Topological Order) ---");
    let execution_order = graph.execute_proper(&output_node);

    for node_id in execution_order {
        if let Some(node) = graph.nodes.get(&node_id) {
            // Retrieve inputs from the "Arena"
            let inputs: Vec<&Tensor> = node.parents.borrow()
                .iter()
                .filter_map(|p| graph.tensor_store.get(&p.id))
                .collect();

            // Simulate computation
            print!("  > Computing '{}' (ID: {}) ", node.name, node.id.0);
            if !inputs.is_empty() {
                print!("from {} inputs", inputs.len());
            } else {
                print!("(Input/Param)");
            }
            println!();
            
            // In a real system, we would write the result to `graph.tensor_store.get_mut(&node_id)`
        }
    }
    
    println!("\n--- Execution Complete ---");
    // Verify the graph is still valid (Rc counts, etc.)
    println!("Graph nodes managed: {}", graph.nodes.len());
}
