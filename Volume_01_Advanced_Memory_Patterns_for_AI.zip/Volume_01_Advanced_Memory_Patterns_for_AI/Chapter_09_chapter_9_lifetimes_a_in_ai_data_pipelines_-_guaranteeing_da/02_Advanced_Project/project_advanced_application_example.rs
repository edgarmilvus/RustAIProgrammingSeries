
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

// main.rs

use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;

/// Represents a raw token ID (e.g., from a vocabulary).
/// In a real scenario, this might be a u32 or u16.
pub type TokenId = u32;

/// A contiguous memory block simulating a pre-allocated tensor buffer.
/// This struct manages the lifecycle of the data.
pub struct TokenPool {
    buffer: Vec<TokenId>,
}

impl TokenPool {
    /// Creates a new pool with a fixed capacity.
    pub fn new(capacity: usize) -> Self {
        // In a real system, this might use unsafe code to align memory
        // or map directly to GPU memory (e.g., via CUDA or Vulkan).
        let mut buffer = Vec::with_capacity(capacity);
        // Initialize with dummy data for demonstration.
        for i in 0..capacity {
            buffer.push(i as TokenId);
        }
        Self { buffer }
    }

    /// Borrows a slice of tokens from the pool.
    /// The returned slice's lifetime is tied to `&self` (the pool).
    /// This is a zero-copy operation.
    pub fn get_slice(&self, start: usize, len: usize) -> &[TokenId] {
        let end = start + len;
        assert!(end <= self.buffer.len(), "Requested range out of bounds");
        &self.buffer[start..end]
    }
}

/// Represents a single inference task processing a specific slice of tokens.
/// The lifetime `'a` ensures that `tokens` cannot outlive the `TokenPool`.
pub struct InferenceTask<'a> {
    id: usize,
    tokens: &'a [TokenId],
    model_name: String,
}

impl<'a> InferenceTask<'a> {
    /// Creates a new task borrowing data from the pool.
    /// Rust's borrow checker verifies that `tokens` lives as long as `'a`.
    pub fn new(id: usize, tokens: &'a [TokenId], model_name: &str) -> Self {
        Self {
            id,
            tokens,
            model_name: model_name.to_string(),
        }
    }

    /// Simulates the heavy computation of a forward pass.
    /// We iterate over the tokens without copying them.
    pub fn run(&self) -> Vec<f32> {
        println!("[Task {}] Processing {} tokens for model '{}'", self.id, self.tokens.len(), self.model_name);
        
        // Simulate embedding generation (e.g., looking up weights).
        // Accessing `self.tokens` is safe because the lifetime `'a` guarantees
        // the underlying pool is still alive.
        let embeddings: Vec<f32> = self.tokens
            .iter()
            .map(|&token| {
                // Simulate expensive calculation
                thread::sleep(Duration::from_micros(100)); 
                (token as f32) * 0.1
            })
            .collect();

        println!("[Task {}] Inference complete.", self.id);
        embeddings
    }
}

/// The Inference Server manages the pool and dispatches tasks.
/// It uses an Arc<Mutex<>> pattern to allow safe concurrent access 
/// to the pool for task creation, though the tasks themselves are 
/// processed sequentially here to demonstrate the lifetime constraints clearly.
struct InferenceServer {
    pool: Arc<Mutex<TokenPool>>,
}

impl InferenceServer {
    pub fn new(pool_size: usize) -> Self {
        Self {
            pool: Arc::new(Mutex::new(TokenPool::new(pool_size))),
        }
    }

    /// Schedules a task. 
    /// Note: In a real async runtime (like Tokio), we would pass the Arc<Mutex<>> 
    /// into the async block, but the lifetime mechanics for the borrowed slice 
    /// would remain the same: the borrow must not escape the scope of the lock guard.
    pub fn schedule_inference(&self, task_id: usize, start: usize, len: usize) {
        // 1. Acquire lock to access the pool
        let pool_guard = self.pool.lock().unwrap();
        
        // 2. Borrow the data slice (Zero-Copy)
        // The slice `token_slice` has a lifetime tied to `pool_guard`.
        let token_slice = pool_guard.get_slice(start, len);

        // 3. Create the task. 
        // The task 'a is implicitly tied to the scope of `pool_guard`.
        let task = InferenceTask::new(task_id, token_slice, "bert-base-uncased");

        // 4. Drop the guard explicitly to release the lock before processing.
        // If we kept the guard while running `task.run()`, we would block 
        // other tasks from even creating slices.
        drop(pool_guard);

        // 5. Run the inference (simulated).
        // Even though the lock is released, the data `token_slice` points to 
        // is still valid because `TokenPool` is wrapped in an Arc (heap allocated)
        // and we haven't modified the underlying vector. 
        // *Crucially*, if `TokenPool` were dropped here, the borrow checker 
        // would have prevented `task` from existing.
        let _result = task.run();
    }
}

fn main() {
    // Initialize the server with a large pool.
    let server = InferenceServer::new(1000);

    println!("--- Starting Inference Pipeline ---");

    // Simulate a stream of incoming requests.
    for i in 0..5 {
        let start = i * 10;
        server.schedule_inference(i, start, 10);
    }

    println!("--- Pipeline Finished ---");
}
