
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

/// A simple struct representing a large dataset or model weights stored in memory.
/// In a real scenario, this might be a `Vec<f32>` or a memory-mapped file.
struct DataStore<'a> {
    /// The raw data buffer. We use a slice reference here to emphasize that
    /// we are borrowing data owned by someone else (e.g., the OS or a main cache).
    buffer: &'a [f32],
}

/// A struct representing a view into a specific chunk of the data.
/// This is a "zero-copy" abstraction.
struct DataSlice<'a> {
    /// The lifetime 'a ties this slice to the lifetime of the DataStore's buffer.
    data: &'a [f32],
}

impl<'a> DataStore<'a> {
    /// Creates a new DataStore from a reference to a slice.
    /// The lifetime 'a explicitly links the store to the input buffer.
    fn new(buffer: &'a [f32]) -> Self {
        DataStore { buffer }
    }

    /// Simulates a high-performance inference step that processes a specific chunk of data.
    /// We pass a reference to `self` and return a `DataSlice` that lives as long as `self`.
    /// This prevents the user from accessing the slice after the DataStore is dropped.
    fn get_inference_chunk(&self, start: usize, end: usize) -> DataSlice<'a> {
        // In a real scenario, we might check bounds here.
        // Note: We are returning a reference to the internal buffer, which is valid
        // as long as 'a (the lifetime of the original buffer) is valid.
        DataSlice {
            data: &self.buffer[start..end],
        }
    }
}

/// A function that consumes the data slice and performs an operation (e.g., inference).
/// It takes a reference with a lifetime 'b, ensuring the data is valid during execution.
fn run_inference<'b>(input: &DataSlice<'b>) -> f32 {
    // Simulate a simple operation (e.g., summing elements).
    // The borrow checker ensures `input` is valid throughout this function.
    input.data.iter().sum()
}

fn main() {
    // 1. Setup: Allocate the "large" dataset on the heap (simulated).
    // This vector owns the data.
    let raw_data: Vec<f32> = vec
![1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0];
    
    // 2. Create the DataStore.
    // We borrow `raw_data` using a slice reference.
    // The lifetime 'a is inferred to be the scope of `raw_data`.
    let store = DataStore::new(&raw_data)
;

    // 3. Create a view (DataSlice) into the data.
    // This does not copy the numbers; it only copies the pointer and length.
    let chunk = store.get_inference_chunk(2, 5); // Points to [3.0, 4.0, 5.0]

    // 4. Process the data.
    let result = run_inference(&chunk);
    println!("Inference result for chunk [2..5]: {}", result);

    // 5. Demonstrate lifetime safety.
    // If we were to drop `raw_data` here, `store` and `chunk` would become invalid.
    // The compiler enforces that `store` cannot outlive `raw_data`.
    
    // Example of what the compiler prevents:
    // let invalid_chunk;
    // {
    //     let local_data = vec
![1.0, 1.0];
    //     let local_store = DataStore::new(&local_data)
;
    //     invalid_chunk = local_store.get_inference_chunk(0, 1);
    // } // `local_data` is dropped here.
    // // println!("{}", invalid_chunk.data[0]); // ERROR: `local_data` does not live long enough.
}
