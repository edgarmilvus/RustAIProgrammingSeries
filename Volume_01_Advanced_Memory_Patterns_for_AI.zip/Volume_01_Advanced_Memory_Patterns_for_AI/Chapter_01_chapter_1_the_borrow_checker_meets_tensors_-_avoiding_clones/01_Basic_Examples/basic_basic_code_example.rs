
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

// Cargo.toml dependencies:
// [dependencies]
// num-traits = "0.2" // For generic numeric operations

use num_traits::Float; // We use this for generic floating-point math
use std::ops::Deref; // For ergonomic access to underlying data

/// Represents an N-dimensional tensor owning its data.
/// In a real system, this would likely use a custom allocator for large models.
#[derive(Debug)]
pub struct Tensor<T> {
    /// The flat buffer of data.
    data: Vec<T>,
    /// The shape of the tensor (e.g., [Height, Width, Channels]).
    shape: Vec<usize>,
}

/// Represents a read-only view into a tensor's data.
/// This struct does not own the data; it only holds a reference.
/// This is the key to zero-copy operations.
#[derive(Debug)]
pub struct TensorView<'a, T> {
    /// A reference to the underlying data slice.
    data: &'a [T],
    /// The shape of the view.
    shape: Vec<usize>,
}

impl<T> Tensor<T> {
    /// Creates a new tensor from a vector and a shape.
    /// Panics if the data length does not match the product of the shape dimensions.
    pub fn new(data: Vec<T>, shape: Vec<usize>) -> Self {
        let expected_len: usize = shape.iter().product();
        assert_eq!(
            data.len(),
            expected_len,
            "Data length {} does not match shape product {}",
            data.len(),
            expected_len
        );
        Tensor { data, shape }
    }

    /// Creates a read-only view of the entire tensor.
    /// This is a cheap operation (O(1)) as it only copies references.
    pub fn view(&self) -> TensorView<T> {
        TensorView {
            data: &self.data,
            shape: self.shape.clone(),
        }
    }

    /// Creates a sliced view of the tensor.
    /// This demonstrates the power of borrowing: we can create multiple
    /// overlapping views into the same data safely.
    /// For simplicity, we slice along the first dimension (e.g., batch dimension).
    pub fn slice(&self, start: usize, end: usize) -> TensorView<T> {
        let slice_len = self.shape[1..].iter().product();
        let start_idx = start * slice_len;
        let end_idx = end * slice_len;
        
        assert!(end_idx <= self.data.len(), "Slice index out of bounds");

        TensorView {
            data: &self.data[start_idx..end_idx],
            shape: {
                let mut new_shape = self.shape.clone();
                new_shape[0] = end - start;
                new_shape
            },
        }
    }
}

// Implement Deref so we can treat TensorView like a slice.
impl<'a, T> Deref for TensorView<'a, T> {
    type Target = [T];

    fn deref(&self) -> &Self::Target {
        self.data
    }
}

/// A function that processes data. It accepts a generic view `&TensorView`.
/// This is crucial: it accepts a borrow, not an owned value.
/// It can operate on the full tensor, a slice, or a sub-region without copying data.
fn run_inference_step<T: Float + std::fmt::Debug>(input: &TensorView<T>) {
    println!("--- Running Inference Step ---");
    println!("Processing tensor with shape: {:?}", input.shape);
    println!("Data slice length: {}", input.data.len());

    // Example operation: Calculate the mean of the data (simplified).
    // We can iterate over the borrowed slice directly.
    let sum: T = input.iter().fold(T::zero(), |acc, &x| acc + x);
    let mean = sum / T::from(input.len()).unwrap();
    
    println!("Calculated Mean: {:?}", mean);
    println!("-----------------------------\n");
}

fn main() {
    // 1. SETUP: Create a large "input" tensor.
    // Imagine this is a 4D tensor: [Batch=2, Height=4, Width=4, Channels=3]
    // Total elements: 2 * 4 * 4 * 3 = 96 elements.
    // In a real scenario, this data might come from a GPU or a file.
    let total_elements = 96;
    let data: Vec<f32> = (0..total_elements as u32)
        .map(|i| i as f32 * 0.1)
        .collect();
    let shape = vec![2, 4, 4, 3];
    
    let input_tensor = Tensor::new(data, shape);
    println!("Created large input tensor with {} elements.", input_tensor.data.len());

    // 2. VIEW CREATION: Create a zero-copy view of the entire tensor.
    // `tensor.view()` returns a `TensorView` that borrows `input_tensor`.
    // No data is copied here.
    let full_view = input_tensor.view();
    
    // 3. PROCESSING: Pass the view to the inference function.
    // The function receives a reference to the view, ensuring no ownership transfer.
    run_inference_step(&full_view);

    // 4. SLICING: Create a sliced view (e.g., processing the first batch item only).
    // This is still a borrow. The underlying data in `input_tensor` remains unchanged.
    let slice_view = input_tensor.slice(0, 1); // Slice from index 0 to 1 (exclusive)
    println!("Created sliced view with shape: {:?}", slice_view.shape);
    
    // 5. PROCESSING THE SLICE: Pass the slice view to the same function.
    // The function logic remains identical, but it operates on a subset of data.
    run_inference_step(&slice_view);

    // 6. CLEANUP: `input_tensor` is dropped here. All views go out of scope.
    // Rust's borrow checker ensures that `full_view` and `slice_view` cannot outlive `input_tensor`.
}
