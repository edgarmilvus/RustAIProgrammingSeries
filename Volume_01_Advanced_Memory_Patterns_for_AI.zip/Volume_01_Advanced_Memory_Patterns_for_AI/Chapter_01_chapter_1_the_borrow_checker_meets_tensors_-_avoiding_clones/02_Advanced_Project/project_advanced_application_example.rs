
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

use std::borrow::Cow;
use std::fmt;
use std::ops::Deref;

/// Represents the shape of a tensor (e.g., [Batch, Height, Width, Channels]).
#[derive(Clone, Debug, PartialEq)]
pub struct TensorShape {
    pub dims: Vec<usize>,
}

impl TensorShape {
    pub fn new(dims: Vec<usize>) -> Self {
        Self { dims }
    }

    /// Calculates the total number of elements in the tensor.
    pub fn len(&self) -> usize {
        self.dims.iter().product()
    }

    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

/// A generic Tensor struct.
/// `T`: The data type (e.g., f32).
/// `D`: The data storage. We use a generic type to allow both owned `Vec<T>` and borrowed `&[T]`.
#[derive(Clone)]
pub struct Tensor<'a, T, D>
where
    D: Deref<Target = [T]>,
{
    pub shape: TensorShape,
    /// The data storage. Note the lifetime `'a` ensures borrowed data lives as long as the tensor.
    pub data: D,
    // PhantomData is used to tie the lifetime 'a to the generic D if D contains references.
    _marker: std::marker::PhantomData<&'a ()>,
}

// Implementation for any Deref target slice (Vec, array slice, Cow, etc.)
impl<'a, T, D> Tensor<'a, T, D>
where
    T: Copy + fmt::Debug,
    D: Deref<Target = [T]>,
{
    /// Creates a new tensor from shape and data.
    /// This is generic and accepts owned or borrowed data.
    pub fn new(shape: TensorShape, data: D) -> Self {
        // In a real scenario, we would assert shape.len() == data.len()
        assert_eq!(shape.len(), data.len(), "Shape length must match data length");
        Self {
            shape,
            data,
            _marker: std::marker::PhantomData,
        }
    }

    /// A "view" operation: Creates a new Tensor pointing to a slice of the original data.
    /// This is O(1) and performs NO memory allocation or copying.
    pub fn slice(&self, start: usize, end: usize) -> Tensor<'_, T, &[T]> {
        let sub_slice = &self.data[start..end];
        // We derive the new shape. For simplicity, we flatten the last dimension here.
        let mut new_dims = self.shape.dims.clone();
        let last_dim = new_dims.last_mut().unwrap();
        *last_dim = end - start; // Adjusting the last dimension
        
        Tensor {
            shape: TensorShape::new(new_dims),
            data: sub_slice,
            _marker: std::marker::PhantomData,
        }
    }

    /// Simulates a computation (e.g., element-wise addition).
    /// Accepts a generic view `&Tensor` to avoid taking ownership.
    /// This allows passing temporary slices or references without cloning.
    pub fn add(&self, other: &Tensor<T, impl Deref<Target = [T]>>) -> Tensor<'a, T, Vec<T>> {
        assert_eq!(self.shape.len(), other.shape.len());

        let mut result_data = Vec::with_capacity(self.shape.len());
        
        // SIMD-friendly loop (conceptually)
        for (a, b) in self.data.iter().zip(other.data.iter()) {
            result_data.push(*a + *b);
        }

        Tensor::new(self.shape.clone(), result_data)
    }
}

/// Helper to create a Tensor from a Cow (Clone-on-Write).
/// This is the bridge between owned and borrowed data.
impl<'a, T> From<(TensorShape, Cow<'a, [T]>)> for Tensor<'a, T, Cow<'a, [T]>>
where
    T: Copy + fmt::Debug,
{
    fn from((shape, data): (TensorShape, Cow<'a, [T]>)) -> Self {
        Tensor {
            shape,
            data,
            _marker: std::marker::PhantomData,
        }
    }
}

// Implement AsRef to allow the tensor to be treated as a slice seamlessly.
impl<'a, T, D> AsRef<[T]> for Tensor<'a, T, D>
where
    D: Deref<Target = [T]>,
{
    fn as_ref(&self) -> &[T] {
        &self.data
    }
}

// Custom Debug implementation for cleaner printing
impl<'a, T, D> fmt::Debug for Tensor<'a, T, D>
where
    T: fmt::Debug + Copy,
    D: Deref<Target = [T]>,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "Tensor {:?} {:?}", self.shape.dims, &self.data.as_ref()[..4])
    }
}

/// --- Main Application: Inference Pipeline ---

fn main() {
    println!("=== High-Performance Tensor Inference Pipeline ===\n");

    // 1. Acquire Data (Simulated from a hardware buffer or file)
    // We use `Cow::Owned` to simulate data that needs to be managed by the engine.
    let raw_data: Vec<f32> = vec
![1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0];
    let input_shape = TensorShape::new(vec![2, 4])
; // Batch 2, 4 features

    // 2. Create the Main Tensor
    // We wrap it in a Cow to demonstrate conditional cloning later.
    let cow_data = Cow::Owned(raw_data);
    let main_tensor: Tensor<f32, Cow<[f32]>> = Tensor::from((input_shape, cow_data));

    println!("1. Main Tensor: {:?}", main_tensor);

    // 3. Create a Zero-Copy View (Slicing)
    // We want to process the first sample in the batch.
    // This creates a new Tensor struct, but the `data` field is a reference (&[f32])
    // pointing to the memory inside `main_tensor`. No allocation occurs.
    let view_tensor = main_tensor.slice(0, 4);
    println!("2. Zero-Copy View (First Batch Item): {:?}", view_tensor);

    // 4. Conditional Cloning with Cow
    // Imagine we need to modify the data. If we own it, we modify in place.
    // If we borrow it (e.g., from a read-only file map), we must clone.
    let mut conditional_tensor: Tensor<f32, Cow<[f32]>> = Tensor::from((
        TensorShape::new(vec![4]),
        Cow::Borrowed(&[10.0, 10.0, 10.0, 10.0]), // Borrowed immutable data
    ));

    // To modify, `Cow` handles the cloning automatically.
    if let Cow::Borrowed(_) = conditional_tensor.data {
        println!("3. Data is borrowed. Cloning on write...");
        // We convert the Cow to Owned by mutating it.
        // This allocates new memory only now, exactly when needed.
        let owned_data = conditional_tensor.data.clone().into_owned();
        conditional_tensor.data = Cow::Owned(owned_data);
    }

    // Now we can safely modify
    let mut_mut_data = conditional_tensor.data.to_mut();
    mut_mut_data[0] = 99.0; // Modify the first element
    println!("4. Modified Tensor: {:?}", conditional_tensor);

    // 5. Inference Simulation (Generic API)
    // We perform an operation using a view. The `add` function takes `&Tensor`.
    // This ensures the function doesn't take ownership of the large data buffers.
    let bias = Tensor::new(
        TensorShape::new(vec![4]),
        vec
![1.0, 1.0, 1.0, 1.0]
,
    );

    // Passing `&view_tensor` and `&bias`. No data is moved or cloned here.
    let result = view_tensor.add(&bias);
    
    println!("5. Inference Result (View + Bias): {:?}", result);
    println!("   (Notice the result is a new owned Vec, but inputs were untouched)");
}
