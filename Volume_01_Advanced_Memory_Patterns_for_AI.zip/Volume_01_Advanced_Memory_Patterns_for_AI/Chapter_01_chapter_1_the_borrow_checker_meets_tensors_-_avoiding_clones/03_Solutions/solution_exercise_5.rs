
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.rs
// Description: Solution for Exercise 5
// ==========================================

// 1. Define the Kernel struct
struct ConvolutionKernel {
    data: Vec<f32>,
}

// Define a custom Tensor struct for demonstration
struct Tensor<T> {
    data: Vec<T>,
}

// Implement AsRef<[f32]> for the custom Tensor
impl AsRef<[f32]> for Tensor<f32> {
    fn as_ref(&self) -> &[f32] {
        &self.data
    }
}

impl ConvolutionKernel {
    // 2. Method accepting generic D: AsRef<[f32]>
    pub fn apply_convolution<D>(&self, input: D) -> f32
    where
        D: AsRef<[f32]>,
    {
        // 3. Convert to slice
        let slice = input.as_ref();
        
        // Simple dummy calculation: sum of element-wise multiplication (dot product)
        // assuming kernel fits in input.
        let mut result = 0.0;
        for (i, &val) in slice.iter().enumerate() {
            if i < self.data.len() {
                result += val * self.data[i];
            }
        }
        result
    }
}

fn main() {
    let kernel = ConvolutionKernel { data: vec![0.5, 0.5] };

    // 4. Demonstrate with Vec<f32>
    let vec_input = vec
![2.0, 4.0];
    let res1 = kernel.apply_convolution(vec_input)
;
    println!("Vec result: {}", res1);

    // Demonstrate with &[f32] (slice)
    let slice_input: &[f32] = &[2.0, 4.0];
    let res2 = kernel.apply_convolution(slice_input);
    println!("Slice result: {}", res2);

    // Demonstrate with Tensor<f32>
    let tensor_input = Tensor { data: vec
![2.0, 4.0] };
    let res3 = kernel.apply_convolution(&tensor_input)
; // Pass by reference
    println!("Tensor result: {}", res3);
}
