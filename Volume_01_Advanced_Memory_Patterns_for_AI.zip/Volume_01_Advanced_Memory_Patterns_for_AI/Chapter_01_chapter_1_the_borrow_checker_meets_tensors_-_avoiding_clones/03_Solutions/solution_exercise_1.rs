
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

use std::ops::Deref;

// 1. Define the Tensor struct
struct Tensor<T> {
    data: Vec<T>,
    rows: usize,
    cols: usize,
}

// 2. Implement Deref so Tensor can be treated as a slice
impl<T> Deref for Tensor<T> {
    type Target = [T];

    fn deref(&self) -> &Self::Target {
        &self.data
    }
}

// 3. Define the generic print function
// This function accepts any type M that can be dereferenced to a slice of T
fn print_matrix<M: Deref<Target = [T]>, T: std::fmt::Debug>(matrix: &M) {
    for item in matrix.iter() {
        print!("{:?} ", item);
    }
    println!();
}

fn main() {
    // Create a tensor
    let my_tensor = Tensor {
        data: vec
![1, 2, 3, 4],
        rows: 2,
        cols: 2,
    };

    // 4. Demonstrate passing &Tensor<i32>
    // The compiler automatically coerces &Tensor<i32> to &[i32] via Deref
    print_matrix(&my_tensor)
;

    // Verify that no clone happened by checking the original data is still valid
    println!("Original data accessible: {:?}", my_tensor.data);
}
