
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.rs
// Description: Solution for Exercise 3
// ==========================================

// 1. Define the MatrixView trait
trait MatrixView<T> {
    fn get(&self, row: usize, col: usize) -> Option<T>;
    fn shape(&self) -> (usize, usize);
}

// Define a simple Tensor for Exercise 1 compatibility
struct Tensor<T> {
    data: Vec<T>,
    rows: usize,
    cols: usize,
}

// 2. Implement MatrixView for &Tensor<f64>
impl MatrixView<f64> for &Tensor<f64> {
    fn get(&self, row: usize, col: usize) -> Option<f64> {
        if row < self.rows && col < self.cols {
            Some(self.data[row * self.cols + col])
        } else {
            None
        }
    }

    fn shape(&self) -> (usize, usize) {
        (self.rows, self.cols)
    }
}

// 3. Implement MatrixView for &Vec<Vec<f64>>
impl MatrixView<f64> for &Vec<Vec<f64>> {
    fn get(&self, row: usize, col: usize) -> Option<f64> {
        self.get(row).and_then(|r| r.get(col).cloned())
    }

    fn shape(&self) -> (usize, usize) {
        (self.len(), if self.is_empty() { 0 } else { self[0].len() })
    }
}

// 4. Generic dot product function
fn compute_dot_product<A, B>(a: A, b: B) -> Result<f64, String>
where
    A: MatrixView<f64>,
    B: MatrixView<f64>,
{
    let (rows_a, cols_a) = a.shape();
    let (rows_b, cols_b) = b.shape();

    if cols_a != rows_b {
        return Err(format!("Incompatible shapes: ({}, {}) x ({}, {})", rows_a, cols_a, rows_b, cols_b));
    }

    let mut sum = 0.0;
    for i in 0..rows_a {
        for j in 0..cols_b {
            // We assume dot product is on vectors, so we check 1D logic or specific indexing
            // For this exercise, let's calculate a specific element or simple sum
            // Let's implement a simple row-column dot product for the (0,0) element
            // to demonstrate usage.
            if i == 0 && j == 0 {
                for k in 0..cols_a {
                    if let (Some(val_a), Some(val_b)) = (a.get(i, k), b.get(k, j)) {
                        sum += val_a * val_b;
                    }
                }
            }
        }
    }
    // Returning the (0,0) element of the result matrix for simplicity
    Ok(sum)
}

fn main() {
    let t1 = Tensor { data: vec![1.0, 2.0, 3.0, 4.0], rows: 2, cols: 2 };
    let v1 = vec
![vec![1.0, 0.0], vec![0.0, 1.0]];

    // Test with Tensor
    let _ = compute_dot_product(&t1, &t1)
;

    // Test with Vec<Vec<f64>>
    let _ = compute_dot_product(&v1, &v1);
}
