
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.rs
// Description: Solution for Exercise 4
// ==========================================

use std::io::{self, Write};

struct SimulatorState {
    memory_usage: usize,
    has_data: bool, // Tracks if we currently "own" the data
}

fn main() {
    let mut state = SimulatorState { memory_usage: 0, has_data: false };
    let stdin = io::stdin();
    let mut stdout = io::stdout();

    println!("--- Memory Simulator ---");
    println!("Commands: load, clone, process_bad, process_good, reset, quit");
    println!("Goal: Process data 3 times without exceeding 250 MB.");
    println!("------------------------");

    loop {
        print!("> ");
        stdout.flush().unwrap();

        let mut input = String::new();
        stdin.read_line(&mut input).unwrap();
        let command = input.trim().to_lowercase();

        match command.as_str() {
            "load" => {
                if state.has_data {
                    println!("Error: Already own data. Cannot load without resetting or losing ownership.");
                } else {
                    state.memory_usage += 100;
                    state.has_data = true;
                    println!("Loaded 100MB. Total usage: {} MB", state.memory_usage);
                }
            }
            "clone" => {
                if state.has_data {
                    state.memory_usage += 100;
                    println!("Cloned data. Total usage: {} MB", state.memory_usage);
                } else {
                    println!("Error: No data to clone.");
                }
            }
            "process_bad" => {
                // Bad process takes ownership (simulated by consuming the flag)
                if state.has_data {
                    println!("Processing (Bad: Takes ownership)...");
                    state.has_data = false; // Ownership moved, we no longer have it here
                    println!("Data consumed. Memory remains at {} MB (leaked if not dropped properly, but here we just lose access).", state.memory_usage);
                } else {
                    println!("Error: No data to process.");
                }
            }
            "process_good" => {
                // Good process borrows (simulated by not changing ownership)
                if state.has_data {
                    println!("Processing (Good: Borrows)...");
                    println!("Data still available. Memory remains at {} MB.", state.memory_usage);
                } else {
                    println!("Error: No data to process.");
                }
            }
            "reset" => {
                state.memory_usage = 0;
                state.has_data = false;
                println!("System reset.");
            }
            "quit" => break,
            _ => println!("Unknown command."),
        }

        // Check win condition (conceptually, 3 successful processes)
        // We don't track count here strictly, just the memory constraint.
        if state.memory_usage > 250 {
            println!("--- GAME OVER: Memory limit exceeded ({} MB) ---", state.memory_usage);
            state.memory_usage = 0;
            state.has_data = false;
        }
    }
}
