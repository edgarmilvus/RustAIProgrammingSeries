
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.rs
// Description: Solution for Exercise 2
// ==========================================

use std::borrow::Cow;

// 1. & 2. Function signature using Cow
fn normalize<'a>(data: &'a [f32], needs_scaling: bool) -> Cow<'a, [f32]> {
    if needs_scaling {
        // 4. Owned case: Allocate new memory and transform data
        let scaled: Vec<f32> = data.iter().map(|&x| x * 2.0).collect();
        Cow::Owned(scaled)
    } else {
        // 3. Borrowed case: Zero-copy
        Cow::Borrowed(data)
    }
}

fn main() {
    let raw_data = vec
![1.0, 2.0, 3.0, 4.0];

    // 5. Test harness
    // Case 1: No scaling needed
    let result1 = normalize(&raw_data, false)
;
    println!("Case 1 (Borrowed): {:?}", result1);
    assert_eq!(result1.len(), 4);

    // Case 2: Scaling needed
    let result2 = normalize(&raw_data, true);
    println!("Case 2 (Owned): {:?}", result2);
    assert_eq!(result2[0], 2.0); // 1.0 * 2.0

    // Verify result2 is distinct from raw_data
    assert_ne!(raw_data[0], result2[0]);
}
