
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.rs
// Description: Solution for Exercise 3
// ==========================================

use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;

// Define the shared resources
struct Dataset {
    data: Vec<f32>,
}

struct BatchQueue {
    batches: Vec<Vec<f32>>,
}

/// Processes data by reading from dataset and writing to batch_queue.
/// 
/// # Deadlock Prevention Strategy
/// To prevent deadlocks, we must always acquire locks in a consistent order.
/// Here, we define the global order as: 
/// 1. Lock `Dataset` (Read)
/// 2. Process data (Scope block)
/// 3. Lock `BatchQueue` (Write)
/// 
/// By strictly following this order in *every* thread, we eliminate the 
/// circular wait condition required for a deadlock.
fn process_data(dataset: Arc<Mutex<Dataset>>, batch_queue: Arc<Mutex<BatchQueue>>) {
    // Step 1: Acquire lock on Dataset first.
    // We use a scoped block to ensure the lock is dropped immediately after use.
    let new_batch = {
        let data_guard = dataset.lock().unwrap();
        // Simulate reading and processing data
        // In a real scenario, this might be heavy computation
        thread::sleep(Duration::from_millis(10));
        
        // Extract a subset of data to form a batch
        // (Just taking the whole vec for simplicity)
        data_guard.data.clone()
    };

    // Step 2: Acquire lock on BatchQueue.
    // Note: The lock on `dataset` is released here because `data_guard` went out of scope.
    // Even if we held the dataset lock, as long as we lock BatchQueue *after* Dataset
    // in every thread, we are safe from deadlock (though inefficient).
    let mut queue_guard = batch_queue.lock().unwrap();
    queue_guard.batches.push(new_batch);
    println!("Thread {:?} added a batch. Queue size: {}", thread::current().id(), queue_guard.batches.len());
}

fn main() {
    // Initialize shared resources wrapped in Arc<Mutex<T>>
    let dataset = Arc::new(Mutex::new(Dataset { data: vec
![1.0, 2.0, 3.0, 4.0] }))
;
    let batch_queue = Arc::new(Mutex::new(BatchQueue { batches: vec
![] }))
;

    let mut handles = vec
![];

    // Spawn two threads that both need access to both resources
    for _ in 0..2 {
        let ds = Arc::clone(&dataset);
        let bq = Arc::clone(&batch_queue);

        let handle = thread::spawn(move || {
            // CRITICAL: Always lock in the same order (Dataset -> BatchQueue)
            process_data(ds, bq);
        });
        handles.push(handle);
    }

    for handle in handles {
        handle.join().unwrap();
    }

    // Verify results
    let final_queue = batch_queue.lock().unwrap();
    println!("Final batch count: {}", final_queue.batches.len());
}
