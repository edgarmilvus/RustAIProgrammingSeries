
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.rs
// Description: Solution for Exercise 4
// ==========================================

use std::io::{self, Write};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;
use rand::Rng;

struct ThreadSafeLogger {
    // We wrap Stdout in a Mutex to ensure exclusive access during writes.
    // Stdout is not thread-safe by default (buffer interleaving).
    stdout: Arc<Mutex<io::Stdout>>,
}

impl ThreadSafeLogger {
    fn new() -> Self {
        ThreadSafeLogger {
            stdout: Arc::new(Mutex::new(io::stdout())),
        }
    }

    fn log(&self, thread_id: usize, message: &str) {
        // 1. Acquire the lock.
        let mut guard = self.stdout.lock().unwrap();
        
        // 2. Format and write the message.
        // Using writeln! macro which locks internally, but we already hold the mutex.
        writeln!(guard, "[Thread {:2}]: {}", thread_id, message).unwrap();
        
        // 3. Flush immediately to ensure visibility.
        guard.flush().unwrap();
        
        // 4. Lock is released here when `guard` goes out of scope.
    }
}

fn main() {
    let logger = ThreadSafeLogger::new();
    let mut handles = vec
![];

    let num_threads = 10;
    let loops = 50;

    for i in 0..num_threads {
        // Clone the Arc to move into the thread
        let logger_handle = Arc::clone(&logger.stdout)
;
        
        handles.push(thread::spawn(move || {
            let rng = rand::thread_rng();
            
            // We reconstruct the logger logic inside the thread for simplicity,
            // or we could pass the struct. Here we use the struct method.
            // To use the struct method, we need to reconstruct ThreadSafeLogger 
            // or pass it. Let's pass the struct reference if possible, 
            // but since we moved the Arc, let's just use the logic directly 
            // or create a temporary logger struct.
            
            // Re-creating the struct wrapper for the moved Arc:
            let local_logger = ThreadSafeLogger { stdout: logger_handle };

            for j in 0..loops {
                // Random delay to simulate work and vary timing
                let delay = rng.gen_range(1..10);
                thread::sleep(Duration::from_millis(delay));

                // Log processing message
                local_logger.log(i, &format!("Processing batch {}...", j));

                // Short pause
                thread::sleep(Duration::from_millis(delay));

                // Log metrics
                local_logger.log(i, &format!("Metrics computed: loss={:.4}", (j as f32) * 0.01));
            }
        }));
    }

    for handle in handles {
        handle.join().unwrap();
    }
}
