
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.rs
// Description: Solution for Exercise 2
// ==========================================

use std::sync::{Arc, Mutex};

/// `Weights` holds the model parameters (weights).
#[derive(Clone, Debug)]
pub struct Weights {
    pub parameters: Vec<f32>,
}

/// `ParameterServer` manages shared model weights in a thread-safe manner.
/// 
/// # Why `Arc<Mutex<T>>`?
/// `Arc` (Atomically Reference Counted) allows multiple threads to own 
/// a reference to the same `Weights` data. `Mutex` (Mutual Exclusion) 
/// provides interior mutability, ensuring that only one thread can 
/// modify the weights at a time, preventing data races during gradient updates.
pub struct ParameterServer {
    // We wrap Weights in a Mutex for safe mutation, and Arc for shared ownership.
    weights: Arc<Mutex<Weights>>,
}

impl ParameterServer {
    /// Creates a new ParameterServer with initial weights.
    pub fn new(initial_weights: Vec<f32>) -> Self {
        ParameterServer {
            weights: Arc::new(Mutex::new(Weights {
                parameters: initial_weights,
            })),
        }
    }

    /// Updates the weights with gradients and returns the new weights.
    /// 
    /// # Arguments
    /// * `gradients` - A slice of f32 representing the gradients to add.
    /// 
    /// # Panics
    /// Panics if the length of `gradients` does not match the length of `weights`.
    pub fn update_and_get(&self, gradients: &[f32]) -> Vec<f32> {
        // Acquire the lock.
        let mut locked_weights = self.weights.lock().unwrap();

        // Panic safety check.
        if locked_weights.parameters.len() != gradients.len() {
            panic!(
                "Gradient length mismatch: expected {}, got {}",
                locked_weights.parameters.len(),
                gradients.len()
            );
        }

        // Perform the update: weights += gradients
        for (weight, grad) in locked_weights.parameters.iter_mut().zip(gradients.iter()) {
            *weight += grad;
        }

        // Return a clone of the updated weights.
        // We must clone because we cannot return a reference to data 
        // protected by a lock that will be released.
        locked_weights.parameters.clone()
    }
}

// Example usage (would typically be in integration tests or a binary)
#[cfg(test)]
mod tests {
    use super::*;
    use std::thread;

    #[test]
    fn test_parameter_server() {
        let initial_weights = vec
![1.0, 2.0, 3.0];
        let server = ParameterServer::new(initial_weights)
;
        let server_arc = Arc::new(server); // Usually wrapped in Arc if shared

        let mut handles = vec
![];

        // Simulate 2 threads sending gradients
        for i in 0..2 {
            let server_ref = Arc::clone(&server_arc);
            handles.push(thread::spawn(move || {
                let gradients = vec
![0.1 * i as f32, 0.2 * i as f32, 0.3 * i as f32];
                let updated = server_ref.update_and_get(&gradients);
                println!("Thread {}: Updated weights: {:?}", i, updated);
            }))
;
        }

        for handle in handles {
            handle.join().unwrap();
        }
    }
}
