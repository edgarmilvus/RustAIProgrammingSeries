
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};

// Define the cache structure
struct InferenceCache {
    // We wrap the HashMap in a Mutex for interior mutability
    // and Arc for shared ownership across threads.
    cache: Arc<Mutex<HashMap<String, String>>>,
}

impl InferenceCache {
    fn new() -> Self {
        InferenceCache {
            cache: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    /// Retrieves a cached value or computes it if missing.
    /// 
    /// # Arguments
    /// * `prompt` - The input key to look up.
    /// * `computation` - A closure representing the expensive model inference.
    fn get_or_compute<F>(&self, prompt: &str, computation: F) -> String
    where
        F: FnOnce() -> String,
    {
        // 1. Acquire the lock. This blocks other threads from accessing the cache.
        let mut cache_guard = self.cache.lock().unwrap();

        // 2. Check if the value exists.
        if let Some(result) = cache_guard.get(prompt) {
            // Cache hit: Return a clone of the value.
            // The lock is released when `cache_guard` goes out of scope.
            return result.clone();
        }

        // 3. Cache miss: Compute the value.
        // We drop the lock before computing to allow other threads 
        // to access the cache while this one computes.
        // However, for this specific pattern (Double-Checked Locking is tricky in Rust), 
        // we often compute inside the lock to prevent thundering herd, 
        // or drop the lock and re-acquire. 
        // Here, we will compute inside the lock for simplicity and consistency.
        
        let result = computation();
        
        // 4. Insert into cache.
        cache_guard.insert(prompt.to_string(), result.clone());

        result
    }
}

fn main() {
    let cache = InferenceCache::new();
    let mut handles = vec
![];

    // Prompts to test: duplicates will trigger cache hits.
    let prompts = vec
![
        "What is Rust?"
, 
        "Explain quantum physics", 
        "What is Rust?", // Duplicate
        "Explain quantum physics", // Duplicate
        "Write a poem", 
        "Write a poem"  // Duplicate
    ];

    let start_time = Instant::now();

    for (i, prompt) in prompts.into_iter().enumerate() {
        // Clone the Arc to move into the thread.
        let cache_handle = Arc::clone(&cache.cache);
        
        handles.push(thread::spawn(move || {
            let thread_start = Instant::now();
            
            // We need to access the cache method. Since `get_or_compute` takes `&self`,
            // we need a reference to the InferenceCache struct. 
            // To keep it simple, we'll reconstruct the logic or pass the struct.
            // For this exercise, let's pass the Arc directly and implement logic inline 
            // to demonstrate the locking mechanism clearly.
            
            let mut cache_guard = cache_handle.lock().unwrap();
            
            if let Some(result) = cache_guard.get(prompt) {
                // Cache Hit
                let duration = thread_start.elapsed();
                println!("[Thread {}] Cache HIT for '{}': {} (took {:?})", i, prompt, result, duration);
                return;
            }

            // Cache Miss - Simulate expensive computation
            // We release the lock during computation to allow others to check cache
            // But wait! If we release the lock, another thread might compute the same thing.
            // This is the "Thundering Herd" problem.
            // For this exercise, we will compute INSIDE the lock to ensure safety, 
            // though in real high-scale systems we might use a more complex pattern.
            
            thread::sleep(Duration::from_millis(50)); // Simulate inference time
            let result = format!("Result for '{}'", prompt);
            
            cache_guard.insert(prompt.to_string(), result.clone());
            
            let duration = thread_start.elapsed();
            println!("[Thread {}] Cache MISS for '{}': {} (took {:?})", i, prompt, result, duration);
        }));
    }

    for handle in handles {
        handle.join().unwrap();
    }

    println!("\nTotal execution time: {:?}", start_time.elapsed());
}
