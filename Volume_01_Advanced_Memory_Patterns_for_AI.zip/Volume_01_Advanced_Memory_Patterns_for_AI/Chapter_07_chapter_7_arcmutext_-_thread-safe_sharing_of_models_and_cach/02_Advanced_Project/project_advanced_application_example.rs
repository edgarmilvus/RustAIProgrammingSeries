
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};

/// Represents a complex AI model (e.g., a Transformer).
/// In a real scenario, this would hold heavy weights (Vec<f32>).
/// Here, we simulate it with a `cache` for performance.
struct AiModel {
    name: String,
    /// A cache mapping inputs to precomputed embeddings.
    /// `Mutex` is required here because we need to mutate this cache
    /// while multiple threads are reading it.
    embedding_cache: Mutex<Vec<(String, Vec<f32>)>>,
}

impl AiModel {
    fn new(name: &str) -> Self {
        Self {
            name: name.to_string(),
            embedding_cache: Mutex::new(Vec::new()),
        }
    }

    /// Simulates an expensive forward pass.
    /// This is a "read-only" operation on the model weights, 
    /// but we check the cache first.
    fn infer(&self, input: &str) -> Vec<f32> {
        // 1. Check Cache (Read Access)
        // We lock the mutex to read the cache. 
        // In a high-performance scenario, we might use a `RwLock` 
        // to allow multiple concurrent readers, but `Mutex` is simpler 
        // and often faster for uncontended access.
        let cache_guard = self.embedding_cache.lock().unwrap();
        
        if let Some(cached) = cache_guard.iter().find(|(k, _)| k == input) {
            println!("[{}] Cache hit for: {}", self.name, input);
            return cached.1.clone();
        }
        
        // Drop the lock immediately after reading to allow other threads to proceed.
        // This is critical to avoid blocking other readers while simulating compute.
        drop(cache_guard);

        // 2. Simulate Expensive Compute
        println!("[{}] Computing embedding for: {}", self.name, input);
        thread::sleep(Duration::from_millis(50)); // Simulate GPU/CPU time
        let embedding: Vec<f32> = input.bytes().map(|b| b as f32).collect();

        // 3. Update Cache (Write Access)
        // We need a mutable reference to the cache, so we lock again.
        let mut cache_guard = self.embedding_cache.lock().unwrap();
        cache_guard.push((input.to_string(), embedding.clone()));
        
        embedding
    }
}

/// The server manages the shared model and dispatches work.
struct InferenceServer {
    /// `Arc` allows multiple threads to own the `AiModel`.
    /// `Mutex` ensures safe mutation of the internal state.
    model: Arc<Mutex<AiModel>>,
}

impl InferenceServer {
    fn new(model_name: &str) -> Self {
        let model = Arc::new(Mutex::new(AiModel::new(model_name)));
        Self { model }
    }

    /// Starts the server with a fixed number of worker threads.
    /// This mimics a thread pool handling HTTP requests.
    fn start(&self, num_workers: usize) {
        println!("Starting Inference Server with {} workers...", num_workers);
        
        let mut handles = vec
![];

        // Create a set of sample queries to simulate incoming traffic.
        let queries = vec
![
            "hello", "world", "rust", "concurrency", 
            "ai", "model", "hello", "rust" // Duplicates to test cache
        ];

        for i in 0..num_workers {
            // Clone the Arc to move into the thread.
            // This increments the atomic reference count.
            let model_handle = Arc::clone(&self.model)
;
            
            // Distribute queries round-robin style to workers
            let query = queries[i % queries.len()].to_string();

            let handle = thread::spawn(move || {
                // Simulate a worker processing a request
                let start = Instant::now();
                
                // We need to lock the mutex to access the model.
                // The `lock()` method returns a `MutexGuard`.
                // When the guard goes out of scope, the lock is released automatically.
                let model_lock = model_handle.lock().unwrap();
                
                // Perform inference
                let _result = model_lock.infer(&query);
                
                // Explicitly drop the guard if we want to release the lock 
                // before the thread finishes other non-critical work.
                drop(model_lock);

                let duration = start.elapsed();
                println!("Worker {} finished in {:?}", i, duration);
            });

            handles.push(handle);
        }

        // Wait for all threads to complete
        for handle in handles {
            handle.join().unwrap();
        }
    }
}

fn main() {
    // 1. Initialize the server with a shared model.
    let server = InferenceServer::new("GPT-Neo-1.3B");

    // 2. Start the server with 5 concurrent workers.
    // This simulates 5 concurrent requests hitting the API.
    server.start(5);

    println!("\nServer simulation complete.");
}
