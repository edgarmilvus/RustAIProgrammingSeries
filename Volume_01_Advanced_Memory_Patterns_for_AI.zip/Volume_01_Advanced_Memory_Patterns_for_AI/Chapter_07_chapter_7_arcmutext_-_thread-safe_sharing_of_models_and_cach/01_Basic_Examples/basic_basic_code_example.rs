
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

/// A simple, thread-safe cache for storing inference results.
/// The cache maps a string query to a floating-point result.
/// We use `Arc` for shared ownership across threads and `Mutex` for interior mutability.
type SharedCache = Arc<Mutex<HashMap<String, f64>>>;

/// Simulates an expensive AI model inference.
/// In a real scenario, this would involve running a neural network forward pass.
/// Here, we just perform a blocking computation and sleep to simulate latency.
fn expensive_inference(query: &str) -> f64 {
    // Simulate computational work
    let result = query.len() as f64 * 3.14159;
    // Simulate network/processing latency
    std::thread::sleep(std::time::Duration::from_millis(100));
    println!("[Worker] Computed result for '{}': {:.2}", query, result);
    result
}

/// A worker task that processes a query.
/// It first checks the cache. If the result is present, it returns it immediately.
/// If not, it computes the result, inserts it into the cache, and then returns it.
/// This is a critical section protected by the `Mutex`.
async fn process_query(cache: SharedCache, query: String) -> f64 {
    // --- 1. Acquire the lock to check the cache ---
    // The `lock()` method blocks the current async task until the lock is acquired.
    // This returns a `MutexGuard`, which provides mutable access to the inner data.
    // The guard automatically releases the lock when it goes out of scope (RAII).
    let mut guard = cache.lock().await;

    // --- 2. Check if the result is already cached ---
    if let Some(&cached_result) = guard.get(&query) {
        println!("[Worker] Cache HIT for '{}': {:.2}", query, cached_result);
        return cached_result;
    }

    // --- 3. Cache MISS: Compute the result ---
    // We need to drop the lock guard here to avoid holding the lock during the
    // expensive computation, which would block other workers unnecessarily.
    // However, we still need to insert the result later. A common pattern is to
    // compute *while holding the lock* to prevent other workers from also computing
    // the same value (cache stampede). For simplicity in this example, we'll compute
    // it and then re-acquire the lock to insert. A more advanced pattern might use
    // a `tokio::sync::RwLock` or a more complex locking strategy.
    //
    // For this example, we will compute *outside* the lock to demonstrate the
    // potential for race conditions if not handled carefully. In a real system,
    // you might use a `tokio::sync::Mutex` with a `tokio::task::spawn_blocking`
    // to avoid blocking the async runtime, or a more advanced pattern like a
    // future-aware cache.
    
    // We must drop the guard to release the lock before computing.
    // If we don't, no other thread can read from the cache while we compute.
    drop(guard); 

    let computed_result = expensive_inference(&query);

    // --- 4. Re-acquire the lock to insert the new result ---
    let mut guard = cache.lock().await;
    guard.insert(query.clone(), computed_result);
    println!("[Worker] Cache INSERT for '{}'", query);

    computed_result
}

#[tokio::main]
async fn main() {
    // --- Shared State Initialization ---
    // `Arc` (Atomic Reference Counting) allows multiple owners of the same data.
    // `Mutex` provides interior mutability, ensuring only one thread can mutate
    // the data at a time, preventing data races.
    let shared_cache: SharedCache = Arc::new(Mutex::new(HashMap::new()));

    // --- Task Spawning ---
    // We simulate multiple concurrent requests to the inference server.
    let mut handles = vec
![];

    // A list of queries to process. Some are duplicated to demonstrate caching.
    let queries = vec
![
        "What is the capital of France?"
.to_string(),
        "What is 2 + 2?".to_string(),
        "What is the capital of France?".to_string(), // Duplicate
        "Explain quantum computing.".to_string(),
        "What is 2 + 2?".to_string(), // Duplicate
    ];

    for query in queries {
        // Clone the Arc for each task. This increments the reference count,
        // but the underlying data is still the same single instance.
        let cache_clone = Arc::clone(&shared_cache);
        
        // Spawn an asynchronous task for each query.
        let handle = tokio::spawn(async move {
            process_query(cache_clone, query).await
        });
        handles.push(handle);
    }

    // --- Await Completion ---
    // Wait for all spawned tasks to finish and collect their results.
    let results = futures::future::join_all(handles).await;

    // --- Final Output ---
    println!("\n--- All Inference Tasks Completed ---");
    for (i, result) in results.iter().enumerate() {
        match result {
            Ok(val) => println!("Task {}: Result = {:.2}", i, val),
            Err(e) => println!("Task {}: Error = {}", i, e),
        }
    }

    // --- Inspect Final Cache State ---
    // We can still access the cache here because `shared_cache` is still in scope.
    // The `Arc` ensures the data is not deallocated until the last reference is dropped.
    let final_guard = shared_cache.lock().await;
    println!("\n--- Final Cache Contents ({} entries) ---", final_guard.len());
    for (key, value) in final_guard.iter() {
        println!("  '{}': {:.2}", key, value);
    }
}
