
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

// main.rs
// A high-performance, zero-copy token ID processing pipeline.
// This example demonstrates how to use slices (`&[u32]`) to process
// token IDs from a large dataset without unnecessary memory allocation.

use std::time::Instant;

/// Represents a batch of token IDs in a high-throughput inference pipeline.
/// In a real scenario, this data might come from a network request or a disk read.
/// We use `Vec<u32>` here to simulate owning the raw data buffer.
struct TokenBatch {
    buffer: Vec<u32>,
}

impl TokenBatch {
    /// Creates a new TokenBatch with a given size (simulating a data load).
    fn new(size: usize) -> Self {
        // Simulate loading data: fill with sequential token IDs.
        let buffer: Vec<u32> = (0..size as u32).collect();
        TokenBatch { buffer }
    }

    /// Retrieves a zero-copy view of a specific window of tokens.
    /// This is the core zero-copy operation: it returns a slice `&[u32]`
    /// pointing into the existing `self.buffer` memory.
    ///
    /// # Arguments
    /// * `start` - The starting index of the window.
    /// * `len` - The number of tokens in the window.
    ///
    /// # Returns
    /// A slice containing the requested tokens, or `None` if the range is invalid.
    fn get_window(&self, start: usize, len: usize) -> Option<&[u32]> {
        let end = start + len;
        // Check if the requested range is within the bounds of the buffer.
        if end <= self.buffer.len() {
            // Return a slice pointing to the memory region [start..end).
            // This operation is O(1) and involves no memory copying.
            Some(&self.buffer[start..end])
        } else {
            None
        }
    }

    /// Processes a slice of tokens.
    /// This function accepts `&[u32]` instead of `Vec<u32>`, allowing it to work
    /// with any contiguous sequence of tokens without taking ownership.
    /// This is crucial for performance in data pipelines.
    fn process_tokens(&self, tokens: &[u32]) {
        // Simulate some processing logic (e.g., embedding lookup or model inference).
        // Here, we just sum the tokens as a placeholder for computation.
        let _sum: u32 = tokens.iter().sum();
        // In a real scenario, you might iterate and perform lookups:
        // for token_id in tokens { ... }
    }
}

fn main() {
    // 1. Setup: Create a large dataset (e.g., a batch of 10,000 tokens).
    // In a real inference server, this might be a request containing a long text sequence.
    let total_tokens = 10_000;
    let batch = TokenBatch::new(total_tokens);
    println!("Created a token batch with {} tokens.", total_tokens);

    // 2. Zero-Copy Slicing: Extract windows of data without cloning.
    // We simulate processing the data in smaller chunks (e.g., sliding windows).
    let window_size = 512;
    let stride = 256; // Overlap between windows

    let start_time = Instant::now();

    // Iterate over the batch using windows.
    // This pattern is common in transformer models for processing long sequences.
    let mut start_index = 0;
    while start_index + window_size <= batch.buffer.len() {
        // CRITICAL ZERO-COPY OPERATION:
        // `get_window` returns a slice `&[u32]` that borrows from `batch.buffer`.
        // No data is copied here. We are just creating a new "view" into existing memory.
        if let Some(window_slice) = batch.get_window(start_index, window_size) {
            // Pass the slice to the processing function.
            // Again, no copying occurs; the function receives a reference to the data.
            batch.process_tokens(window_slice);
            
            // Move to the next window (sliding window approach).
            start_index += stride;
        }
    }

    let duration = start_time.elapsed();
    println!("Processed {} windows in {:?}", (start_index / stride), duration);

    // 3. Demonstrating Slice Flexibility:
    // Slices can be passed to functions that expect them, or used directly.
    let full_slice: &[u32] = &batch.buffer;
    println!("Full slice length: {}", full_slice.len());

    // You can also create sub-slices manually using range syntax.
    let first_10_tokens: &[u32] = &batch.buffer[0..10];
    println!("First 10 tokens: {:?}", first_10_tokens);
}
