
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.rs
// Description: Solution for Exercise 4
// ==========================================

// Cargo.toml dependencies:
// [dependencies]
// clap = { version = "4.0", features = ["derive"] }
// serde = { version = "1.0", features = ["derive"] }
// serde_json = "1.0"

use clap::Parser;
use serde::Deserialize;
use std::fs::File;
use std::io::{self, Read};

// Define the CLI arguments structure using clap.
#[derive(Parser, Debug)]
#[command(author, version, about, long_about = None)]
struct Args {
    /// Path to the JSON file containing token IDs.
    #[arg(short, long)]
    file: String,

    /// Window to analyze in the format "start:size". Optional.
    /// If not provided, the entire token list is analyzed.
    #[arg(short, long)]
    window: Option<String>,
}

// Helper function to parse the "start:size" window string.
fn parse_window(window_str: &str) -> Result<(usize, usize), String> {
    let parts: Vec<&str> = window_str.split(':').collect();
    if parts.len() != 2 {
        return Err("Invalid window format. Use 'start:size'.".to_string());
    }
    let start = parts[0]
        .parse::<usize>()
        .map_err(|_| "Invalid start index".to_string())?;
    let size = parts[1]
        .parse::<usize>()
        .map_err(|_| "Invalid window size".to_string())?;
    Ok((start, size))
}

// Helper function to compute and print statistics for a slice of tokens.
// This function operates entirely on a slice, fulfilling the zero-copy mandate.
fn print_stats(tokens: &[u32]) {
    if tokens.is_empty() {
        println!("The selected window is empty.");
        return;
    }

    let length = tokens.len();
    
    // Calculate min, max, and sum in a single pass for efficiency.
    let (min, max, sum) = tokens.iter().fold(
        (u32::MAX, u32::MIN, 0u64), // Use u64 for sum to prevent overflow
        |(min, max, sum), &val| {
            (
                min.min(val),
                max.max(val),
                sum + val as u64,
            )
        },
    );

    let avg = sum as f32 / length as f32;

    println!("--- Window Statistics ---");
    println!("Length: {}", length);
    println!("Min Token ID: {}", min);
    println!("Max Token ID: {}", max);
    println!("Average Token ID: {:.2}", avg);
    println!("-------------------------");
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args = Args::parse();

    // Read the entire file content.
    let mut file = File::open(&args.file)?;
    let mut contents = String::new();
    file.read_to_string(&mut contents)?;

    // Parse the JSON into an owned Vec<u32>.
    let all_tokens: Vec<u32> = serde_json::from_str(&contents)?;

    // Determine the slice to process based on the CLI arguments.
    let tokens_to_process: &[u32] = match &args.window {
        Some(window_str) => {
            match parse_window(window_str) {
                Ok((start, size)) => {
                    // Here we use the logic from Exercise 1 to get the slice.
                    // This is a zero-copy operation.
                    let end_index = std::cmp::min(start + size, all_tokens.len());
                    if start >= all_tokens.len() {
                        eprintln!("Error: Start index {} is out of bounds for a token list of length {}.", start, all_tokens.len());
                        std::process::exit(1);
                    }
                    &all_tokens[start..end_index]
                }
                Err(e) => {
                    eprintln!("Error parsing window: {}", e);
                    std::process::exit(1);
                }
            }
        }
        None => {
            // If no window is provided, use the entire slice.
            &all_tokens
        }
    };

    // Calculate and print statistics on the slice.
    print_stats(tokens_to_process);

    Ok(())
}
