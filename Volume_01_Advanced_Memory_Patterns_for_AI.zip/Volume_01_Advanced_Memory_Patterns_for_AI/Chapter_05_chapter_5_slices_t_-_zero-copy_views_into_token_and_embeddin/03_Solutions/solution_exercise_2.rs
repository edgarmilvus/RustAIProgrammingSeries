
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.rs
// Description: Solution for Exercise 2
// ==========================================

/// Views a flat slice of floats as a matrix and returns a specific row (chunk).
/// 
/// # Arguments
/// * `embeddings` - A flat slice representing the concatenated embedding vectors.
/// * `dim` - The dimensionality (number of elements) of each embedding vector.
/// * `chunk_index` - The 0-based index of the desired embedding vector.
/// 
/// # Returns
/// An `Option` containing a slice of the specific embedding vector if valid, otherwise `None`.
fn get_embedding_chunk(embeddings: &[f32], dim: usize, chunk_index: usize) -> Option<&[f32]> {
    // 1. Calculate the start index.
    // We use checked multiplication and addition to prevent potential overflow 
    // and to verify bounds in a single step.
    let start = match chunk_index.checked_mul(dim) {
        Some(index) => index,
        None => return None, // Handles integer overflow
    };

    // 2. Calculate the end index.
    let end = start + dim;

    // 3. Check if the calculated range is within the bounds of the slice.
    // If `end` is greater than `embeddings.len()`, the chunk is incomplete or invalid.
    if end > embeddings.len() {
        return None;
    }

    // 4. Return the slice.
    // This creates a view into the existing memory without copying data.
    Some(&embeddings[start..end])
}
