
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.rs
// Description: Solution for Exercise 3
// ==========================================

/// Merges a specific pair of consecutive tokens into a new ID, writing to a buffer.
/// 
/// # Arguments
/// * `tokens` - The input slice of token IDs.
/// * `buffer` - A mutable slice used to store the result. Must be large enough.
/// * `pair` - A tuple `(u32, u32)` representing the tokens to merge.
/// * `new_id` - The new token ID to replace the pair with.
/// 
/// # Returns
/// A slice (`&[u32]`) containing the merged sequence.
fn merge_tokens(tokens: &[u32], buffer: &mut [u32], pair: (u32, u32), new_id: u32) -> &[u32] {
    let mut write_index = 0;
    let mut read_index = 0;

    // Iterate through the tokens using a sliding window approach.
    while read_index < tokens.len() {
        // Check if we have at least two tokens remaining to form a pair.
        if read_index + 1 < tokens.len() {
            // Check if the current window matches the target pair.
            if tokens[read_index] == pair.0 && tokens[read_index + 1] == pair.1 {
                // Match found: write the new ID to the buffer.
                buffer[write_index] = new_id;
                write_index += 1;
                // Skip the next token in the input since it's part of the merge.
                read_index += 2;
                continue;
            }
        }
        
        // No match (or single token left): copy the current token as-is.
        buffer[write_index] = tokens[read_index];
        write_index += 1;
        read_index += 1;
    }

    // Return a slice of the buffer containing the valid data.
    &buffer[0..write_index]
}
