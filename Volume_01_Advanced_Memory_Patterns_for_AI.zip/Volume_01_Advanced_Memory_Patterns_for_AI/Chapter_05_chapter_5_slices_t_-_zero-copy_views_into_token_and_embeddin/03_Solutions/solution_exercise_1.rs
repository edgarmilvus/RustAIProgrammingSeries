
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

/// Returns a zero-copy slice representing a context window from the token sequence.
/// 
/// # Arguments
/// * `tokens` - A slice of token IDs.
/// * `start_index` - The starting index of the window.
/// * `window_size` - The desired size of the window.
/// 
/// # Returns
/// A slice containing up to `window_size` elements starting from `start_index`.
/// If `start_index` is out of bounds, returns an empty slice.
/// If the window extends beyond the slice, returns the slice from `start_index` to the end.
fn get_context_window(tokens: &[u32], start_index: usize, window_size: usize) -> &[u32] {
    // 1. Handle the case where the start index is beyond the length of the tokens.
    // Since we are working with unsigned integers (usize), we don't need to check 
    // for negative indices. If start_index > tokens.len(), the range `start_index..`
    // will be empty, but we explicitly handle it for clarity and safety.
    if start_index >= tokens.len() {
        return &[];
    }

    // 2. Calculate the end index.
    // We use std::cmp::min to ensure we don't try to index past the end of the slice.
    // This handles the boundary condition where `start_index + window_size` exceeds `tokens.len()`.
    let end_index = std::cmp::min(start_index + window_size, tokens.len());

    // 3. Return the subslice.
    // Rust's slicing syntax `&tokens[start..end]` is panic-safe here because 
    // we have already guaranteed that `start_index` is valid and `end_index` is clamped.
    &tokens[start_index..end_index]
}
