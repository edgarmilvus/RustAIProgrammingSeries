
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

/// A high-performance token processing pipeline.
/// 
/// This struct holds the owned `Vec<u32>` representing token IDs.
/// In a real scenario, this buffer might be pre-allocated and reused 
/// to avoid allocator churn (Arena/Linear Allocator pattern).
pub struct TokenPipeline {
    tokens: Vec<u32>,
    /// Metadata to simulate token boundaries in a batch.
    batch_boundaries: Vec<usize>,
}

impl TokenPipeline {
    /// Creates a new pipeline with a pre-allocated capacity.
    pub fn new(capacity: usize) -> Self {
        Self {
            tokens: Vec::with_capacity(capacity),
            batch_boundaries: Vec::new(),
        }
    }

    /// Simulates ingesting raw text and tokenizing it.
    /// In reality, this would interface with a tokenizer like `tokenizers` or `tiktoken`.
    /// Here, we just generate dummy IDs.
    pub fn ingest(&mut self, text: &str) {
        // Simulate tokenization: hash characters to u32 IDs
        let start_idx = self.tokens.len();
        for char in text.chars() {
            // Keep IDs small for demo
            self.tokens.push(char as u32 % 1000); 
        }
        self.batch_boundaries.push(start_idx);
    }

    /// **Zero-Copy Accessor**
    /// Retrieves a specific window of tokens as a slice.
    /// 
    /// # Arguments
    /// * `start` - Index of the first token.
    /// * `len` - Number of tokens in the window.
    /// 
    /// # Returns
    /// `Some(&[u32])` if the range is valid, otherwise `None`.
    /// 
    /// # Under the Hood
    /// This function performs bounds checking (which is safe) but does not 
    /// allocate memory. It constructs a slice fat pointer pointing directly 
    /// into the `self.tokens` heap memory.
    pub fn get_window(&self, start: usize, len: usize) -> Option<&[u32]> {
        let end = start + len;
        if end <= self.tokens.len() {
            Some(&self.tokens[start..end])
        } else {
            None
        }
    }

    /// Retrieves a slice for the entire sequence.
    pub fn as_slice(&self) -> &[u32] {
        &self.tokens[..]
    }

    /// **Advanced Pattern: Batch Processing**
    /// Iterates over defined batch boundaries and returns slices for each batch.
    /// This allows parallel processing of different batches without copying data.
    pub fn iter_batches(&self) -> BatchIterator<'_> {
        BatchIterator {
            tokens: &self.tokens,
            boundaries: &self.batch_boundaries,
            index: 0,
        }
    }
}

/// Iterator that yields zero-copy slices for each batch.
pub struct BatchIterator<'a> {
    tokens: &'a [u32],
    boundaries: &'a [usize],
    index: usize,
}

impl<'a> Iterator for BatchIterator<'a> {
    type Item = &'a [u32];

    fn next(&mut self) -> Option<Self::Item> {
        if self.index >= self.boundaries.len() {
            return None;
        }

        let start = self.boundaries[self.index];
        // Calculate end based on next boundary or end of tokens
        let end = if self.index + 1 < self.boundaries.len() {
            self.boundaries[self.index + 1]
        } else {
            self.tokens.len()
        };

        self.index += 1;
        Some(&self.tokens[start..end])
    }
}

/// Simulates a downstream consumer (e.g., an Embedding Layer).
/// It accepts a slice of tokens and processes them.
/// Note: It takes `&[u32]`, not `Vec<u32>`, proving zero-copy capability.
fn compute_embeddings(token_slice: &[u32]) -> Vec<f32> {
    // In a real scenario, this would look up a weight matrix.
    // Here, we just convert IDs to floats to simulate the output.
    token_slice.iter().map(|&id| id as f32 * 0.01).collect()
}

fn main() {
    println!("--- Initializing Token Pipeline ---");
    let mut pipeline = TokenPipeline::new(1024);

    // 1. Ingest Data
    pipeline.ingest("The quick brown fox jumps over the lazy dog.");
    pipeline.ingest("Rust enables memory safety without garbage collection.");
    
    println!("Total tokens stored: {}", pipeline.as_slice().len());

    // 2. Zero-Copy Windowing (Sliding Window Example)
    // We want to process the first 5 tokens without allocating a new Vec.
    if let Some(window) = pipeline.get_window(0, 5) {
        println!("\n--- Sliding Window (0..5) ---");
        println!("Slice content: {:?}", window);
        
        // We can pass this slice directly to a computation function.
        let embeddings = compute_embeddings(window);
        println!("Computed embeddings: {:?}", embeddings);
    }

    // 3. Batch Iteration
    // Process the data in chunks defined during ingestion.
    println!("\n--- Batch Processing ---");
    for (i, batch) in pipeline.iter_batches().enumerate() {
        println!("Batch {}: {:?} (Length: {})", i, batch, batch.len());
        
        // Perform computation on the batch slice
        let _ = compute_embeddings(batch);
    }

    // 4. Demonstrating Mutability Constraints
    // If we tried to modify the pipeline while holding a slice, Rust prevents it.
    // let window = pipeline.get_window(0, 5).unwrap();
    // pipeline.ingest("New data"); // Error: cannot borrow `pipeline` as mutable because it is also borrowed as immutable
    
    println!("\n--- Pipeline Processing Complete ---");
}
