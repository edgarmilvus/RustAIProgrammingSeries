
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.rs
// Description: Solution for Exercise 2
// ==========================================

use std::ops::Range;

#[derive(Debug)]
struct StridedView<'a, T> {
    data: &'a [T],
    rows: usize,
    cols: usize,
    row_stride: usize,
    col_stride: usize,
}

impl<'a, T> StridedView<'a, T> {
    fn new(data: &'a [T], rows: usize, cols: usize) -> Self {
        Self {
            data,
            rows,
            cols,
            row_stride: cols, // Default row-major: next row is 'cols' elements away
            col_stride: 1,    // Next col is 1 element away
        }
    }

    fn get(&self, row: usize, col: usize) -> Option<&T> {
        if row >= self.rows || col >= self.cols {
            return None;
        }
        // Calculate index using strides
        let index = (row * self.row_stride) + (col * self.col_stride);
        self.data.get(index)
    }

    // O(1) Transposition: Swap dimensions and strides
    fn transpose(&self) -> StridedView<'a, T> {
        StridedView {
            data: self.data,
            rows: self.cols,    // Rows become cols
            cols: self.rows,    // Cols become rows
            row_stride: self.col_stride, // Row stride becomes old col stride
            col_stride: self.row_stride, // Col stride becomes old row stride
        }
    }

    // Creates a sub-view without copying data
    fn slice(&self, row_range: Range<usize>, col_range: Range<usize>) -> StridedView<'a, T> {
        // Calculate the new starting offset in the underlying data
        // Start offset = (start_row * row_stride) + (start_col * col_stride)
        let start_offset = (row_range.start * self.row_stride) + (col_range.start * self.col_stride);
        
        // The new data slice starts at the calculated offset
        let new_data = &self.data[start_offset..];
        
        // Adjust dimensions
        let new_rows = row_range.end - row_range.start;
        let new_cols = col_range.end - col_range.start;

        StridedView {
            data: new_data,
            rows: new_rows,
            cols: new_cols,
            row_stride: self.row_stride,
            col_stride: self.col_stride,
        }
    }
}

fn main() {
    // Create a flat vector: 0..12
    let data: Vec<i32> = (0..12).collect();
    
    // View as 3x4 matrix
    let view = StridedView::new(&data, 3, 4);
    
    println!("Original View (3x4):");
    println!("Element (0, 0): {:?}", view.get(0, 0).unwrap()); // Should be 0
    println!("Element (2, 3): {:?}", view.get(2, 3).unwrap()); // Should be 11
    
    // Transpose: becomes 4x3
    let transposed = view.transpose();
    println!("\nTransposed View (4x3):");
    println!("Element (0, 0): {:?}", transposed.get(0, 0).unwrap()); // Still 0
    println!("Element (3, 2): {:?}", transposed.get(3, 2).unwrap()); // Should be 11
    
    // Slice: rows 1..3, cols 1..3 (2x2 submatrix)
    // Original data:
    // 0  1  2  3
    // 4  5  6  7
    // 8  9  10 11
    // Slice should be [[5, 6], [9, 10]]
    let sliced = view.slice(1..3, 1..3);
    println!("\nSliced View (2x2):");
    println!("Element (0, 0): {:?}", sliced.get(0, 0).unwrap()); // Should be 5
    println!("Element (1, 1): {:?}", sliced.get(1, 1).unwrap()); // Should be 10
}
