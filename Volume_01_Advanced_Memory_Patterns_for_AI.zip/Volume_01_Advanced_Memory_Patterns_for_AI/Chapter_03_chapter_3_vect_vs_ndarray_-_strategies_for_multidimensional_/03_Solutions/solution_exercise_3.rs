
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.rs
// Description: Solution for Exercise 3
// ==========================================

use clap::Parser;
use memmap2::MmapOptions;
use std::fs::File;
use std::io::Write;
use std::path::PathBuf;
use anyhow::{Context, Result};

#[derive(Parser, Debug)]
#[command(author, version, about, long_about = None)]
struct Args {
    /// Path to input CSV file
    #[arg(short, long)]
    input: PathBuf,

    /// Path to output binary file
    #[arg(short, long)]
    output: PathBuf,

    /// Target shape dimensions (e.g., "64 64 3")
    #[arg(short, long, num_args = 1.., value_delimiter = ' ')]
    shape: Vec<usize>,

    /// Use row-major (C-style) ordering. Defaults to column-major (Fortran-style) if false.
    #[arg(short, long)]
    row_major: bool,
}

fn main() -> Result<()> {
    let args = Args::parse();

    // 1. Validate shape
    if args.shape.is_empty() {
        anyhow::bail!("Shape must contain at least one dimension");
    }
    let total_elements: usize = args.shape.iter().product();

    // 2. Memory map input file
    let file = File::open(&args.input).context("Failed to open input file")?;
    let mmap = unsafe { MmapOptions::new().map(&file)? };
    
    // Convert memory map to string and parse CSV
    // Note: For very large files, a streaming parser is better, but for this exercise,
    // we assume the file fits in memory or is small enough for string conversion.
    let csv_content = std::str::from_utf8(&mmap).context("Invalid UTF-8 in CSV")?;
    
    let values: Vec<f32> = csv_content
        .lines()
        .filter_map(|line| line.trim().parse::<f32>().ok())
        .collect();

    // 3. Validate data count
    if values.len() != total_elements {
        anyhow::bail!(
            "Shape product ({}) does not match data length ({})",
            total_elements,
            values.len()
        );
    }

    // 4. Prepare output buffer
    let mut output_file = File::create(&args.output).context("Failed to create output file")?;
    
    // We will write the data in the requested order.
    // Since we already have a flat Vec<f32> of the source data, we need to 
    // remap indices if the output requires a different layout than the input (assumed row-major).
    
    if args.row_major {
        // Row-major output: Write the flat vector as-is (assuming input was row-major)
        // If input was conceptually column-major, we would need to permute here.
        // For this exercise, we assume the CSV is a flat stream, and we interpret it into the shape.
        let bytes = unsafe { std::slice::from_raw_parts(values.as_ptr() as *const u8, values.len() * 4) };
        output_file.write_all(bytes)?;
    } else {
        // Column-major output (Fortran-style)
        // We need to write elements such that the first axis changes fastest.
        // Example: Shape (2, 3) -> Indices: (0,0), (1,0), (0,1), (1,1), (0,2), (1,2)
        
        // Calculate strides for the output layout
        let mut strides = vec
![0; args.shape.len()];
        let mut stride = 1;
        // In column-major, the last dimension (columns)
 is contiguous (stride 1),
        // the second to last has stride = dim_last, etc.
        for i in (0..args.shape.len()).rev() {
            strides[i] = stride;
            stride *= args.shape[i];
        }

        // Create a buffer to hold the reordered data
        let mut reordered = vec
![0.0f32; total_elements];

        // Iterate over the logical shape to determine where each source element goes
        // We iterate through the source linearly (0..N)
 and map to the logical coordinates of the destination.
        for (src_idx, &val) in values.iter().enumerate() {
            // Calculate coordinates in the destination shape based on row-major assumption of source
            let mut coords = vec
![0; args.shape.len()];
            let mut temp = src_idx;
            for i in (0..args.shape.len())
.rev() {
                coords[i] = temp % args.shape[i];
                temp /= args.shape[i];
            }

            // Calculate destination index using column-major strides
            let mut dest_idx = 0;
            for i in 0..args.shape.len() {
                dest_idx += coords[i] * strides[i];
            }
            
            reordered[dest_idx] = val;
        }
        
        let bytes = unsafe { std::slice::from_raw_parts(reordered.as_ptr() as *const u8, reordered.len() * 4) };
        output_file.write_all(bytes)?;
    }

    println!("Successfully wrote {} elements to {}", total_elements, args.output.display());
    Ok(())
}

/*
 * Example Usage:
 * // Create a dummy CSV
 * $ seq 1 100 | tr '\n' ',' | sed 's/,$//' > data.csv
 * 
 * // Run tool (Row-major 5x5x4)
 * $ cargo run -- --input data.csv --output tensor.bin --shape 5 5 4 --row-major
 * 
 * // Run tool (Column-major 5x5x4)
 * $ cargo run -- --input data.csv --output tensor.bin --shape 5 5 4
 */
