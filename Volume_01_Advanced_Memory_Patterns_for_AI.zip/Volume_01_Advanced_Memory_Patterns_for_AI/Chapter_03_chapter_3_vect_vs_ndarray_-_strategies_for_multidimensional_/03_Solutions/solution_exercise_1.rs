
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

use std::time::Instant;

struct Matrix {
    data: Vec<f64>,
    rows: usize,
    cols: usize,
}

impl Matrix {
    fn new(rows: usize, cols: usize) -> Self {
        let data = vec
![0.0; rows * cols];
        Self { data, rows, cols }
    }

    // Naive transpose: Reads row-wise, writes column-wise (stride-heavy)
    fn transpose_naive(&self)
 -> Matrix {
        let mut dest = Matrix::new(self.cols, self.rows);
        let start = Instant::now();

        for i in 0..self.rows {
            for j in 0..self.cols {
                // Source: row-major access (good)
                let src_val = self.data[i * self.cols + j];
                // Dest: column-major access (bad: stride = dest.cols)
                dest.data[j * dest.cols + i] = src_val;
            }
        }
        
        println!("Naive transpose took: {:?}", start.elapsed());
        dest
    }

    // Cache-aware transpose: Uses blocking (tiling) strategy
    fn transpose_tiled(&self) -> Matrix {
        const BLOCK_SIZE: usize = 32; // Fits comfortably in L1 cache
        let mut dest = Matrix::new(self.cols, self.rows);
        let start = Instant::now();

        // Iterate over blocks
        for i_block in (0..self.rows).step_by(BLOCK_SIZE) {
            for j_block in (0..self.cols).step_by(BLOCK_SIZE) {
                // Iterate within the block
                let i_max = (i_block + BLOCK_SIZE).min(self.rows);
                let j_max = (j_block + BLOCK_SIZE).min(self.cols);

                for i in i_block..i_max {
                    for j in j_block..j_max {
                        let src_val = self.data[i * self.cols + j];
                        dest.data[j * dest.cols + i] = src_val;
                    }
                }
            }
        }

        println!("Tiled transpose took: {:?}", start.elapsed());
        dest
    }
}

fn main() {
    // 2048x2048 matrix (approx 32MB for f64)
    let size = 2048;
    let mut matrix = Matrix::new(size, size);
    
    // Initialize with some data
    for (i, val) in matrix.data.iter_mut().enumerate() {
        *val = i as f64;
    }

    println!("--- Matrix Transpose Benchmark (2048x2048) ---");
    
    // Run naive
    let _ = matrix.transpose_naive();
    
    // Run tiled
    let _ = matrix.transpose_tiled();
}

/*
 * Instructor's Analysis:
 * 
 * 1. Data Layout: We use a flat Vec<f64> representing a row-major 2D matrix.
 *    Index (i, j) is mapped to i * cols + j.
 * 
 * 2. Naive Implementation:
 *    - The inner loop reads `src[i * cols + j]` sequentially (stride 1). 
 *      This is cache-friendly because CPUs fetch cache lines (typically 64 bytes) 
 *      containing adjacent elements.
 *    - However, it writes to `dest[j * dest.cols + i]`. Since `dest.cols` is large (2048),
 *      the write stride is 2048 * 8 bytes = 16KB. This jumps over huge chunks of memory.
 *    - Result: Every write likely misses the cache, forcing expensive RAM access.
 * 
 * 3. Tiled Implementation:
 *    - We divide the matrix into small blocks (32x32).
 *    - The inner loops iterate over a small sub-matrix.
 *    - When we access `dest.data[j * dest.cols + i]` inside a block, the offset `j` is small (0-31).
 *      The stride is still technically large, but because we process the block compactly,
 *      the data remains in the L1/L2 cache during the block's processing.
 *    - This maximizes spatial locality for both reads and writes within the cache line.
 * 
 * 4. Performance Expectation:
 *    - For a 2048x2048 matrix (32MB), the naive version will thrash the cache (working set > L3).
 *    - The tiled version keeps the working set of the destination block inside L1 cache.
 *    - The tiled version is expected to be significantly faster (often 5x-10x faster).
 */
