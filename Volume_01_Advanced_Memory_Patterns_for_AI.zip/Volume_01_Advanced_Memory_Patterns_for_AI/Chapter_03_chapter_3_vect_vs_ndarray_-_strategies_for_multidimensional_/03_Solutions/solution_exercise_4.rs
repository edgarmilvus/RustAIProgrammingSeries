
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.rs
// Description: Solution for Exercise 4
// ==========================================

use ndarray::{Array, Array3, Axis, ShapeBuilder};

fn main() {
    // 1. Data Generation
    let size = 1_000_000;
    let data_vec: Vec<f32> = (0..size as f32).collect();

    // 2. Initial Reshape
    // We want a shape of (100, 100, 100) -> 1,000,000 elements.
    // Note: into_shape() returns a Result. If the memory is contiguous (which it is),
    // it succeeds without copying.
    let array_3d: Array3<f32> = Array::from_shape_vec((100, 100, 100), data_vec).unwrap();

    println!("Original Array Shape: {:?}", array_3d.shape());
    println!("Original Array Address: {:p}", array_3d.as_ptr());

    // 3. Zero-Copy Slicing
    // Slice the central 50x50 region of the first "depth" (index 0 along axis 2).
    // Slicing returns a View (ArrayView), which is a reference to the data.
    let slice_view = array_3d.slice(s![25..75, 25..75, 0]);
    
    println!("\nSliced Array Shape: {:?}", slice_view.shape());
    println!("Sliced Array Address: {:p}", slice_view.as_ptr());
    // Note: The address should be offset by (25 * 100 + 25) * 4 bytes from original.

    // 4. Permutation (Transpose)
    // Swap axes to change layout from (Depth, Height, Width) to (Height, Width, Depth)
    // This creates a new view with different strides.
    let permuted_view = array_3d.permuted_axes([1, 2, 0]); 

    println!("\nPermuted Array Shape: {:?}", permuted_view.shape());
    println!("Permuted Array Address: {:p}", permuted_view.as_ptr());
    
    // 5. Verification
    // All pointers should point to the same underlying memory allocation,
    // though the slice pointer will be offset.
    assert_eq!(array_3d.as_ptr(), permuted_view.as_ptr());
    
    println!("\n--- Verification ---");
    println!("Original and Permuted share memory: {}", 
        std::ptr::eq(array_3d.as_ptr(), permuted_view.as_ptr()));
    
    // Accessing elements to ensure correctness
    // Original (0,0,0) is 0.0
    // Permuted (0,0,0) maps to (0,0,0) in original -> 0.0
    println!("Value at (0,0,0) in permuted: {}", permuted_view[[0, 0, 0]]);
    
    // Original (1,2,3) is calculated: 1*100*100 + 2*100 + 3 = 10203
    // In permuted (2,3,1) -> (2,3,1) in original
    println!("Value at (2,3,1) in permuted: {}", permuted_view[[2, 3, 1]]);
}
