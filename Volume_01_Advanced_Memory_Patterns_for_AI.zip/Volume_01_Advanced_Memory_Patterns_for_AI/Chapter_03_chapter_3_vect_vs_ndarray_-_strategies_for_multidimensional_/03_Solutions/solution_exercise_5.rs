
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.rs
// Description: Solution for Exercise 5
// ==========================================

use std::time::Instant;
use rand::Rng;

fn main() {
    // Configuration
    // 100 million u64s is ~800 MB, exceeding typical L3 caches (30-80MB)
    let n_elements: usize = 100_000_000;
    
    println!("--- Memory Access Pattern Benchmark ---");
    println!("Allocating {:.2} MB...", (n_elements * 8) as f64 / 1_000_000.0);

    // Allocate and initialize
    // We use Box<[u64]> to ensure it is on the heap and pinned (prevents relocation during bench)
    let mut data = vec
![0u64; n_elements];
    // Initialize with non-zero values to prevent optimization from removing reads
    for i in 0..n_elements {
        data[i] = i as u64;
    }

    // Prepare random indices for the random access test
    let mut rng = rand::thread_rng();
    let random_indices: Vec<usize> = (0..n_elements)
        .map(|_| rng.gen_range(0..n_elements))
        .collect();

    let mut choice = 'y';
    while choice == 'y' {
        println!("\nRunning benchmarks (Iterations per pattern: 10)...");
        
        // 1. Sequential Access (Row-Major)
        // This is ideal for hardware prefetchers.
        let start = Instant::now();
        let mut sum = 0u64;
        for _ in 0..10 {
            for &val in &data {
                sum += val;
            }
        }
        let seq_time = start.elapsed().as_millis();
        println!("Sequential:  {:>8} ms (Sum: {})", seq_time, sum);

        // 2. Strided Access (Column-Major simulation)
        // We simulate a 2D access by jumping by a large stride.
        // For a 10000x10000 matrix, stride is 10000.
        let stride = 10000;
        let start = Instant::now();
        let mut sum = 0u64;
        for _ in 0..10 {
            // We only iterate as far as the stride allows to stay in bounds
            for i in (0..n_elements).step_by(stride) {
                sum += data[i];
            }
        }
        let stride_time = start.elapsed().as_millis();
        println!("Strided:     {:>8} ms (Stride: {})", stride_time, stride);

        // 3. Random Access
        // This causes constant cache misses and TLB (Translation Lookaside Buffer) misses.
        let start = Instant::now();
        let mut sum = 0u64;
        for _ in 0..10 {
            for &idx in &random_indices {
                sum += data[idx];
            }
        }
        let rand_time = start.elapsed().as_millis();
        println!("Random:      {:>8} ms (Sum: {})", rand_time, sum);

        println!("\nRun again? (y/n): ");
        let mut input = String::new();
        std::io::stdin().read_line(&mut input).unwrap();
        choice = input.trim().chars().next().unwrap_or('n');
    }
}

/*
 * Instructor's Analysis:
 * 
 * 1. Cache Hierarchy & Prefetching:
 *    - Sequential access is fastest because the CPU hardware prefetcher detects the pattern
 *      and fetches data from RAM into L3/L2/L1 caches before the program requests it.
 *    - Strided access (large stride) defeats the prefetcher. The CPU requests address A, 
 *      then A+Stride. By the time it requests A+Stride, the cache line containing A+Stride 
 *      hasn't been fetched yet (or was evicted), causing a cache miss.
 * 
 * 2. Data Size vs Cache:
 *    - With 800MB of data, the dataset is much larger than the L3 cache (typically 16-80MB).
 *    - Sequential access still performs well because RAM bandwidth is high, and prefetching hides latency.
 *    - Strided access performs poorly because every access is likely a "cold miss" or "capacity miss".
 * 
 * 3. Random Access:
 *    - This is the worst case. It causes "streaming" behavior where every access requests a 
 *      different cache line. This floods the memory bus with requests and creates high latency.
 *    - It also causes TLB misses (page table lookups), adding significant overhead.
 * 
 * 4. Expected Results:
 *    - Sequential << Strided << Random
 *    - The exact numbers depend on the specific CPU (M1/M2 vs Intel vs AMD) and RAM speed,
 *      but the relative ratios often show sequential being 5x-10x faster than strided, 
 *      and 10x-20x faster than random.
 */
