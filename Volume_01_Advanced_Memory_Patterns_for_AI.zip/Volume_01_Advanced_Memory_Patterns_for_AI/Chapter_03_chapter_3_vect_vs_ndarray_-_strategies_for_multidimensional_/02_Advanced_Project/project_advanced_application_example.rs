
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

/// memory_patterns_demo/src/main.rs
///
/// This application demonstrates memory layout strategies for high-dimensional data
/// (specifically image batches) in a high-performance context.
///
/// # Concepts Demonstrated
/// 1.  **Flat `Vec<T>` vs. Strided `ndarray`**: Comparing raw pointer access vs. stride-based access.
/// 2.  **Cache Locality**: How data layout impacts iteration speed.
/// 3.  **Zero-Copy Views**: Using `ndarray` to slice sub-regions without cloning data.

use ndarray::{Array3, Axis, s};
use rand::Rng;
use std::time::Instant;

/// Configuration for the synthetic dataset.
const BATCH_SIZE: usize = 32;
const HEIGHT: usize = 224;
const WIDTH: usize = 224;
const CHANNELS: usize = 1; // Grayscale

/// ---------------------------------------------------------------------------
/// 1. VEC STRATEGY (Flat Memory)
/// ---------------------------------------------------------------------------
///
/// Represents a batch of images stored in a flat `Vec<f32>`.
/// Memory Layout (Row-Major): [Batch 0 Row 0, Batch 0 Row 1, ..., Batch N Row H]
///
/// Pros:
/// - Minimal overhead (just the vector).
/// - Extremely cache-friendly for sequential iteration.
/// Cons:
/// - Manual index calculation required.
/// - No inherent dimension safety (easy to mix up H/W).
#[derive(Debug, Clone)]
struct FlatImageBatch {
    data: Vec<f32>,
    batch: usize,
    height: usize,
    width: usize,
}

impl FlatImageBatch {
    /// Generates synthetic data.
    fn generate(batch: usize, height: usize, width: usize) -> Self {
        let size = batch * height * width;
        let mut rng = rand::thread_rng();
        let data = (0..size).map(|_| rng.gen::<f32>()).collect();
        Self { data, batch, height, width }
    }

    /// Performs normalization (0.0 - 1.0 -> -1.0 - 1.0) using manual index arithmetic.
    /// This is O(N) where N is total pixels.
    fn normalize_inplace(&mut self) {
        let total_pixels = self.batch * self.height * self.width;
        // Direct memory access is fast, but we must calculate the index manually.
        for i in 0..total_pixels {
            self.data[i] = self.data[i] * 2.0 - 1.0;
        }
    }

    /// Applies a simple 3x3 box blur kernel to the center pixel of every image.
    /// This demonstrates the complexity of manual boundary checking and index math.
    fn apply_box_blur(&self) -> FlatImageBatch {
        let mut result = FlatImageBatch::generate(self.batch, self.height, self.width);
        
        // Iterate over batches
        for b in 0..self.batch {
            // Iterate over pixels (excluding borders for simplicity)
            for y in 1..(self.height - 1) {
                for x in 1..(self.width - 1) {
                    let mut sum = 0.0;
                    // 3x3 Kernel loop
                    for ky in 0..3 {
                        for kx in 0..3 {
                            // Calculate source index manually
                            let src_y = y + ky - 1;
                            let src_x = x + kx - 1;
                            let src_idx = (b * self.height * self.width) 
                                        + (src_y * self.width) 
                                        + src_x;
                            sum += self.data[src_idx];
                        }
                    }
                    // Calculate destination index
                    let dst_idx = (b * self.height * self.width) + (y * self.width) + x;
                    result.data[dst_idx] = sum / 9.0;
                }
            }
        }
        result
    }
}

/// ---------------------------------------------------------------------------
/// 2. NDARRAY STRATEGY (Strided Memory)
/// ---------------------------------------------------------------------------
///
/// Represents a batch of images using `ndarray::Array3<f32>`.
/// Shape: [Batch, Height, Width]
/// Strides: Calculated automatically based on memory layout (Row-major by default).
///
/// Pros:
/// - Dimension safety (compile-time shape checks available).
/// - Ergonomic slicing (views).
/// - Optimized iterators that match raw pointer performance.
/// Cons:
/// - Slight metadata overhead (storing strides).
/// - Learning curve for the API.
struct NdarrayImageBatch {
    data: Array3<f32>,
}

impl NdarrayImageBatch {
    /// Generates synthetic data.
    fn generate(batch: usize, height: usize, width: usize) -> Self {
        let mut rng = rand::thread_rng();
        // ndarray::random is available, but we'll use standard generation for clarity
        let data = Array3::from_shape_fn((batch, height, width), |_| rng.gen::<f32>());
        Self { data }
    }

    /// Performs normalization using ndarray's vectorized operations.
    /// This leverages SIMD (Single Instruction, Multiple Data) implicitly.
    fn normalize_inplace(&mut self) {
        // `*=` broadcasts the scalar operation across the entire array.
        // This is significantly more concise and often faster than manual loops
        // due to compiler auto-vectorization.
        self.data = &self.data * 2.0 - 1.0;
    }

    /// Applies a box blur using slicing and sliding windows.
    /// This demonstrates the power of "Views" (zero-copy).
    fn apply_box_blur(&self) -> Self {
        // We create a new array for the result.
        let mut result = Array3::zeros(self.data.raw_dim());

        // Iterate over the batch dimension
        for mut image in self.data.axis_iter_mut(Axis(0)) {
            // We cannot blur the edges easily with simple slicing, 
            // so we iterate over the inner region.
            for y in 1..(HEIGHT - 1) {
                for x in 1..(WIDTH - 1) {
                    // Create a view of the 3x3 neighborhood.
                    // This is ZERO-COPY. It just calculates pointers and strides.
                    let window = image.slice(s![
                        (y - 1)..=(y + 1),
                        (x - 1)..=(x + 1)
                    ]);
                    
                    // Calculate the mean. `iter().sum()` is highly optimized.
                    let mean = window.iter().sum::<f32>() / 9.0;
                    
                    // Assign to result (requires mutable access to the specific image slice)
                    // Note: In a real optimized loop, we might index directly to avoid 
                    // the overhead of creating the view struct repeatedly, 
                    // but this illustrates the API.
                    result[[0, y, x]] = mean; // Simplified for single batch logic in loop
                }
            }
        }
        // Note: The loop above is simplified for demonstration. 
        // In production, `ndarray` offers `windowing` iterators or `convolution` methods.
        result
    }
    
    /// A more idiomatic approach using `mapv` for normalization (alternative to normalize_inplace)
    fn normalize_idiomatic(&self) -> Self {
        Self {
            data: self.data.mapv(|x| x * 2.0 - 1.0)
        }
    }
}

/// ---------------------------------------------------------------------------
/// 3. MAIN EXECUTION & BENCHMARK
/// ---------------------------------------------------------------------------
fn main() {
    println!("=== Memory Pattern Strategy Benchmark ===");
    println!("Dataset: {}x{}x{} (Batch x Height x Width)", BATCH_SIZE, HEIGHT, WIDTH);
    println!("Total Elements: {:.2}M\n", (BATCH_SIZE * HEIGHT * WIDTH) as f32 / 1_000_000.0);

    // --- 1. VEC STRATEGY EXECUTION ---
    let start = Instant::now();
    let mut flat_batch = FlatImageBatch::generate(BATCH_SIZE, HEIGHT, WIDTH);
    flat_batch.normalize_inplace();
    let _blurred_flat = flat_batch.apply_box_blur();
    let vec_duration = start.elapsed();
    println!("Vec Strategy Time: {:?}", vec_duration);

    // --- 2. NDARRAY STRATEGY EXECUTION ---
    let start = Instant::now();
    let mut ndarray_batch = NdarrayImageBatch::generate(BATCH_SIZE, HEIGHT, WIDTH);
    ndarray_batch.normalize_inplace();
    // Note: The blur implementation in ndarray is illustrative; 
    // in reality, we would use crate `imageproc` or `convolution`.
    let _blurred_ndarray = ndarray_batch.apply_box_blur();
    let ndarray_duration = start.elapsed();
    println!("Ndarray Strategy Time: {:?}", ndarray_duration);

    // --- 3. ZERO-COPY VIEW DEMONSTRATION ---
    // This is where `ndarray` shines. We can take a slice of the data without copying.
    let start = Instant::now();
    let batch_view = &ndarray_batch.data;
    
    // Extract the first image (Shape: [224, 224])
    let first_image = batch_view.index_axis(Axis(0), 0);
    
    // Extract a region (ROI) from the first image (Shape: [50, 50])
    // This creates a new view struct, but the underlying data pointer is shared.
    let roi = first_image.slice(s![50..100, 50..100]);
    
    // Perform an operation on the ROI
    let roi_mean = roi.mean().unwrap();
    
    let view_duration = start.elapsed();
    
    println!("\n=== Zero-Copy View Analysis ===");
    println!("ROI Mean Value: {:.4}", roi_mean);
    println!("View Extraction Time: {:?}", view_duration);
    println!("ROI Shape: {:?}", roi.shape());
    println!("ROI is a view (no allocation): true");
    
    println!("\n=== Summary ===");
    println!("Vec: Best for raw speed in simple iteration, but requires manual index math.");
    println!("Ndarray: Best for complex dimension manipulation, slicing, and safety.");
}
