
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

/// A high-performance matrix struct using a flat Vec for storage.
/// This represents the "manual index arithmetic" approach.
struct FlatMatrix {
    data: Vec<f32>,
    rows: usize,
    cols: usize,
}

impl FlatMatrix {
    /// Creates a new matrix initialized with zeros.
    /// Memory is allocated once on the heap.
    fn new(rows: usize, cols: usize) -> Self {
        Self {
            data: vec
![0.0; rows * cols],
            rows,
            cols,
        }
    }

    /// Performs matrix-vector multiplication: y = A * x
    /// This is a critical operation in neural networks (e.g., a dense layer)
.
    /// 
    /// # Performance Note
    /// Accessing elements via `self.data[idx]` is extremely fast, but calculating
    /// `row * self.cols + col` on every access introduces minor arithmetic overhead
    /// and requires the compiler to prove no aliasing exists for optimization.
    fn multiply(&self, vector: &[f32]) -> Vec<f32> {
        assert_eq!(self.cols, vector.len(), "Dimension mismatch");
        
        let mut result = vec
![0.0; self.rows];

        // Manual iteration over rows
        for row in 0..self.rows {
            let row_offset = row * self.cols; // Pre-calculate offset for cache locality
            let mut sum = 0.0;

            // Manual iteration over columns
            for col in 0..self.cols {
                // Index calculation: row-major order
                let idx = row_offset + col;
                sum += self.data[idx] * vector[col];
            }
            result[row] = sum;
        }
        result
    }
}

/// A wrapper around ndarray::Array2 for comparison.
/// This represents the "structured abstraction" approach.
struct NdArrayMatrix {
    data: ndarray::Array2<f32>,
}

impl NdArrayMatrix {
    /// Creates a new matrix using ndarray's allocator.
    /// Note: ndarray also uses a flat Vec internally by default.
    fn new(rows: usize, cols: usize) -> Self {
        Self {
            data: ndarray::Array2::zeros((rows, cols)),
        }
    }

    /// Performs matrix-vector multiplication using ndarray's safe indexing.
    /// 
    /// # Performance Note
    /// `ndarray` uses Strided Array views. While `row(i)` creates a view (zero-copy),
    /// the dot product operation leverages optimized BLAS routines if linked,
    /// or highly optimized iterators that the compiler can auto-vectorize easily.
    fn multiply(&self, vector: &ndarray::Array1<f32>) -> ndarray::Array1<f32> {
        assert_eq!(self.data.shape()[1], vector.len(), "Dimension mismatch");

        // ndarray allows functional, high-level operations.
        // This is often more readable and less prone to off-by-one errors.
        self.data.dot(vector)
    }
}

fn main() {
    // --- Context: Inference Server Setup ---
    // We are loading a model layer with 1024 inputs and 512 outputs.
    let rows = 512;
    let cols = 1024;

    println!("--- Initializing Matrices ---");
    
    // 1. The Flat Vec Approach
    let mut flat_mat = FlatMatrix::new(rows, cols);
    // Simulate loading weights (random values)
    for i in 0..flat_mat.data.len() {
        flat_mat.data[i] = i as f32 * 0.001;
    }

    // 2. The ndarray Approach
    let mut nd_mat = NdArrayMatrix::new(rows, cols);
    // Simulate loading weights
    for mut row in nd_mat.data.rows_mut() {
        for (j, val) in row.iter_mut().enumerate() {
            *val = j as f32 * 0.001;
        }
    }

    // Input vector (batch size 1)
    let input_data: Vec<f32> = (0..cols).map(|i| i as f32).collect();
    let input_nd = ndarray::Array1::from_vec(input_data.clone());

    println!("--- Running Inference ---");

    // Run Flat Matrix Inference
    let start = std::time::Instant::now();
    let result_flat = flat_mat.multiply(&input_data);
    let duration_flat = start.elapsed();
    println!("Flat Vec multiplication took: {:?}", duration_flat);

    // Run ndarray Inference
    let start = std::time::Instant::now();
    let result_nd = nd_mat.multiply(&input_nd);
    let duration_nd = start.elapsed();
    println!("ndarray multiplication took: {:?}", duration_nd);

    // Verification (sanity check)
    // We compare the first element of the result to ensure logic is sound.
    // Note: Floating point precision might differ slightly depending on optimization levels.
    println!("--- Results ---");
    println!("Flat result (first 5): {:?}", &result_flat[..5]);
    println!("ndarray result (first 5): {:?}", result_nd.slice(ndarray::s
![..5])
);
}
