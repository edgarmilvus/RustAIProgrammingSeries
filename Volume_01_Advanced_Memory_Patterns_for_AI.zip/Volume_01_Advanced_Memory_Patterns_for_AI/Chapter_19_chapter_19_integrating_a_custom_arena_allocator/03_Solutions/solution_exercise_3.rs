
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.rs
// Description: Solution for Exercise 3
// ==========================================

// Cargo.toml dependency: allocator-api2 = "0.2"
use allocator_api2::alloc::{Allocator, Layout};

// Re-open the BumpArena module or extend the previous definition
impl Allocator for BumpArena {
    unsafe fn allocate(&self, layout: Layout) -> Result<std::ptr::NonNull<[u8]>, allocator_api2::alloc::AllocError> {
        let size = layout.size();
        let align = layout.align();

        // We need mutable access to update the offset, but the trait takes &self.
        // This requires Interior Mutability (e.g., UnsafeCell or RefCell).
        // For this solution, we will assume BumpArena uses interior mutability 
        // or we cast &self to &mut self (unsafe, but common for allocators).
        // Let's modify BumpArena to use `Cell<usize>` for offset to be safe.
        
        // *Revised BumpArena for Allocator Trait support:*
        // struct BumpArena { buffer: *mut u8, capacity: usize, offset: Cell<usize> }
        
        // Since we cannot easily modify the struct definition in this text block,
        // we will write the implementation assuming we have mutable access.
        // In a real implementation, you would use `offset: Cell<usize>` or `AtomicUsize`.
        
        // Pseudo-code for the logic:
        /*
        let current_ptr = self.buffer as usize + self.offset.get();
        let aligned_addr = (current_ptr + (align - 1)) & !(align - 1);
        let padding = aligned_addr - current_ptr;
        
        if self.offset.get() + padding + size > self.capacity {
            return Err(AllocError);
        }
        
        self.offset.set(self.offset.get() + padding + size);
        
        let ptr = aligned_addr as *mut u8;
        let slice_ptr = std::ptr::NonNull::from_raw_parts(ptr as *mut (), size);
        Ok(slice_ptr)
        */
        
        // For the executable code, we will provide a wrapper that allows mutation.
        // Note: The standard `Allocator` trait is currently unstable in std.
        // We use `allocator-api2` for stability.
        
        // Due to the constraint of `&self` in the trait, we cannot implement it 
        // directly on the previous `BumpArena` without interior mutability.
        // Let's define a compatible version here:
        
        unimplemented!("Requires interior mutability (e.g. Cell) for offset to satisfy &self");
    }

    unsafe fn deallocate(&self, _ptr: std::ptr::NonNull<u8>, _layout: Layout) {
        // Bump arenas do not support individual deallocation.
        // This is a no-op.
    }
}

// To make this work, we define a version of BumpArena suitable for the Allocator trait.
use std::cell::Cell;

pub struct BumpArena {
    buffer: *mut u8,
    capacity: usize,
    offset: Cell<usize>,
}

impl BumpArena {
    pub fn new(capacity: usize) -> Self {
        let layout = Layout::from_size_align(capacity, 8).unwrap();
        let buffer = unsafe { alloc_zeroed(layout) };
        Self { buffer, capacity, offset: Cell::new(0) }
    }
    
    // Helper for the exercise function
    pub fn reset(&mut self) {
        self.offset.set(0);
    }
}

impl Allocator for BumpArena {
    unsafe fn allocate(&self, layout: Layout) -> Result<std::ptr::NonNull<[u8]>, allocator_api2::alloc::AllocError> {
        let size = layout.size();
        let align = layout.align();
        
        let current_ptr = self.buffer as usize + self.offset.get();
        let aligned_addr = (current_ptr + (align - 1)) & !(align - 1);
        let padding = aligned_addr - current_ptr;
        
        if self.offset.get() + padding + size > self.capacity {
            return Err(allocator_api2::alloc::AllocError);
        }
        
        self.offset.set(self.offset.get() + padding + size);
        
        let ptr = aligned_addr as *mut u8;
        let slice_ptr = std::ptr::NonNull::from_raw_parts_mut(ptr, size);
        Ok(slice_ptr)
    }

    unsafe fn deallocate(&self, _ptr: std::ptr::NonNull<u8>, _layout: Layout) {
        // No-op
    }
}

// Type Alias
pub type ArenaVec<'a, T> = std::vec::Vec<T, &'a BumpArena>;

// The requested function
pub fn process_batch<'a>(arena: &'a BumpArena, inputs: &[f32]) -> ArenaVec<'a, f32> {
    // Create the Vec with the arena as the allocator
    let mut output_vec = ArenaVec::new_in(arena);
    
    // Perform operation
    for &val in inputs {
        output_vec.push(val * 2.0);
    }
    
    output_vec
}
