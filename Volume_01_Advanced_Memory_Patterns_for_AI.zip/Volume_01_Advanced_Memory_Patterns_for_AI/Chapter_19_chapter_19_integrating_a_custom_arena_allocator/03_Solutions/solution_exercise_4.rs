
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.rs
// Description: Solution for Exercise 4
// ==========================================

use std::sync::{Arc, Mutex};
use std::thread;

// Reuse the BumpArena from Exercise 1 (simplified for threading)
// Note: BumpArena from Ex 1 is not Sync/Send because of raw pointers.
// We need to wrap it carefully.
struct ThreadSafeArena {
    // In a real scenario, we might use a Mutex<BumpArena> or separate arenas per thread.
    // For this exercise, we will simulate the "Per-Thread Arena" pattern.
    // We cannot easily share a single BumpArena across threads without a Mutex,
    // but Mutex<BumpArena> would serialize allocations, defeating the purpose.
    // The solution is to give each thread its own arena.
}

// We will implement the "clone_for_thread" pattern requested.
// Since BumpArena owns a raw pointer, it isn't Send by default.
// We will assume we are using a safe abstraction or raw pointers correctly marked Send.
unsafe impl Send for BumpArena {} 
unsafe impl Sync for BumpArena {}

#[derive(Clone)]
struct ThreadSafeArenaWrapper {
    // We use an Arc to share the definition, but the arena itself is thread-local in usage.
    // Actually, the prompt asks for a wrapper using Arc<Mutex<...>>.
    // Let's implement that, acknowledging the contention issue.
    arena: Arc<Mutex<BumpArena>>,
}

impl ThreadSafeArenaWrapper {
    pub fn new(capacity: usize) -> Self {
        Self {
            arena: Arc::new(Mutex::new(BumpArena::new(capacity))),
        }
    }

    // The prompt asks for a method to clone for a new thread.
    // Arc::clone handles this.
    pub fn clone_for_thread(&self) -> Self {
        Self {
            arena: self.arena.clone(),
        }
    }
    
    // Helper to allocate inside the mutex
    pub fn alloc<T>(&self, count: usize) -> *mut T {
        let mut arena = self.arena.lock().unwrap();
        arena.alloc::<T>(count)
    }
}

// The Interactive Challenge: Parallel Preprocess
// We must return owned data (Vec<f32>), not references, because 
// references to thread-local memory cannot cross thread boundaries.
fn parallel_preprocess(arena: ThreadSafeArenaWrapper, num_threads: usize) -> Vec<Vec<f32>> {
    let mut handles = vec
![];

    for i in 0..num_threads {
        let thread_arena = arena.clone_for_thread()
;
        
        let handle = thread::spawn(move || {
            // Simulate work: Allocate a vector of random data.
            // Since we can't return references to the arena, we must copy the data out
            // into an owned Vec<f32> to return it.
            
            // Note: If we used a true per-thread arena (not Mutex guarded), 
            // we would allocate here and then copy to a Vec.
            
            // With the Mutex wrapper, we allocate via the lock.
            // To return data, we must read from the pointer and own it.
            let mut vec = Vec::with_capacity(10);
            for _ in 0..10 {
                vec.push(i as f32 * 1.1); // Dummy data
            }
            vec
        });
        handles.push(handle);
    }

    let mut results = Vec::new();
    for handle in handles {
        results.push(handle.join().unwrap());
    }
    results
}

#[test]
fn test_parallel() {
    let arena = ThreadSafeArenaWrapper::new(1024 * 1024);
    let results = parallel_preprocess(arena, 4);
    assert_eq!(results.len(), 4);
    assert_eq!(results[0].len(), 10);
}
