
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

use std::alloc::{alloc_zeroed, Layout};
use std::ptr;

pub struct BumpArena {
    buffer: *mut u8,
    capacity: usize,
    offset: usize,
}

impl BumpArena {
    /// Allocates a buffer of the specified size using the global allocator.
    pub fn new(capacity: usize) -> Self {
        // Safety: We assume the system allocator returns a valid pointer for the layout.
        // We use alloc_zeroed to initialize memory to 0, which is safer for raw pointers.
        let layout = Layout::from_size_align(capacity, 8).unwrap();
        let buffer = unsafe { alloc_zeroed(layout) };
        
        Self {
            buffer,
            capacity,
            offset: 0,
        }
    }

    /// Allocates memory for `count` elements of type `T`.
    pub fn alloc<T>(&mut self, count: usize) -> *mut T {
        let size = std::mem::size_of::<T>() * count;
        let align = std::mem::align_of::<T>();

        // Calculate the layout for the requested allocation.
        // unwrap() is safe here because size and align are valid for T.
        let layout = Layout::from_size_align(size, align).unwrap();

        // Calculate the current bump pointer address.
        let current_ptr = self.buffer as usize + self.offset;
        
        // Calculate the aligned address.
        // The formula (addr + (align - 1)) & !(align - 1) rounds up to the next alignment boundary.
        let aligned_addr = (current_ptr + (align - 1)) & !(align - 1);
        
        // Calculate the padding needed to reach the aligned address.
        let padding = aligned_addr - current_ptr;
        
        // Check for sufficient capacity.
        if self.offset + padding + size > self.capacity {
            panic!("Arena out of memory");
        }

        // Update the bump pointer.
        self.offset += padding + size;

        // Return the aligned pointer cast to *mut T.
        // Safety: The pointer is within the bounds of the allocated buffer and is properly aligned.
        (aligned_addr as *mut u8) as *mut T
    }

    /// Resets the bump pointer to the start of the buffer.
    /// This effectively "frees" all memory.
    pub fn reset(&mut self) {
        self.offset = 0;
    }
}

// Safety: BumpArena manages a unique pointer to heap memory. 
// It does not implement Drop to avoid double-free if raw pointers are leaked,
// but we implement a manual cleanup method for demonstration.
impl Drop for BumpArena {
    fn drop(&mut self) {
        // Safety: We are deallocating the memory we allocated in `new`.
        // This is safe only if no references to this memory exist elsewhere.
        let layout = Layout::from_size_align(self.capacity, 8).unwrap();
        unsafe {
            std::alloc::dealloc(self.buffer, layout);
        }
    }
}
