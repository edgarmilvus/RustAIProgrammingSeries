
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.rs
// Description: Solution for Exercise 5
// ==========================================

use std::fmt;

// We need a struct to track allocation metadata for visualization
struct AllocationRecord {
    type_name: String,
    size: usize,
    align: usize,
    start_addr: usize,
    padding: usize,
}

pub fn run_visualization_simulation() {
    // Simulate a buffer at address 0x1000
    let buffer_start = 0x1000;
    let mut current_offset = 0;
    
    let mut records = Vec::new();

    // 1. Allocate a u32 (size 4, align 4)
    // Address 0x1000 is already aligned to 4.
    let size = 4;
    let align = 4;
    let start_addr = buffer_start + current_offset;
    current_offset += size;
    records.push(AllocationRecord { 
        type_name: "u32".to_string(), size, align, start_addr, padding: 0 
    });

    // 2. Allocate a u8 (size 1, align 1)
    // Next address is 0x1004.
    let size = 1;
    let align = 1;
    let start_addr = buffer_start + current_offset;
    current_offset += size;
    records.push(AllocationRecord { 
        type_name: "u8".to_string(), size, align, start_addr, padding: 0 
    });

    // 3. Allocate a f64 (size 8, align 8)
    // Current address is 0x1005. Needs alignment to 0x1008.
    let size = 8;
    let align = 8;
    let current_addr = buffer_start + current_offset;
    let aligned_addr = (current_addr + (align - 1)) & !(align - 1);
    let padding = aligned_addr - current_addr;
    current_offset += padding + size;
    
    records.push(AllocationRecord { 
        type_name: "f64".to_string(), size, align, start_addr: aligned_addr, padding 
    });

    // Generate DOT output
    println!("digraph ArenaLayout {{");
    println!("    rankdir=TB;");
    println!("    node [shape=record];");
    println!("    subgraph cluster_arena {{");
    println!("        label=\"BumpArena Memory Buffer (Start: 0x{:X})\";", buffer_start);
    println!("        style=filled;");
    println!("        color=lightgrey;");
    println!("        node [style=filled, color=white];");

    for rec in records {
        // Calculate end address for visualization
        let end_addr = rec.start_addr + rec.size;
        
        // Create a label showing details
        // If there was padding, we might want to visualize it as a separate node or label
        if rec.padding > 0 {
            println!("        \"padding_{}\" [label=\"Padding|{} bytes\", style=dashed, color=grey];", 
                     rec.start_addr - rec.padding, rec.padding);
        }

        println!("        \"alloc_{}\" [label=\"{{{}|{} bytes|Addr: 0x{:X}}}\"];", 
                 rec.start_addr, rec.type_name, rec.size, rec.start_addr);
    }

    println!("    }}");
    println!("}}");
}

// To run this, call run_visualization_simulation() in main or a test.
// Output example (simplified):
// digraph ArenaLayout {
//     rankdir=TB;
//     node [shape=record];
//     subgraph cluster_arena {
//         label="BumpArena Memory Buffer (Start: 0x1000)";
//         style=filled;
//         color=lightgrey;
//         node [style=filled, color=white];
//         "alloc_4096" [label="{u32|4 bytes|Addr: 0x1000}"];
//         "alloc_4100" [label="{u8|1 bytes|Addr: 0x1004}"];
//         "padding_4101" [label="Padding|3 bytes", style=dashed, color=grey];
//         "alloc_4104" [label="{f64|8 bytes|Addr: 0x1008}"];
//     }
// }
