
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

// Cargo.toml (for reference only, not part of the executable code)
// [package]
// name = "arena_example"
// version = "0.1.0"
// edition = "2021"
// 
// [dependencies]
// No external dependencies required for this example.

use std::alloc::{alloc, dealloc, Layout};
use std::mem;
use std::ptr;
use std::sync::Mutex;

/// A simple bump-pointer arena allocator for high-throughput memory management.
/// 
/// This allocator allocates from a contiguous block of memory, "bumping" a pointer
/// forward for each allocation. It's ideal for short-lived objects in AI inference
/// pipelines, where allocations are freed all at once (e.g., per request).
/// 
/// # Safety Notes
/// - Allocations are not aligned beyond the layout's alignment; users must handle alignment.
/// - No deallocation of individual pointers; the entire arena is dropped at once.
/// - Thread-safe via Mutex, but for production, consider lock-free or per-thread arenas.
struct BumpArena {
    /// The base pointer to the allocated memory block.
    ptr: *mut u8,
    /// Current allocation pointer (bumps forward on each alloc).
    current: *mut u8,
    /// End of the arena (ptr + size).
    end: *mut u8,
    /// Total size of the arena in bytes.
    size: usize,
}

impl BumpArena {
    /// Creates a new arena with the specified capacity.
    /// 
    /// # Arguments
    /// * `capacity` - Size in bytes. Must be > 0.
    /// 
    /// # Panics
    /// If allocation fails (e.g., out of memory) or capacity is 0.
    /// 
    /// # Example
    /// 