
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

use std::alloc::{GlobalAlloc, Layout, System};
use std::cell::UnsafeCell;
use std::mem;
use std::ptr;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::time::Instant;

/// ============================================================================
/// 1. THE ARENA ALLOCATOR IMPLEMENTATION
/// ============================================================================

/// A thread-safe, bump-pointer Arena Allocator.
///
/// # How it works:
/// 1. It pre-allocates a large contiguous block of memory on the heap.
/// 2. `alloc` simply moves a pointer forward (bumps it) by the requested size.
/// 3. It does not support individual deallocation; memory is freed all at once
///    when the Arena is dropped.
///
/// # Why for AI?
/// Inference steps generate massive amounts of intermediate tensors (e.g., attention matrices).
/// These have strictly scoped lifetimes (alive only for the duration of one forward pass).
/// The Arena eliminates fragmentation and malloc overhead during the critical path.
struct Arena {
    /// The raw pointer to the start of the allocated block.
    ptr: *mut u8,
    /// The total size of the arena block.
    capacity: usize,
    /// The current allocation head, moved atomically.
    head: AtomicUsize,
}

unsafe impl Sync for Arena {} // Safe because we use atomics for `head`.

impl Arena {
    /// Creates a new Arena with a fixed capacity (e.g., 64MB).
    fn new(capacity: usize) -> Self {
        // We use the global allocator to get the backing memory.
        let layout = Layout::from_size_align(capacity, 16).unwrap();
        let ptr = unsafe { System.alloc(layout) };
        
        if ptr.is_null() {
            panic!("Failed to allocate arena memory");
        }

        Arena {
            ptr,
            capacity,
            head: AtomicUsize::new(0),
        }
    }

    /// Allocates a block of memory fitting `layout`.
    /// Returns a raw pointer and the offset (for metadata).
    unsafe fn alloc_raw(&self, layout: Layout) -> *mut u8 {
        let mut current_head = self.head.load(Ordering::Relaxed);
        let mut new_head;

        loop {
            // Calculate the start address within the arena block.
            let start_addr = self.ptr as usize + current_head;
            
            // Calculate padding for alignment.
            let align_mask = layout.align() - 1;
            let padding = (align_mask - (start_addr & align_mask)) & align_mask;
            
            // Calculate the new head position.
            let alloc_size = layout.size();
            new_head = current_head + padding + alloc_size;

            // Check for overflow (OOM).
            if new_head > self.capacity {
                panic!("Arena out of memory (capacity: {} bytes)", self.capacity);
            }

            // Try to update the head atomically.
            match self.head.compare_exchange_weak(
                current_head,
                new_head,
                Ordering::SeqCst, // SeqCst ensures visibility across threads
                Ordering::Relaxed,
            ) {
                Ok(_) => {
                    // Success: Return the pointer to the aligned start.
                    return (start_addr + padding) as *mut u8;
                }
                Err(head) => {
                    // Another thread updated the head, retry with new value.
                    current_head = head;
                }
            }
        }
    }

    /// Resets the arena pointer to 0.
    /// WARNING: This invalidates all data previously allocated in this arena.
    /// It is safe only when no threads are accessing the allocated memory.
    fn reset(&self) {
        self.head.store(0, Ordering::SeqCst);
    }
}

unsafe impl GlobalAlloc for Arena {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        self.alloc_raw(layout)
    }

    unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {
        // No-op: We deallocate all memory at once via `reset` or `drop`.
    }
}

/// ============================================================================
/// 2. MOCK AI DATA STRUCTURES
/// ============================================================================

/// A mock Tensor structure. In a real scenario, this would hold f32/f16 data.
/// We use a raw pointer to simulate ownership of data within the Arena.
struct Tensor {
    ptr: *mut f32,
    len: usize,
}

impl Tensor {
    /// Simulates creating a tensor (e.g., an attention matrix).
    /// This uses the `Arena` allocator implicitly via the GlobalAlloc trait.
    fn new(size: usize) -> Self {
        let layout = Layout::from_size_align(size * mem::size_of::<f32>(), 16).unwrap();
        // We use System here to route through our GlobalAlloc impl if set globally,
        // or we could pass a reference to a specific arena instance.
        // For this demo, we assume the Arena is set as the global allocator for simplicity,
        // or we manually call the allocator logic. 
        // *Note: In production, you would likely pass `&Arena` explicitly to avoid global state.*
        
        // To demonstrate explicit usage without setting global allocator:
        let ptr = unsafe { System.alloc(layout) } as *mut f32;
        
        // Initialize with dummy values (simulating a forward pass)
        for i in 0..size {
            unsafe { ptr.add(i).write(1.0); }
        }

        Tensor { ptr, len: size }
    }

    /// A dummy computation (e.g., matrix multiplication).
    fn compute(&self) -> f32 {
        let mut sum = 0.0;
        for i in 0..self.len {
            unsafe { sum += *self.ptr.add(i); }
        }
        sum
    }
}

/// RAII Guard for the Arena.
/// When this guard goes out of scope, it resets the arena.
/// This enforces the "Scope-Based" lifetime strategy.
struct ArenaGuard<'a> {
    arena: &'a Arena,
}

impl<'a> ArenaGuard<'a> {
    fn new(arena: &'a Arena) -> Self {
        arena.reset(); // Ensure clean slate at start of scope
        ArenaGuard { arena }
    }
}

impl<'a> Drop for ArenaGuard<'a> {
    fn drop(&mut self) {
        self.arena.reset();
    }
}

/// ============================================================================
/// 3. INFERENCE PIPELINE LOGIC
/// ============================================================================

/// Simulates a high-throughput inference step.
/// 
/// # Architecture
/// 1. **Input**: A prompt/token sequence.
/// 2. **Processing**: 
///    - Allocate Query/Key/Value tensors (Attention).
///    - Allocate Intermediate activation layers.
///    - Compute.
/// 3. **Output**: Logits.
/// 
/// All intermediate allocations happen inside the `Arena`.
fn run_inference_step(arena: &Arena, input_size: usize) -> f32 {
    // 1. Create a scope guard. All allocations here are tied to this scope.
    let _guard = ArenaGuard::new(arena);

    // 2. Allocate Attention Matrices (Q, K, V)
    // In a standard allocator, these 3 allocations would scatter memory.
    // In the Arena, they are contiguous blocks.
    let q = Tensor::new(input_size);
    let k = Tensor::new(input_size);
    let v = Tensor::new(input_size);

    // 3. Allocate Intermediate Dense Layer
    let dense = Tensor::new(input_size);

    // 4. Perform Computations (Mock)
    let mut result = q.compute() + k.compute() + v.compute();
    result += dense.compute();

    // 5. The `_guard` drops here, resetting the arena pointer to 0.
    // The memory is now ready for the next inference step immediately.
    result
}

/// ============================================================================
/// 4. BENCHMARKING & MAIN
/// ============================================================================

fn main() {
    // Initialize a 64MB Arena.
    // In a real LLM, this might be 10GB+ of GPU/CPU memory.
    let arena = Arena::new(64 * 1024 * 1024); 
    let iterations = 10_000;

    println!("Starting Inference Benchmark...");
    println!("Mode: Custom Arena Allocator");
    
    let start = Instant::now();
    for _ in 0..iterations {
        run_inference_step(&arena, 1024); // Simulate 1024-element tensors
    }
    let arena_duration = start.elapsed();

    // Compare with Standard Allocator (System)
    println!("\nMode: Standard System Allocator");
    let start = Instant::now();
    for _ in 0..iterations {
        // In the standard mode, we just allocate and immediately drop
        let _t1 = Tensor::new(1024);
        let _t2 = Tensor::new(1024);
        let _t3 = Tensor::new(1024);
        let _t4 = Tensor::new(1024);
    }
    let system_duration = start.elapsed();

    println!("------------------------------------------------");
    println!("Arena Allocator Time:  {:?}", arena_duration);
    println!("System Allocator Time: {:?}", system_duration);
    println!("Speedup Factor:        {:.2}x", 
        system_duration.as_nanos() as f64 / arena_duration.as_nanos() as f64);
    println!("------------------------------------------------");
    println!("\nExplanation:");
    println!("The Arena allocator avoids OS syscalls (brk/mmap) for every tensor.");
    println!("It maintains pointer locality, improving CPU cache hit rates.");
}
