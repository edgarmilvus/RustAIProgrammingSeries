
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

use std::time::Instant;

/// Represents a tensor with dimensions and heap-allocated data.
/// 
/// We use `Box<[f32]>` instead of `Vec<f32>` because model weights are 
/// typically fixed-size after loading. `Box<[T]>` is 16 bytes (on 64-bit)
/// containing a pointer and a length, whereas `Vec<T>` is 24 bytes 
/// (pointer, length, capacity). This saves 8 bytes on the stack per tensor.
pub struct BoxedTensor {
    rows: usize,
    cols: usize,
    /// The actual data lives on the heap. The stack footprint is just the pointer.
    data: Box<[f32]>,
}

impl BoxedTensor {
    /// Creates a new tensor filled with a specific value.
    /// 
    /// # Arguments
    /// * `rows` - Number of rows.
    /// * `cols` - Number of columns.
    /// * `value` - The value to fill the tensor with.
    ///
    /// # Under the Hood
    /// 1. `vec![value; rows * cols]` allocates memory on the heap via the standard allocator.
    /// 2. `.into_boxed_slice()` converts the Vec into a raw box, dropping capacity metadata.
    /// 3. This operation is O(1) regarding time (just pointer manipulation), but O(N) regarding memory allocation.
    pub fn new(rows: usize, cols: usize, value: f32) -> Self {
        let size = rows * cols;
        // Allocate on heap immediately
        let data = vec
![value; size].into_boxed_slice()
;
        
        BoxedTensor { rows, cols, data }
    }

    /// Simulates loading weights from a disk file (e.g., a .bin checkpoint).
    /// In a real scenario, this would read bytes and cast them to f32.
    /// 
    /// # Safety
    /// This function simulates heavy I/O and memory allocation. 
    pub fn load_from_checkpoint(rows: usize, cols: usize) -> Self {
        let start = Instant::now();
        println!("Loading weights ({}x{}) onto Heap...", rows, cols);
        
        // Simulate processing time and allocation
        let mut data = Vec::with_capacity(rows * cols);
        for i in 0..(rows * cols) {
            // Simulate weight values (e.g., Xavier initialization)
            data.push(((i as f32) % 255.0) / 255.0);
        }

        let tensor = BoxedTensor {
            rows,
            cols,
            data: data.into_boxed_slice(),
        };

        println!("Loading complete in {:?}", start.elapsed());
        tensor
    }

    /// Performs a matrix multiplication: C = A * B
    /// 
    /// This function demonstrates how `Box` allows passing large data 
    /// efficiently between functions. Since `BoxedTensor` owns its data,
    /// we pass ownership or references without deep copying the heap data.
    ///
    /// # Arguments
    /// * `other` - The tensor to multiply with (must have matching dimensions).
    ///
    /// # Returns
    /// A new `BoxedTensor` containing the result.
    pub fn matmul(&self, other: &BoxedTensor) -> Result<BoxedTensor, String> {
        if self.cols != other.rows {
            return Err(format!(
                "Dimension mismatch: {}x{} multiplied by {}x{}",
                self.rows, self.cols, other.rows, other.cols
            ));
        }

        let result_rows = self.rows;
        let result_cols = other.cols;
        let mut result_data = vec
![0.0; result_rows * result_cols].into_boxed_slice()
;

        // Naive O(N^3) multiplication for demonstration
        // In production, this would use SIMD or GPU kernels.
        for i in 0..self.rows {
            for j in 0..other.cols {
                let mut sum = 0.0;
                for k in 0..self.cols {
                    let a_val = self.data[i * self.cols + k];
                    let b_val = other.data[k * other.cols + j];
                    sum += a_val * b_val;
                }
                result_data[i * result_cols + j] = sum;
            }
        }

        Ok(BoxedTensor {
            rows: result_rows,
            cols: result_cols,
            data: result_data,
        })
    }

    /// Returns the sum of all elements in the tensor.
    /// Useful for verifying calculations.
    pub fn sum(&self) -> f32 {
        self.data.iter().sum()
    }
}

/// The entry point of our inference engine simulation.
fn main() {
    println!("=== Advanced Memory Pattern: Boxed Inference Engine ===\n");

    // 1. Load Large Model Weights
    // We simulate a large dense layer (e.g., 1024x1024).
    // If we tried to store [f32; 1024*1024] on the stack, it would be 4MB.
    // With Box, the stack usage is negligible (just the pointer).
    let weights = BoxedTensor::load_from_checkpoint(1024, 1024);
    
    // 2. Load Input Data
    // Input batch size of 1, with 1024 features.
    let input = BoxedTensor::new(1024, 1, 1.0); // Vector of 1.0s

    println!("\n--- Starting Inference ---");
    let inference_start = Instant::now();

    // 3. Perform Matrix Multiplication
    // We pass references to the tensors. No heap data is copied here,
    // only the pointers (8 bytes) are passed to the function.
    match weights.matmul(&input) {
        Ok(output) => {
            let duration = inference_start.elapsed();
            println!("Inference finished in {:?}", duration);
            println!("Output tensor size: {}x{}", output.rows, output.cols);
            
            // Verify logic (sum should be roughly 1024 * average_weight)
            // Since input is 1.0 and weights are normalized 0.0..1.0, sum ~ 512 * 1024
            println!("Output checksum: {:.2}", output.sum());
        }
        Err(e) => eprintln!("Error during inference: {}", e),
    }

    // 4. Memory Safety
    // When `weights` and `input` go out of scope here, Rust automatically
    // drops the Box, which deallocates the heap memory immediately.
    // No manual `free()` required.
    println!("\nResources released automatically via RAII.");
}
