
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

/// A simulation of a large model weight tensor.
/// In a real scenario, this might contain gigabytes of f32 data.
/// We derive Debug for printing and Clone to demonstrate ownership costs.
#[derive(Debug, Clone)]
struct ModelWeights {
    /// A unique identifier for the weight layer.
    id: String,
    /// The raw data buffer. In reality, this would be a Vec<f32> or a specialized tensor struct.
    /// For this example, we simulate size with a vector of bytes.
    data: Vec<u8>,
}

impl ModelWeights {
    /// Creates a new set of weights with a specific size.
    fn new(id: &str, size: usize) -> Self {
        println!("Allocating {:.2} MB on the heap for weights '{}'", 
                 size as f64 / 1_000_000.0, id);
        ModelWeights {
            id: id.to_string(),
            // Simulate heavy allocation
            data: vec
![0u8; size],
        }
    }
}

/// A lightweight struct representing a layer in the neural network.
/// It holds a Boxed pointer to the weights, not the weights themselves.
struct Layer {
    name: String,
    // Box<T> is used here. It stores the pointer to the heap-allocated ModelWeights.
    // The Layer struct itself remains small and can live on the stack.
    weights: Box<ModelWeights>,
}

impl Layer {
    /// Creates a new layer, taking ownership of the boxed weights.
    fn new(name: &str, weights: Box<ModelWeights>) -> Self {
        Layer {
            name: name.to_string(),
            weights,
        }
    }

    /// Performs an inference operation.
    /// This function takes a reference to the layer, proving we don't need ownership
    /// to read the weights.
    fn infer(&self) {
        println!("Layer '{}' performing inference using {} bytes of data.", 
                 self.name, self.weights.data.len());
    }
}

/// A container for the entire model architecture.
/// This struct is designed to live on the heap if the model is large enough,
/// but for this example, we'll instantiate it on the stack to show how Box
/// keeps the stack usage minimal.
struct InferenceEngine {
    layers: Vec<Layer>,
}

impl InferenceEngine {
    fn new() -> Self {
        InferenceEngine { layers: Vec::new() }
    }

    /// Adds a layer to the engine.
    fn add_layer(&mut self, layer: Layer) {
        self.layers.push(layer);
    }

    /// Runs the full inference pipeline.
    fn run_pipeline(&self) {
        println!("--- Starting Inference Pipeline ---");
        for layer in &self.layers {
            layer.infer();
        }
        println!("--- Pipeline Complete ---");
    }
}

fn main() {
    // 1. Allocate a large weight tensor on the heap using Box::new.
    // Without Box, `ModelWeights::new("layer1", 10_000_000)` would attempt
    // to fit 10MB onto the stack frame of `main`, causing a panic.
    let heavy_weights = Box::new(ModelWeights::new("layer_1_weights", 10_000_000));

    // 2. Inspect the memory address.
    // `heavy_weights` is a smart pointer on the stack pointing to data on the heap.
    println!("Pointer to heap data: {:p}", heavy_weights.data.as_ptr());

    // 3. Move ownership into a Layer.
    // Note: We do not clone `heavy_weights` here. Ownership is transferred.
    let layer_1 = Layer::new("Dense_1024", heavy_weights);

    // 4. Attempting to use `heavy_weights` here would result in a compile-time error.
    // Uncommenting the line below will fail:
    // println!("{:?}", heavy_weights); 

    // 5. Create the engine and run the pipeline.
    let mut engine = InferenceEngine::new();
    engine.add_layer(layer_1);
    
    // We can add more layers. We must allocate new boxes for them.
    let weights_2 = Box::new(ModelWeights::new("layer_2_weights", 5_000_000));
    let layer_2 = Layer::new("Output_10", weights_2);
    engine.add_layer(layer_2);

    engine.run_pipeline();
}
