
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_6.rs
// Description: Solution for Exercise 6
// ==========================================

use std::mem;

// Define sizes for the matrices.
// We use small sizes here to make the output readable, 
// but the concept applies to large matrices.
const SIZE_A: usize = 10;
const SIZE_B: usize = 10;
const SIZE_D: usize = 20; // Larger than A or B

type MatrixSmall = Box<[f64; SIZE_A]>;
type MatrixLarge = Box<[f64; SIZE_D]>;

fn main() {
    // 1. Allocate Matrix A
    let matrix_a = Box::new([0.0; SIZE_A]);
    let ptr_a = &*matrix_a as *const [f64; SIZE_A] as usize;
    println!("Allocated A: {:p} (Address: {})", &matrix_a, ptr_a);

    // 2. Allocate Matrix B
    let matrix_b = Box::new([0.0; SIZE_B]);
    let ptr_b = &*matrix_b as *const [f64; SIZE_B] as usize;
    println!("Allocated B: {:p} (Address: {})", &matrix_b, ptr_b);

    // 3. Allocate Matrix C
    let matrix_c = Box::new([0.0; SIZE_A]);
    let ptr_c = &*matrix_c as *const [f64; SIZE_A] as usize;
    println!("Allocated C: {:p} (Address: {})", &matrix_c, ptr_c);

    println!("\n--- Dropping Matrix B ---\n");
    
    // 4. Deallocate Matrix B
    // We explicitly drop it to free the memory block.
    drop(matrix_b); 

    // 5. Allocate Matrix D (Larger than A, B, or C)
    // The allocator needs to find a block large enough for 20 f64s.
    // Depending on the allocator strategy (e.g., First-Fit, Best-Fit),
    // it might reuse the gap left by B (if it fits) or find a new block at the end.
    let matrix_d = Box::new([0.0; SIZE_D]);
    let ptr_d = &*matrix_d as *const [f64; SIZE_D] as usize;
    println!("Allocated D (Larger): {:p} (Address: {})", &matrix_d, ptr_d);

    // 6. Visualization Logic
    // We collect pointers to visualize relative positions.
    let mut addresses = vec
![
        ("A", ptr_a)
,
        ("C", ptr_c),
        ("D", ptr_d),
    ];
    
    // Sort by address to see the order in memory.
    addresses.sort_by_key(|&(_, addr)| addr);

    println!("\n--- Memory Layout Visualization (Sorted by Address) ---");
    for (name, addr) in addresses {
        println!("Block {}: Address {}", name, addr);
    }

    // Generate Graphviz DOT format for the diagram.
    println!("\n--- Graphviz DOT Output ---");
    println!(r#"
digraph MemoryLayout {{
    rankdir=LR;
    node [shape=box];
    Stack [label="Stack\n(matrix_a, matrix_c, matrix_d)"];
    
    Heap [label="Heap Memory", shape=plaintext];

    // Pointers from Stack to Heap
    Stack -> A [label="ptr"];
    Stack -> C [label="ptr"];
    Stack -> D [label="ptr"];

    // Heap Blocks
    A [label="Matrix A\n({} f64s)"];
    C [label="Matrix C\n({} f64s)"];
    D [label="Matrix D\n({} f64s)"];
    
    // Visualizing the Gap (Conceptual)
    // In a real diagram, you would draw the blocks at relative positions.
    // Here we describe the layout.
    
    {{ rank=same; Heap }}
    {{ rank=same; A, C, D }}
}}"#, SIZE_A, SIZE_A, SIZE_D);
}
