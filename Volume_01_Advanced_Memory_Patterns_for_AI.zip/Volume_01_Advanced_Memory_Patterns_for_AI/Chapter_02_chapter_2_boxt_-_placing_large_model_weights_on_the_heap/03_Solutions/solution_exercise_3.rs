
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.rs
// Description: Solution for Exercise 3
// ==========================================

// Enable the unstable feature gate.
#![feature(allocator_api)]

use std::alloc::{Allocator, Global, Layout};
use std::ptr::NonNull;

// 4. Define the struct generic over an Allocator.
pub struct ModelWeights<A: Allocator> {
    // We store a boxed slice of f64 using the provided allocator.
    data: Box<[f64], A>,
}

impl ModelWeights<Global> {
    // Helper constructor for the default global allocator.
    pub fn new_global(size: usize) -> Self {
        Self::new(size, Global)
    }
}

impl<A: Allocator> ModelWeights<A> {
    // 4. Constructor taking a size and an allocator.
    pub fn new(size: usize, alloc: A) -> Self {
        // Create a vector using the specific allocator.
        // Vec::new_in(alloc) creates a vector that uses this allocator.
        let mut vec = Vec::new_in(alloc);
        
        // Resize the vector to the desired size with zeros.
        // This triggers the allocation via the custom allocator.
        vec.resize(size, 0.0);

        // Convert the Vec into a boxed slice.
        // This retains the allocator context.
        let boxed_slice = vec.into_boxed_slice();

        ModelWeights { data: boxed_slice }
    }

    pub fn len(&self) -> usize {
        self.data.len()
    }
}
