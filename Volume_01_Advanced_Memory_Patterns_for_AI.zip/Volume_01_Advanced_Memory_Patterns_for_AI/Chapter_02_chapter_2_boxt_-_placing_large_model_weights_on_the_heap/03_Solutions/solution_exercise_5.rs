
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.rs
// Description: Solution for Exercise 5
// ==========================================

// src/bin/debug_alloc.rs or main.rs
#![feature(allocator_api)]

use std::alloc::{Allocator, Global, Layout};
use std::ptr::NonNull;
use rusty_ml::ModelWeights; // Assuming rusty-ml is a dependency or in workspace

// 6. A simple Debug Allocator wrapper.
#[derive(Clone, Copy)]
struct DebugAllocator;

unsafe impl Allocator for DebugAllocator {
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, std::alloc::AllocError> {
        // Log the allocation.
        println!("[DEBUG ALLOC] Allocating {} bytes", layout.size());
        // Delegate to the global allocator.
        Global.allocate(layout)
    }

    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // Log the deallocation.
        println!("[DEBUG ALLOC] Deallocating {} bytes", layout.size());
        // Delegate to the global allocator.
        Global.deallocate(ptr, layout)
    }
}

fn main() {
    println!("--- Testing Custom Allocator ---");
    
    // Instantiate ModelWeights with the DebugAllocator.
    // This will trigger the print statements during allocation.
    {
        let model = ModelWeights::new(10, DebugAllocator);
        println!("Model created with size: {}", model.len());
    } // 'model' goes out of scope here, triggering deallocation logs.
    
    println!("--- End of Test ---");
}
