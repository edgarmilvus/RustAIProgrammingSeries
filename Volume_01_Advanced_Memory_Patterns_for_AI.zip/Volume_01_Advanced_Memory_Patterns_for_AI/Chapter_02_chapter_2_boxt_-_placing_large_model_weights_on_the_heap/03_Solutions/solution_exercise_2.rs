
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.rs
// Description: Solution for Exercise 2
// ==========================================

use std::time::Instant;

// 1. Define the struct with a large Vec.
// We simulate a large model with 10 million elements.
const MODEL_SIZE: usize = 10_000_000;

#[derive(Clone)] // 2. Derive Clone for the unboxed version.
struct ModelWeightsUnboxed {
    weights: Vec<f64>,
}

// 3. Refactoring to use Box.
// We cannot simply derive Clone here if we want to demonstrate the manual process,
// but technically Box<Vec<T>> would clone the Vec inside if we derived it.
// To strictly follow the prompt's "Challenge" to implement a custom deep_clone,
// we will not derive Clone here.
struct ModelWeightsBoxed {
    weights: Box<Vec<f64>>,
}

impl ModelWeightsUnboxed {
    fn new() -> Self {
        // 3. Initialize with dummy data.
        // We use a simple loop to avoid external dependencies.
        let mut w = Vec::with_capacity(MODEL_SIZE);
        for i in 0..MODEL_SIZE {
            w.push(i as f64 * 0.1);
        }
        Self { weights: w }
    }
}

impl ModelWeightsBoxed {
    fn new() -> Self {
        let mut w = Vec::with_capacity(MODEL_SIZE);
        for i in 0..MODEL_SIZE {
            w.push(i as f64 * 0.1);
        }
        Self {
            weights: Box::new(w),
        }
    }

    // 5. & 6. Custom deep_clone implementation.
    // This allocates new heap memory and copies values.
    fn deep_clone(&self) -> Self {
        // Create a new vector with the same capacity.
        let mut new_vec = Vec::with_capacity(self.weights.len());
        
        // Copy elements manually.
        // In a real scenario, `clone_from_slice` is more efficient for slices.
        new_vec.extend_from_slice(&self.weights);

        Self {
            weights: Box::new(new_vec),
        }
    }
}

fn main() {
    println!("--- Cloning Performance Analysis ---");

    // --- Unboxed Vector ---
    let unboxed_model = ModelWeightsUnboxed::new();
    
    // 4. Measure derived clone.
    let start = Instant::now();
    let _unboxed_clone = unboxed_model.clone();
    let duration = start.elapsed();
    println!("Time to clone unboxed Vec: {:?}", duration);

    // --- Boxed Vector ---
    let boxed_model = ModelWeightsBoxed::new();

    // Measure custom deep clone.
    let start = Instant::now();
    let _boxed_clone = boxed_model.deep_clone();
    let duration = start.elapsed();
    println!("Time to deep clone boxed Vec: {:?}", duration);
    
    // Note: The times should be very similar because both involve 
    // allocating a new 80MB chunk of memory and copying the data.
    // The Box adds a layer of indirection but doesn't change the 
    // cost of copying the underlying data.
}
