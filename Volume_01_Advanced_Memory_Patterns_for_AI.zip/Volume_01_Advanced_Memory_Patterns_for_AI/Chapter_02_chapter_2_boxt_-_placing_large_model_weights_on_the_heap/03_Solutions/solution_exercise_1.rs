
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

use std::mem;

// Define a constant size for the matrix dimensions.
// 4096 * 4096 * 8 bytes (f64) = 134,217,728 bytes (~128 MB).
const MATRIX_SIZE: usize = 4096;

// 1. Define the struct holding a large fixed-size array on the stack.
struct WeightMatrixStack {
    // This will likely cause a stack overflow because the struct
    // attempts to store the entire array inline on the stack.
    data: [[f64; MATRIX_SIZE]; MATRIX_SIZE],
}

// 2. Define the struct using Box to move the data to the heap.
struct WeightMatrixHeap {
    // Box<T> allocates memory on the heap and stores a pointer to it on the stack.
    // The type is Box<[T; N]>, a pointer to an array of fixed size.
    data: Box<[[f64; MATRIX_SIZE]; MATRIX_SIZE]>,
}

fn main() {
    println!("--- Analyzing Memory Footprint ---");
    
    // Calculate the total size in bytes.
    let total_size = MATRIX_SIZE * MATRIX_SIZE * std::mem::size_of::<f64>();
    println!("Total data size: {:.2} MB", total_size as f64 / 1_048_576.0);

    // ---------------------------------------------------------
    // 3. Attempting to instantiate on the stack (Uncommenting this will likely crash or fail to compile)
    // ---------------------------------------------------------
    // let _stack_matrix = WeightMatrixStack {
    //     data: [[0.0; MATRIX_SIZE]; MATRIX_SIZE],
    // };
    // println!("Stack matrix size: {} bytes", mem::size_of::<WeightMatrixStack>());
    
    // ---------------------------------------------------------
    // 4 & 5. Instantiating on the heap and checking sizes
    // ---------------------------------------------------------
    
    // We allocate the matrix on the heap.
    // Note: We must initialize it carefully to avoid stack overflow during construction.
    // We create a zeroed array on the heap directly.
    let heap_matrix = WeightMatrixHeap {
        data: Box::new([[0.0; MATRIX_SIZE]; MATRIX_SIZE]),
    };

    // Check the size of the struct itself (on the stack).
    // This should be small (typically 8 bytes for the pointer on a 64-bit system).
    let struct_size = mem::size_of::<WeightMatrixHeap>();
    println!("Size of WeightMatrixHeap struct (on stack): {} bytes", struct_size);

    // 6. Verify the actual data size on the heap.
    // size_of_val returns the size of the value the pointer points to.
    let data_size = mem::size_of_val(&*heap_matrix.data);
    println!("Size of data pointed to by Box (on heap): {} bytes", data_size);
    
    // ---------------------------------------------------------
    // Verification of the "Under the Hood" logic
    // ---------------------------------------------------------
    assert!(struct_size <= 16, "Struct should only contain a pointer (and maybe metadata)");
    assert!(data_size == total_size, "Heap data should match the calculated total size");
}
