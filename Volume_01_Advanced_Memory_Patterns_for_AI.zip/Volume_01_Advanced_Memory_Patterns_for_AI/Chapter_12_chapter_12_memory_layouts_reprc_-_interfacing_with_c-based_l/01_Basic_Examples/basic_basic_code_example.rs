
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

/// 1. Define the data structure.
/// We are simulating a configuration struct for an AI inference engine.
/// This struct must match the memory layout of a C struct defined in a CUDA header file.
#[repr(C)] // CRITICAL: Ensures Rust uses the same memory layout as C (field order & alignment).
pub struct InferenceConfig {
    /// The ID of the model to run (e.g., 101 for ResNet, 202 for BERT).
    /// In C: `uint32_t model_id;`
    pub model_id: u32,

    /// The batch size for the inference.
    /// In C: `uint64_t batch_size;`
    pub batch_size: u64,

    /// A flag indicating if we should use mixed precision (0 or 1).
    /// In C: `uint8_t use_mixed_precision;`
    pub use_mixed_precision: u8,
}

/// 2. Define the "C Library" Interface.
/// In a real scenario, these functions would be imported from a `.so` or `.dll` file
/// using `extern "C"`. Here, we simulate the C library behavior to make the example runnable.
mod cuda_driver {
    use super::InferenceConfig;

    /// A simulated C function that accepts a pointer to our config.
    /// In real FFI, this would be: `extern "C" { fn launch_kernel(config: *const InferenceConfig); }`
    pub unsafe extern "C" fn launch_inference_kernel(config: *const InferenceConfig) {
        if config.is_null() {
            eprintln!("Error: Null pointer passed to CUDA kernel.");
            return;
        }

        // SAFETY: We assume the pointer provided by Rust is valid for the duration of this call.
        let cfg = unsafe { &*config };

        // Simulate the C library reading the memory directly.
        println!("--- CUDA Kernel Received Configuration ---");
        println!("| Model ID:          {}", cfg.model_id);
        println!("| Batch Size:        {}", cfg.batch_size);
        println!("| Mixed Precision:   {}", cfg.use_mixed_precision);
        println!("-----------------------------------------");
    }
}

/// 3. Helper function to print struct memory layout for educational purposes.
/// This helps visualize the "Under the Hood" memory alignment.
fn print_memory_layout<T: Sized>() {
    println!(
        "Size of {}: {} bytes",
        std::any::type_name::<T>(),
        std::mem::size_of::<T>()
    );
    println!(
        "Alignment of {}: {} bytes",
        std::any::type_name::<T>(),
        std::mem::align_of::<T>()
    );
}

/// 4. The Main Execution Logic.
/// This represents a Rust-native CLI tool or Inference Server preparing data for a GPU.
fn main() {
    println!("=== High-Performance AI Inference Setup ===\n");

    // A. Create the Rust struct instance.
    // This lives entirely on the Rust stack (or heap, if boxed).
    let config = InferenceConfig {
        model_id: 202,          // Example: BERT model
        batch_size: 32,         // Process 32 items at once
        use_mixed_precision: 1, // True
    };

    // B. Inspect the memory layout.
    // Note: Without #[repr(C)], the size might differ due to Rust's internal padding rules.
    print_memory_layout::<InferenceConfig>();
    println!();

    // C. Pass data to the C library (FFI).
    // We must pass a raw pointer to the C function.
    // Rust guarantees that the layout of `config` matches what the C function expects.
    unsafe {
        cuda_driver::launch_inference_kernel(&config as *const _);
    }

    println!("\n=== Inference Setup Complete ===");
}
