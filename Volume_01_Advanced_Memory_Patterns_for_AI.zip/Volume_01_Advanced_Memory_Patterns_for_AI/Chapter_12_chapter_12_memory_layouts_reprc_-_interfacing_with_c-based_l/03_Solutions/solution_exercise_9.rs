
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_9.rs
// Description: Solution for Exercise 9
// ==========================================

// Proposal for a `CudaKernel` trait
pub trait CudaKernel {
    /// The input/output types required by the kernel.
    type Params: Sized;

    /// Launches the kernel with the given parameters and configuration.
    /// 
    /// # Arguments
    /// * `params` - A reference to the FFI-compatible parameter struct.
    /// * `grid_dim` - Grid dimensions (x, y, z).
    /// * `block_dim` - Block dimensions (x, y, z).
    /// * `shared_mem_bytes` - Dynamic shared memory size.
    /// * `stream` - Optional CUDA stream.
    ///
    /// # Safety
    /// This method is unsafe because the kernel execution is asynchronous and 
    /// memory safety depends on the validity of pointers in `params` for the duration of the launch.
    unsafe fn launch(
        &self,
        params: &Self::Params,
        grid_dim: (u32, u32, u32),
        block_dim: (u32, u32, u32),
        shared_mem_bytes: u32,
        stream: Option<&CudaStream>, // Assuming CudaStream from Ex 2
    ) -> Result<(), String>;

    /// Returns the PTX or binary representation of the kernel (optional, for dynamic loading).
    fn get_module(&self) -> &[u8];
}
