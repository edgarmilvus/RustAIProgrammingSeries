
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

use std::mem::{size_of, align_of};

// 1. Define the struct with #[repr(C)]
// This ensures the layout follows C struct rules (field order preserved, padding added for alignment).
#[repr(C)]
pub struct TensorDescriptor {
    pub ndims: u32,          // 4 bytes
    pub data_type: u32,      // 4 bytes
    pub dims: [i32; 8],      // 8 * 4 = 32 bytes
    pub strides: [i32; 8],   // 8 * 4 = 32 bytes
}

fn main() {
    // 3. Create an instance for a 4x6 matrix (Row-major)
    // Strides: [6, 1] (stride 0 is 6 elements to next row, stride 1 is 1 element to next col)
    // Padding the rest with 0.
    let tensor = TensorDescriptor {
        ndims: 2,
        data_type: 3, // Hypothetical ID for f32
        dims: [4, 6, 0, 0, 0, 0, 0, 0],
        strides: [6, 1, 0, 0, 0, 0, 0, 0],
    };

    // 4. Print size and alignment
    println!("Size of TensorDescriptor: {} bytes", size_of::<TensorDescriptor>());
    println!("Alignment of TensorDescriptor: {} bytes", align_of::<TensorDescriptor>());
    
    // Sum of individual fields (ignoring padding)
    let sum_fields = size_of::<u32>() + size_of::<u32>() + 
                     (8 * size_of::<i32>()) + (8 * size_of::<i32>());
    println!("Sum of individual fields: {} bytes", sum_fields);

    // 5. Under the Hood Analysis
    println!("\n--- Layout Analysis ---");
    println!("Alignment requirement for u32/i32: typically 4 bytes on 64-bit platforms.");
    println!("Field offsets:");
    println!("  ndims:      offset 0");
    println!("  data_type:  offset 4 (contiguous to previous u32)");
    println!("  dims:       offset 8 (aligned to 8 bytes? No, 4 is sufficient for i32, but arrays align to element alignment)");
    
    // Note: In Rust (and C), the alignment of a struct is the max alignment of its fields.
    // Arrays align to their element alignment. [i32; 8] aligns to 4.
    // The compiler will likely pack ndims and data_type (8 bytes total).
    // dims starts at offset 8. 
    // strides starts at offset 8 + 32 = 40.
    // Total size = 40 + 32 = 72 bytes.
    
    // If we reordered fields (e.g., putting arrays first), the layout might change slightly 
    // regarding padding between fields, but the total size usually remains the same 
    // because the largest alignment requirement dictates the overall struct alignment.
}

