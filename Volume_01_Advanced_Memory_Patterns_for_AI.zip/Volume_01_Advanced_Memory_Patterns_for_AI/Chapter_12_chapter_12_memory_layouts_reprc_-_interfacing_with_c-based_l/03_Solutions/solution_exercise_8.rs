
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_8.rs
// Description: Solution for Exercise 8
// ==========================================

// kernel.rs
use super::ffi::LaunchParams;
use super::gpu_buffer::GPUBuffer;

// 3. Safe launch function
pub fn launch_elementwise_add(
    a: &GPUBuffer<f32>,
    b: &GPUBuffer<f32>,
    c: &mut GPUBuffer<f32>,
    n: usize,
) -> Result<(), String> {
    // Safety check: Ensure buffers are large enough
    if a.len < n || b.len < n || c.len < n {
        return Err("Buffer size mismatch".to_string());
    }

    // Prepare LaunchParams
    let params = LaunchParams {
        d_a: a.as_ptr(),
        d_b: b.as_ptr(),
        d_c: c.as_mut_ptr(),
        n,
    };

    // Launch configuration (simplified)
    let grid_dim = (n as u32 + 255) / 256;
    let block_dim = 256;

    unsafe {
        // Call the underlying C kernel
        ffi::launch_elementwise_kernel(&params, grid_dim, block_dim);
    }

    // Note: In a real scenario, we might need to synchronize here or return a future
    // For this mock, we assume the launch is synchronous.
    Ok(())
}
