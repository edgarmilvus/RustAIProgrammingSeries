
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.rs
// Description: Solution for Exercise 5
// ==========================================

// src/main.rs
use ffi_exercise::ManagedVector;

fn main() {
    // Create vector of 1024 elements
    let mut vec = ManagedVector::new(1024).expect("Failed to allocate vector");

    // Verify contents (initialized to 0..1023 in C)
    assert_eq!(vec.as_slice()[0], 0.0);
    assert_eq!(vec.as_slice()[100], 100.0);

    // Modify contents
    {
        let slice = vec.as_mut_slice();
        slice[0] = 999.0;
        slice[1023] = -1.0;
    }

    // Verify modifications
    assert_eq!(vec.as_slice()[0], 999.0);
    assert_eq!(vec.as_slice()[1023], -1.0);

    // Drop is called automatically here, freeing memory
    println!("Vector operations completed successfully.");
}
