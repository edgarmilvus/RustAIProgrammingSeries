
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_7.rs
// Description: Solution for Exercise 7
// ==========================================

// gpu_buffer.rs
use std::marker::PhantomData;
use std::os::raw::c_void;
use super::ffi;

// 2. Generic GPU Buffer
pub struct GPUBuffer<T> {
    ptr: *mut T,
    len: usize,
    _marker: PhantomData<T>, // Tracks ownership of T
}

impl<T> GPUBuffer<T> {
    // Allocate uninitialized memory on the device
    pub fn new(len: usize) -> Result<Self, String> {
        let size = len * std::mem::size_of::<T>();
        let mut ptr: *mut c_void = std::ptr::null_mut();
        
        unsafe {
            let err = ffi::cuda_malloc(&mut ptr as *mut *mut c_void, size);
            if err != 0 {
                return Err(format!("CUDA malloc failed with code: {}", err));
            }
        }

        Ok(GPUBuffer {
            ptr: ptr as *mut T,
            len,
            _marker: PhantomData,
        })
    }

    // Copy data from host slice to device
    pub fn from_host_slice(data: &[T]) -> Result<Self, String> {
        let buffer = GPUBuffer::new(data.len())?;
        unsafe {
            let err = ffi::cuda_memcpy(
                buffer.ptr as *mut c_void,
                data.as_ptr() as *const c_void,
                data.len() * std::mem::size_of::<T>(),
                ffi::MEMCPY_HOST_TO_DEVICE,
            );
            if err != 0 {
                return Err(format!("CUDA memcpy failed with code: {}", err));
            }
        }
        Ok(buffer)
    }

    // Copy data from device to host Vec
    pub fn to_host(&self) -> Result<Vec<T>, String> {
        let mut host_vec = Vec::with_capacity(self.len);
        unsafe {
            host_vec.set_len(self.len); // Unsafe: initializes memory without running constructors
            let err = ffi::cuda_memcpy(
                host_vec.as_mut_ptr() as *mut c_void,
                self.ptr as *const c_void,
                self.len * std::mem::size_of::<T>(),
                ffi::MEMCPY_DEVICE_TO_HOST,
            );
            if err != 0 {
                return Err(format!("CUDA memcpy failed with code: {}", err));
            }
        }
        Ok(host_vec)
    }

    // Get raw pointer for FFI
    pub fn as_ptr(&self) -> *const T {
        self.ptr
    }

    pub fn as_mut_ptr(&mut self) -> *mut T {
        self.ptr
    }
}

// 3. Drop implementation to prevent use-after-free
impl<T> Drop for GPUBuffer<T> {
    fn drop(&mut self) {
        if !self.ptr.is_null() {
            unsafe {
                ffi::cuda_free(self.ptr as *mut c_void);
            }
            self.ptr = std::ptr::null_mut();
        }
    }
}

// Send and Sync are required to pass buffers to threads (like kernel launches)
unsafe impl<T: Send> Send for GPUBuffer<T> {}
unsafe impl<T: Sync> Sync for GPUBuffer<T> {}
