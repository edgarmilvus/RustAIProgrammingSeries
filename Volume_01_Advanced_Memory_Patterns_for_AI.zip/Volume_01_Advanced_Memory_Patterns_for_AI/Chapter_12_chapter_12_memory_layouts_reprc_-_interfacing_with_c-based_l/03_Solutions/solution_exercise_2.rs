
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.rs
// Description: Solution for Exercise 2
// ==========================================

use std::mem::{size_of, align_of};

// 2. Define the newtype wrapper
// 3. Apply #[repr(transparent)]
#[repr(transparent)]
pub struct CudaStream {
    inner: usize,
}

impl CudaStream {
    // Mock constructor for demonstration
    pub fn new(handle: usize) -> Self {
        CudaStream { inner: handle }
    }
}

// 4. Define the config struct containing the wrapper
#[repr(C)]
pub struct KernelConfig {
    pub stream: CudaStream, // Zero-cost wrapper
    pub block_size: u32,
    pub grid_size: u32,
}

fn main() {
    let config = KernelConfig {
        stream: CudaStream::new(0xDEAD_BEEF),
        block_size: 256,
        grid_size: 1024,
    };

    // 5. Verify layout
    println!("Size of CudaStream: {} bytes", size_of::<CudaStream>());
    println!("Size of KernelConfig: {} bytes", size_of::<KernelConfig>());
    println!("Size of raw equivalent (usize + u32 + u32): {} bytes", 
             size_of::<usize>() + size_of::<u32>() + size_of::<u32>());
    
    println!("Alignment of CudaStream: {} bytes", align_of::<CudaStream>());
    println!("Alignment of KernelConfig: {} bytes", align_of::<KernelConfig>());

    // Analysis of layout
    // On a 64-bit platform, usize is 8 bytes.
    // KernelConfig fields:
    // 1. stream (usize, 8 bytes)
    // 2. block_size (u32, 4 bytes)
    // 3. grid_size (u32, 4 bytes)
    // Total raw sum: 16 bytes.
    
    // With #[repr(C)], fields are laid out sequentially.
    // stream: offset 0 (size 8)
    // block_size: offset 8 (size 4)
    // grid_size: offset 12 (size 4)
    // Total size: 16 bytes. No padding needed because u32 follows u32, and the struct size (16) 
    // is a multiple of the alignment of usize (8).
}
