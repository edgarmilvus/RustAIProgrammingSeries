
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.rs
// Description: Solution for Exercise 3
// ==========================================

// src/lib.rs or src/ffi.rs
use std::os::raw::{c_uint, c_float};

// 2. Rust equivalent of the C struct
#[repr(C)]
pub struct FloatVector {
    pub num_elements: u32,
    pub data: *mut f32,
}

// 3. Safe Rust API
pub struct ManagedVector {
    inner: FloatVector,
}

impl ManagedVector {
    // 4. Constructor calling C function
    pub fn new(n: u32) -> Option<Self> {
        let mut inner = FloatVector {
            num_elements: 0,
            data: std::ptr::null_mut(),
        };
        
        // Unsafe block for FFI call
        unsafe {
            create_vector(&mut inner, n);
        }

        if inner.data.is_null() {
            None
        } else {
            Some(ManagedVector { inner })
        }
    }

    // Safe read access
    pub fn as_slice(&self) -> &[f32] {
        unsafe { std::slice::from_raw_parts(self.inner.data, self.inner.num_elements as usize) }
    }

    // Safe write access
    pub fn as_mut_slice(&mut self) -> &mut [f32] {
        unsafe { std::slice::from_raw_parts_mut(self.inner.data, self.inner.num_elements as usize) }
    }
}

// 5. Drop implementation for cleanup
impl Drop for ManagedVector {
    fn drop(&mut self) {
        unsafe {
            free_vector(&mut self.inner);
        }
    }
}

// 6. FFI declarations
extern "C" {
    fn create_vector(vec: *mut FloatVector, n: c_uint);
    fn free_vector(vec: *mut FloatVector);
}
