
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

// main.rs
use std::alloc::{alloc_zeroed, dealloc, Layout};
use std::fmt;
use std::ptr::NonNull;

/// C-compatible struct representing the header of a Tensor.
/// This struct is designed to be passed directly to a CUDA kernel.
/// The `#[repr(C)]` attribute guarantees:
/// 1. Field order is preserved (no compiler reordering).
/// 2. Padding is added between fields to satisfy the alignment requirements of the following type.
/// 3. The struct has a predictable memory layout compatible with C.
#[repr(C)]
#[derive(Debug, Clone, Copy)]
pub struct CudaTensorHeader {
    /// The number of dimensions (rank) of the tensor.
    pub rank: u32,
    /// Total number of elements in the tensor (product of dimensions).
    pub num_elements: usize,
    /// Padding to ensure the struct size is a multiple of 8 (common alignment).
    /// Without this, `rank` (4 bytes) + `num_elements` (8 bytes) = 12 bytes.
    /// C compilers often pad structs to the alignment of the largest member.
    /// Here, we explicitly pad to 16 bytes to align with 64-bit pointers if needed.
    _padding: [u8; 4],
    /// The dimensions of the tensor.
    /// In C, this would be a flexible array member (e.g., `size_t dims[]`).
    /// In Rust, we fix the size for this example, but in a real scenario,
    /// you might allocate this struct dynamically with extra space.
    pub dims: [usize; 4],
}

impl CudaTensorHeader {
    /// Creates a new header.
    /// Note: In a production system, `dims` might be allocated on the heap
    /// if the rank exceeds the fixed array size.
    pub fn new(rank: u32, dims: &[usize]) -> Self {
        assert!(rank as usize <= 4, "This example supports max rank 4");
        let num_elements: usize = dims.iter().product();
        
        let mut header_dims = [0usize; 4];
        header_dims[..dims.len()].copy_from_slice(dims);

        CudaTensorHeader {
            rank,
            num_elements,
            _padding: [0; 4],
            dims: header_dims,
        }
    }
}

/// A wrapper around a raw pointer allocated for GPU data.
/// This struct manages the memory lifecycle (allocation/deallocation).
/// It uses a custom layout to ensure alignment suitable for GPU transfers.
pub struct CudaTensor {
    /// The metadata header, stored on the host.
    header: CudaTensorHeader,
    /// A non-null pointer to the data buffer (allocated on host or device depending on context).
    /// For this example, we simulate a pinned host memory allocation.
    data_ptr: NonNull<f32>,
    /// The layout used for allocation, needed for safe deallocation.
    layout: Layout,
}

impl CudaTensor {
    /// Creates a new tensor with data initialized to zero.
    /// 
    /// # Arguments
    /// * `dims` - A slice of dimensions (e.g., &[2, 3, 4] for a 2x3x4 tensor).
    /// 
    /// # Safety
    /// This function performs unsafe FFI allocation but wraps it in a safe API.
    pub fn new(dims: &[usize]) -> Result<Self, &'static str> {
        let rank = dims.len() as u32;
        let header = CudaTensorHeader::new(rank, dims);
        
        // Calculate total byte size for the data buffer.
        // We use `usize` to prevent overflow on 32-bit systems, though we expect 64-bit.
        let num_elements = header.num_elements;
        let size_bytes = num_elements * std::mem::size_of::<f32>();

        // Define the memory layout for allocation.
        // We require alignment of 128 bytes (0x80) to simulate GPU buffer requirements.
        // Standard alignment for f32 is 4 bytes, but GPU DMA often requires 128 or 256.
        let alignment = 128;
        let layout = Layout::from_size_align(size_bytes, alignment)
            .map_err(|_| "Invalid layout size or alignment")?;

        // SAFETY: We use `alloc_zeroed` to ensure the memory is initialized.
        // In a real CUDA scenario, this memory would be allocated via `cudaMallocHost`
        // or `cuMemAlloc` to ensure it is pinned or device-resident.
        let ptr = unsafe { alloc_zeroed(layout) };
        
        let data_ptr = NonNull::new(ptr as *mut f32)
            .ok_or("Memory allocation failed")?;

        // Initialize with dummy data for demonstration (e.g., sequential values)
        // In a real scenario, this data might come from a model loader.
        let slice = unsafe { std::slice::from_raw_parts_mut(ptr as *mut f32, num_elements) };
        for (i, val) in slice.iter_mut().enumerate() {
            *val = i as f32;
        }

        Ok(CudaTensor {
            header,
            data_ptr,
            layout,
        })
    }

    /// Returns a raw pointer to the data buffer.
    /// This is primarily for FFI usage.
    pub fn as_ptr(&self) -> *const f32 {
        self.data_ptr.as_ptr()
    }

    /// Returns a mutable raw pointer to the data buffer.
    pub fn as_mut_ptr(&mut self) -> *mut f32 {
        self.data_ptr.as_ptr()
    }

    /// Returns the header as a raw pointer for FFI.
    pub fn header_ptr(&self) -> *const CudaTensorHeader {
        &self.header as *const _
    }

    /// Simulates calling a CUDA kernel.
    /// In a real application, this would use `rust-cuda` or `cuda-driver-sys`.
    /// We simulate the FFI call signature here.
    pub unsafe fn launch_kernel(&self) {
        println!("Launching CUDA Kernel...");
        println!("  Header Layout: {:?}", std::mem::size_of::<CudaTensorHeader>());
        println!("  Rank: {}", self.header.rank);
        println!("  Num Elements: {}", self.header.num_elements);
        
        // Hypothetical FFI call:
        // cuda_kernel_forward(self.header_ptr(), self.as_ptr());
        
        // For this example, we just verify the memory is accessible and correct.
        let data_slice = std::slice::from_raw_parts(self.as_ptr(), self.header.num_elements);
        let sum: f32 = data_slice.iter().sum();
        println!("  Kernel simulation: Sum of elements = {}", sum);
    }
}

/// Implementing `Drop` ensures we free the memory using the exact layout
/// used for allocation. This prevents memory leaks.
impl Drop for CudaTensor {
    fn drop(&mut self) {
        unsafe {
            dealloc(self.data_ptr.as_ptr() as *mut u8, self.layout);
        }
    }
}

/// Helper to display the tensor contents.
impl fmt::Display for CudaTensor {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "CudaTensor(rank={}, dims={:?})", self.header.rank, self.header.dims)
    }
}

fn main() {
    // 1. Define the tensor shape (e.g., a batch of 2 images, 3 channels, 4x4 pixels).
    let dims = [2, 3, 4, 4];
    
    // 2. Create the tensor. This triggers the custom allocator.
    let mut tensor = CudaTensor::new(&dims).expect("Failed to create tensor");
    
    println!("Created: {}", tensor);
    
    // 3. Verify the memory layout is correct for FFI.
    // We check that the size of the header matches what C would expect.
    let header_size = std::mem::size_of::<CudaTensorHeader>();
    println!("Header size: {} bytes (Expected: 16 bytes for this struct)", header_size);
    
    // 4. Simulate passing the tensor to the GPU.
    // In a real system, this `unsafe` block would contain the actual FFI call.
    unsafe {
        tensor.launch_kernel();
    }
    
    println!("Inference complete. Memory will be freed automatically.");
}
