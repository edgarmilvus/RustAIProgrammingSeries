
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

// main.rs

/// A high-performance matrix library demonstrating judicious use of `unsafe` for
/// zero-cost abstractions in linear algebra operations.
mod matrix {
    use std::alloc::{alloc_zeroed, dealloc, Layout};
    use std::fmt;
    use std::ops::{Deref, DerefMut};

    /// Represents a matrix with a fixed row-major layout.
    /// 
    /// This struct manages heap memory manually to ensure strict control over
    /// alignment and layout, which is critical for SIMD performance.
    pub struct Matrix {
        /// Pointer to the heap-allocated data.
        ptr: *mut f32,
        /// Number of rows.
        rows: usize,
        /// Number of columns.
        cols: usize,
        /// Total capacity (usually rows * cols).
        capacity: usize,
    }

    impl Matrix {
        /// Creates a new matrix initialized to zeros.
        /// 
        /// # Safety
        /// This function uses `unsafe` to allocate memory manually. 
        /// It ensures the memory is properly aligned for `f32` (4 bytes).
        pub fn new(rows: usize, cols: usize) -> Self {
            let capacity = rows * cols;
            // Calculate layout for the allocation. 
            // SAFETY: Layout is valid for f32 and capacity > 0 (assuming non-zero dims).
            let layout = Layout::array::<f32>(capacity).unwrap();
            
            // SAFETY: We are allocating raw memory. We must ensure we handle this memory
            // correctly in Drop to avoid memory leaks.
            let ptr = unsafe { alloc_zeroed(layout) as *mut f32 };

            // Check for allocation failure (though alloc_zeroed usually panics on OOM)
            if ptr.is_null() {
                panic!("Memory allocation failed");
            }

            Matrix { ptr, rows, cols, capacity }
        }

        /// Performs matrix multiplication: C = A * B.
        /// 
        /// This implementation uses `unsafe` to perform raw pointer arithmetic,
        /// bypassing Rust's standard bounds checking for maximum throughput.
        /// 
        /// # Algorithm
        /// 1. Validate dimensions (A.cols == B.rows).
        /// 2. Allocate result matrix C.
        /// 3. Iterate through rows of A and columns of B.
        /// 4. Compute dot products using unchecked pointer access.
        pub fn multiply(&self, other: &Matrix) -> Matrix {
            assert_eq!(self.cols, other.rows, "Dimension mismatch: A.cols must equal B.rows");
            
            let rows = self.rows;
            let cols = other.cols;
            let inner = self.cols; // Common dimension
            let mut result = Matrix::new(rows, cols);

            // SAFETY: We maintain invariants manually. 
            // We know the indices are within bounds because we iterate strictly 
            // within the defined dimensions. We use `get_unchecked_mut` logic manually.
            unsafe {
                // Cache pointers to avoid repeated field access in hot loops
                let a_ptr = self.ptr;
                let b_ptr = other.ptr;
                let c_ptr = result.ptr;

                // Loop tiling is omitted for brevity, but standard row-col iteration is used.
                for i in 0..rows {
                    for j in 0..cols {
                        let mut sum = 0.0;
                        
                        // The inner loop is the critical bottleneck.
                        // We use raw pointer offsets instead of `self[i][k]`.
                        for k in 0..inner {
                            // Calculate offsets manually
                            let a_idx = i * self.cols + k;
                            let b_idx = k * other.cols + j;
                            
                            // Dereference pointers directly
                            let a_val = *a_ptr.add(a_idx);
                            let b_val = *b_ptr.add(b_idx);
                            
                            sum += a_val * b_val;
                        }

                        // Write result directly
                        let c_idx = i * cols + j;
                        *c_ptr.add(c_idx) = sum;
                    }
                }
            }

            result
        }

        /// Returns a slice view of the matrix data.
        pub fn as_slice(&self) -> &[f32] {
            // SAFETY: The pointer and length are valid as long as the struct exists.
            unsafe { std::slice::from_raw_parts(self.ptr, self.capacity) }
        }

        /// Populates the matrix with random values for testing.
        pub fn fill_random(&mut self) {
            // Using standard safe iterators here for initialization (not the hot path)
            let slice = unsafe { std::slice::from_raw_parts_mut(self.ptr, self.capacity) };
            for val in slice.iter_mut() {
                *val = rand::random::<f32>();
            }
        }
    }

    /// Implement Deref for ergonomic read-only access (e.g., matrix[0])
    impl Deref for Matrix {
        type Target = [f32];
        fn deref(&self) -> &Self::Target {
            self.as_slice()
        }
    }

    /// Custom Debug implementation for cleaner output
    impl fmt::Debug for Matrix {
        fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
            write!(f, "Matrix {}x{}: ", self.rows, self.cols)?;
            let slice = self.as_slice();
            // Print first few elements to avoid flooding console
            for i in 0..std::cmp::min(5, slice.len()) {
                write!(f, "{:.2} ", slice[i])?;
            }
            if slice.len() > 5 { write!(f, "...")?; }
            Ok(())
        }
    }

    /// Critical: Drop implementation to prevent memory leaks.
    /// Since we used `alloc_zeroed`, we must manually `dealloc`.
    impl Drop for Matrix {
        fn drop(&mut self) {
            if !self.ptr.is_null() {
                let layout = Layout::array::<f32>(self.capacity).unwrap();
                // SAFETY: We are deallocating the memory we allocated in `new`.
                // We use the same layout.
                unsafe {
                    dealloc(self.ptr as *mut u8, layout);
                }
                self.ptr = std::ptr::null_mut();
            }
        }
    }
}

// --- Application Usage ---

fn main() {
    // 1. Setup: Create large matrices to simulate a real workload (e.g., layer weights)
    let dim = 256; 
    println!("Initializing matrices of size {}x{}...", dim, dim);
    
    let mut a = matrix::Matrix::new(dim, dim);
    let mut b = matrix::Matrix::new(dim, dim);
    
    a.fill_random();
    b.fill_random();

    // 2. Execution: Perform the multiplication
    println!("Performing matrix multiplication (unsafe kernel)...");
    let start = std::time::Instant::now();
    
    let c = a.multiply(&b);
    
    let duration = start.elapsed();
    println!("Multiplication completed in {:?}", duration);

    // 3. Verification: Check a small slice of the result
    println!("Result preview: {:?}", c);

    // 4. Performance Context
    // A naive implementation using Vec<Vec<f32>> would involve:
    // - Double indirection (pointer chasing)
    // - Bounds checks on every index access
    // - Cache misses due to non-contiguous memory
    // 
    // Our unsafe implementation:
    // - Single contiguous block of memory
    // - Zero bounds checks in the inner loop
    // - Predictable memory access patterns
}
