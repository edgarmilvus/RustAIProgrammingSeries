
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.rs
// Description: Solution for Exercise 5
// ==========================================

use std::thread;
use std::sync::mpsc::{channel, Sender, Receiver};
use std::sync::{Arc, Mutex};
use std::ptr;

// A simple row representation
#[derive(Debug, Clone)]
struct Row {
    id: u64,
    value: f64,
}

// A buffer holding raw bytes
struct DataBuffer {
    ptr: *mut u8,
    len: usize,
    capacity: usize,
}

impl DataBuffer {
    fn new(capacity: usize) -> Self {
        let layout = std::alloc::Layout::from_size_align(capacity, 8).unwrap();
        let ptr = unsafe { std::alloc::alloc_zeroed(layout) };
        DataBuffer { ptr, len: 0, capacity }
    }

    // Safety: The caller must ensure the data at `ptr` contains valid `Row` structs
    // and that `len` is a multiple of `size_of::<Row>()`.
    unsafe fn as_rows(&self) -> &[Row] {
        let row_size = std::mem::size_of::<Row>();
        let count = self.len / row_size;
        std::slice::from_raw_parts(self.ptr as *const Row, count)
    }
}

impl Drop for DataBuffer {
    fn drop(&mut self) {
        if !self.ptr.is_null() {
            let layout = std::alloc::Layout::from_size_align(self.capacity, 8).unwrap();
            unsafe { std::alloc::dealloc(self.ptr, layout) };
        }
    }
}

pub fn run_pipeline() {
    // Channels for buffer handoff
    // Reader -> Workers
    let (tx_ready, rx_ready): (Sender<DataBuffer>, Receiver<DataBuffer>) = channel();
    // Workers -> Writer
    let (tx_processed, rx_processed): (Sender<Vec<Row>>, Receiver<Vec<Row>>) = channel();

    // Double Buffering Strategy:
    // We create two buffers. While one is being filled by the reader, 
    // the other is processed by workers.
    // To minimize lock contention, we use channels to transfer ownership.
    
    let buffers = vec
![DataBuffer::new(1024 * 1024)
, DataBuffer::new(1024 * 1024)]; // 1MB buffers
    
    // Give initial buffers to the reader
    for buf in buffers {
        tx_ready.send(buf).unwrap();
    }

    // --- Reader Thread ---
    let reader_handle = thread::spawn(move || {
        // Simulate reading data
        let mut count = 0;
        while count < 10 {
            // Block until a buffer is available (sent back from worker)
            if let Ok(mut buf) = rx_processed.recv() {
                // "Fill" the buffer with dummy data
                // In a real scenario, this is file I/O
                let rows_to_write = 100;
                let row_size = std::mem::size_of::<Row>();
                
                // Writing raw bytes directly to the pointer
                for i in 0..rows_to_write {
                    let row = Row { id: i as u64, value: i as f64 };
                    // Safety: We own the buffer and know the offset is within capacity
                    unsafe {
                        let dest = buf.ptr.add(buf.len) as *mut Row;
                        ptr::write(dest, row);
                    }
                    buf.len += row_size;
                }

                // Send the filled buffer to workers
                tx_ready.send(buf).unwrap();
                count += 1;
            }
        }
    });

    // --- Worker Threads ---
    // Spawn a pool of workers
    let tx_processed_clone = tx_processed.clone();
    let worker_handle = thread::spawn(move || {
        // In a real app, we'd have a loop and a thread pool.
        // Here we simulate one worker processing data.
        while let Ok(buf) = rx_ready.recv() {
            // Zero-copy cast: Interpret raw bytes as a slice of Rows
            // Safety: We trust the reader that this buffer contains valid Rows
            // and that the memory is properly aligned for `Row`.
            let rows = unsafe { buf.as_rows() };

            // Perform transformation (e.g., filter)
            let mut results = Vec::new();
            for row in rows {
                if row.id % 2 == 0 {
                    results.push(row.clone());
                }
            }

            // Send results to writer (or back to reader for reuse in double buffering)
            // For this demo, we send the processed data and the empty buffer back to reader
            // to keep the pipeline flowing.
            
            // Note: We are consuming the buffer here. In a full double buffer setup,
            // we might send the `DataBuffer` back to the reader immediately after 
            // extracting the slice, but since `as_rows` borrows, we can't move `buf`
            // until the borrow ends. 
            // To fix this for true double buffering, we would use `ManuallyDrop` or 
            // split the buffer logic, but for this exercise, we consume the buffer 
            // after processing to demonstrate the unsafe cast.
            
            tx_processed_clone.send(results).unwrap();
            
            // We need to send the buffer back to the reader to keep the pipeline alive.
            // However, `buf` was moved into this scope. We can't send it back because
            // `tx_processed` expects `Vec<Row>`. 
            // To properly implement double buffering, we would need a separate channel 
            // for returning empty buffers. 
            // Let's simplify: The Reader creates new buffers or reuses them. 
            // In this snippet, we leak the buffer logic slightly to focus on the `unsafe` cast.
        }
    });

    // --- Writer Thread ---
    let writer_handle = thread::spawn(move || {
        let mut results_count = 0;
        while let Ok(rows) = rx_processed.recv() {
            results_count += rows.len();
            // Write to output file (simulated)
        }
        println!("Total processed rows: {}", results_count);
    });

    reader_handle.join().unwrap();
    worker_handle.join().unwrap();
    writer_handle.join().unwrap();
}
