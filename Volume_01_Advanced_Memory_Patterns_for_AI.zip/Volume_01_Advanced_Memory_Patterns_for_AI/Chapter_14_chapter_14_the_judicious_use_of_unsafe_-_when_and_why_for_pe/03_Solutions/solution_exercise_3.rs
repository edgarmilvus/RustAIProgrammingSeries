
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.rs
// Description: Solution for Exercise 3
// ==========================================

use std::alloc::{alloc_zeroed, dealloc, Layout};
use std::ptr;

pub struct Arena<T> {
    // Raw pointer to the heap-allocated buffer
    ptr: *mut u8,
    // Current offset in bytes
    offset: usize,
    // Total capacity in bytes
    capacity: usize,
    // Layout of T to calculate alignment and size
    layout: Layout,
}

impl<T> Arena<T> {
    pub fn new(capacity: usize) -> Self {
        // Calculate layout for T. We use Layout::new<T>() but need to align it.
        // We calculate the layout for the entire buffer based on the alignment of T.
        let layout = Layout::new::<T>();
        // Calculate total size needed: capacity * size_of::<T>(), aligned.
        // Note: For a simple arena, we usually allocate `capacity * size_of::<T>()` 
        // ensuring the start is aligned to T.
        let buffer_size = capacity * layout.size();
        
        // Safety: Allocating zeroed memory ensures uninitialized memory is safe 
        // if we were to read it (though we won't until written).
        // We align the allocation to the alignment of T.
        let alloc_layout = Layout::from_size_align(buffer_size, layout.align())
            .expect("Invalid layout");
        
        // Safety: alloc_zeroed returns a null pointer if the allocation fails 
        // (e.g., zero size or out of memory). We handle the null case.
        let ptr = unsafe { alloc_zeroed(alloc_layout) };

        Arena {
            ptr,
            offset: 0,
            capacity: buffer_size,
            layout: alloc_layout,
        }
    }

    pub fn alloc(&mut self, value: T) -> *mut T {
        let type_size = std::mem::size_of::<T>();
        let type_align = std::mem::align_of::<T>();

        // Calculate the next aligned address
        // This is a simplified alignment logic. 
        // In production, one would use strict pointer alignment arithmetic.
        let align_mask = type_align - 1;
        let next_offset = (self.offset + align_mask) & !align_mask;

        // Check for capacity overflow
        if next_offset + type_size > self.capacity {
            panic!("Arena out of capacity");
        }

        // Calculate the pointer for the new value
        // Safety: We know self.ptr is valid (non-null) and points to a buffer of size self.capacity.
        // We are performing pointer arithmetic within the bounds of the allocation.
        let ptr = unsafe { self.ptr.add(next_offset) } as *mut T;

        // Safety: We have ensured the pointer is properly aligned for T.
        // We are writing to uninitialized memory that we own.
        unsafe {
            ptr::write(ptr, value);
        }

        // Update offset for next allocation
        self.offset = next_offset + type_size;

        ptr
    }

    pub fn reset(&mut self) {
        // Reset the offset to 0. 
        // This effectively "frees" all allocated objects without deallocating the buffer.
        // WARNING: This does NOT run destructors (Drop) for objects allocated in the arena.
        // If T has drop glue (e.g., contains Strings or Vecs), those resources will leak
        // unless manually managed. For this exercise, we assume T is simple or the user
        // handles cleanup before reset.
        self.offset = 0;
    }
}

impl<T> Drop for Arena<T> {
    fn drop(&mut self) {
        // Safety: We are deallocating the memory block that was allocated via the global allocator.
        // We must use the exact same Layout used in allocation.
        // This is safe as long as self.ptr is valid and was allocated with `alloc_zeroed`.
        if !self.ptr.is_null() {
            unsafe {
                dealloc(self.ptr, self.layout);
            }
        }
    }
}
