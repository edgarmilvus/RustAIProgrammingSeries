
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

// src/lib.rs
use std::arch::x86_64::*;

/// Performs matrix multiplication C = A * B using AVX2 intrinsics.
/// A: m x n, B: n x p, C: m x p
/// Matrices are stored in row-major order.
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn matmul_avx2(c: &mut [f32], a: &[f32], b: &[f32], m: usize, n: usize, p: usize) {
    // Safety: This function requires the CPU to support AVX2. 
    // The caller must ensure this, or use runtime feature detection before calling.
    
    // We iterate over rows of A and columns of B.
    for i in 0..m {
        for j in 0..p {
            let mut sum = _mm256_setzero_ps();

            // Inner loop: process 8 elements at a time
            let mut k = 0;
            while k + 8 <= n {
                // Safety: We assume the slices `a` and `b` are valid and contain at least
                // the data we are reading. Pointer arithmetic stays within bounds.
                let a_ptr = a.as_ptr().add(i * n + k);
                let b_ptr = b.as_ptr().add(k * p + j);

                // Load 8 floats from A (contiguous in memory for row i)
                let av = _mm256_loadu_ps(a_ptr);
                
                // Load 8 floats from B (strided access, gather-like)
                // Note: AVX2 doesn't have a direct gather for 32-bit floats in 256-bit registers 
                // efficiently without AVX-512. We simulate by loading 8 contiguous floats 
                // from B and shuffling, or simply doing scalar loads for the stride.
                // For this exercise, we will use a scalar approach for the 'j' stride 
                // to remain strictly AVX2 compatible without complex shuffles, 
                // or we can load a block if P is large enough.
                // To maximize SIMD usage, we usually block B, but here we stick to the prompt's request.
                // A common trick for row-major B is to transpose B first, but let's stick to direct access.
                
                // Actually, standard SIMD matmul usually transposes B. 
                // Given the prompt constraints, we will load B elements scalar-wise 
                // into a SIMD register to multiply with A.
                // This is not peak performance but demonstrates unsafe pointer usage.
                
                // Let's load 8 floats from B corresponding to the current column j
                // but we need to stride by 'p'. 
                // We will construct a vector where all elements are B[k*p + j].
                // This is inefficient but strictly follows the "unsafe pointer" prompt requirement 
                // for a specific architecture without blocking.
                
                // Optimization: Let's assume P is large. We will load 8 consecutive B rows 
                // if possible to do a matrix-vector product, but the prompt asks for A*B.
                // Let's do the standard approach: Load A block, Load B block, FMA.
                // Since we are 1D striding B, let's just do scalar accumulation for B 
                // inside the SIMD register for simplicity in this specific snippet, 
                // or use a gather (AVX2 supports _mm256_i32gather_ps).
                
                // Using gather for strided access:
                let indices = _mm256_setr_epi32(
                    (j + 0 * p) as i32, (j + 1 * p) as i32, (j + 2 * p) as i32, (j + 3 * p) as i32,
                    (j + 4 * p) as i32, (j + 5 * p) as i32, (j + 6 * p) as i32, (j + 7 * p) as i32,
                );
                // Safety: We ensure indices are within the bounds of `b`.
                let bv = _mm256_i32gather_ps(b.as_ptr().add(k), indices, 4);

                // Fused Multiply-Add: sum += av * bv
                sum = _mm256_fmadd_ps(av, bv, sum);

                k += 8;
            }

            // Horizontal sum of the 8 floats in 'sum'
            let mut tmp = [0.0f32; 8];
            _mm256_storeu_ps(tmp.as_mut_ptr(), sum);
            
            let mut scalar_sum = 0.0;
            for val in &tmp {
                scalar_sum += val;
            }

            // Handle remainder elements (n % 8)
            while k < n {
                scalar_sum += a[i * n + k] * b[k * p + j];
                k += 1;
            }

            c[i * p + j] = scalar_sum;
        }
    }
}

// Naive implementation for benchmarking
pub fn matmul_naive(c: &mut [f32], a: &[f32], b: &[f32], m: usize, n: usize, p: usize) {
    for i in 0..m {
        for j in 0..p {
            let mut sum = 0.0;
            for k in 0..n {
                sum += a[i * n + k] * b[k * p + j];
            }
            c[i * p + j] = sum;
        }
    }
}
