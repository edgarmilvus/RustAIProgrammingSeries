
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.rs
// Description: Solution for Exercise 2
// ==========================================

// benches/matmul_bench.rs
use criterion::{black_box, criterion_group, criterion_main, Criterion};
use fast_matrix::{matmul_avx2, matmul_naive};
use std::arch::x86_64::__cpuid;

fn benchmark_matmul(c: &mut Criterion) {
    // Check for AVX2 support
    let cpuid = __cpuid(0x7);
    let avx2_supported = (cpuid.ebx & (1 << 5)) != 0;

    let m = 256;
    let n = 256;
    let p = 256;
    let size = m * n;

    let a = vec
![1.0f32; size];
    let b = vec![1.0f32; n * p];
    let mut c_naive = vec![0.0f32; m * p];
    let mut c_avx = vec![0.0f32; m * p];

    let mut group = c.benchmark_group("Matrix Multiplication");
    
    group.bench_function("Naive Iterator", |b| {
        b.iter(|| {
            matmul_naive(black_box(&mut c_naive), black_box(&a), black_box(&b), m, n, p);
        })
    });

    if avx2_supported {
        group.bench_function("AVX2 Intrinsics", |b| {
            b.iter(|| {
                // Safety: We checked CPUID, so AVX2 is supported. 
                // We pass valid slices.
                unsafe {
                    matmul_avx2(black_box(&mut c_avx), black_box(&a), black_box(&b), m, n, p);
                }
            })
        });
    } else {
        println!("AVX2 not supported on this CPU, skipping AVX2 benchmark.");
    }

    group.finish();
}

criterion_group!(benches, benchmark_matmul);
criterion_main!(benches);
