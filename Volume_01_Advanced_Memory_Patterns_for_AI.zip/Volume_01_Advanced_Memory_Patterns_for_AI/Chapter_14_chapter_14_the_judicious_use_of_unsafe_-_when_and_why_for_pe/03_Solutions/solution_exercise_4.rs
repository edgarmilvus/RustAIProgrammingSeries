
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.rs
// Description: Solution for Exercise 4
// ==========================================

use std::ops::Deref;

pub struct FastPtr<T> {
    ptr: *const T,
    // We store the base pointer and length for bounds checking in debug mode.
    // In release mode, these fields might be optimized away if unused.
    base: *const T,
    len: usize,
}

impl<T> FastPtr<T> {
    /// Creates a new FastPtr.
    /// # Safety
    /// The caller must ensure `ptr` points to valid memory of at least `len` items.
    pub unsafe fn new(ptr: *const T, len: usize) -> Self {
        FastPtr {
            ptr,
            base: ptr,
            len,
        }
    }

    /// Returns a new pointer offset by `count` elements.
    /// # Safety
    /// The resulting pointer must remain within the bounds of the original allocation.
    pub unsafe fn offset(&self, count: isize) -> FastPtr<T> {
        // Calculate the new pointer position
        let new_ptr = self.ptr.offset(count);
        
        // Calculate the distance from the base to check bounds in debug mode
        // Note: isize arithmetic can be tricky, but offset returns a pointer 
        // that is valid if the original was valid within the allocation.
        
        FastPtr {
            ptr: new_ptr,
            base: self.base,
            len: self.len,
        }
    }
}

impl<T> Deref for FastPtr<T> {
    type Target = T;

    fn deref(&self) -> &Self::Target {
        // Conditional compilation for safety checks
        #[cfg(debug_assertions)]
        {
            // Safety Check 1: Null check
            if self.ptr.is_null() {
                panic!("Dereferencing a null FastPtr");
            }

            // Safety Check 2: Bounds check
            // Calculate distance from base in elements
            let offset = (self.ptr as usize - self.base as usize) / std::mem::size_of::<T>();
            if offset >= self.len {
                panic!(
                    "FastPtr out of bounds: offset {}, len {}",
                    offset, self.len
                );
            }
        }

        // In release builds, this block is compiled directly to:
        // mov rax, [rdi]  (load pointer value)
        // ret
        // No branching, no bounds checks.
        
        // Safety: 
        // In debug mode, we have verified the pointer is non-null and within bounds.
        // In release mode, we rely on the caller's guarantee (via the `unsafe` constructor)
        // that the pointer is valid.
        unsafe { &*self.ptr }
    }
}
