
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

/// A high-performance utility for normalizing floating-point data.
/// 
/// In a real-world scenario, this might be part of a pre-processing 
/// pipeline for a computer vision model.
struct DataProcessor;

impl DataProcessor {
    /// Normalizes a slice of floats in-place using an `unsafe` block 
    /// to bypass bounds checking.
    ///
    /// # Safety
    /// The caller must ensure that `min` and `max` are the actual 
    /// minimum and maximum values of the slice. Otherwise, division 
    /// by zero or invalid scaling may occur.
    unsafe fn normalize_unsafe(data: &mut [f32], min: f32, max: f32) {
        // Pre-calculate the range to avoid repeated subtraction in the loop.
        let range = max - min;
        
        // We assert that range is not zero to prevent division by zero.
        // In a release build with optimizations, this check is cheap.
        assert!(range > 0.0, "Range cannot be zero (max must be > min)");

        // Iterate over the slice using raw pointers.
        // This bypasses the borrow checker's iterator overhead in some contexts
        // and allows us to use `get_unchecked_mut`.
        let len = data.len();
        let ptr = data.as_mut_ptr();

        for i in 0..len {
            // SAFETY: We iterate exactly `0..len`, so `i` is always valid.
            // The compiler trusts us and removes the bounds check.
            let val = *ptr.add(i);
            let normalized = (val - min) / range;
            *ptr.add(i) = normalized;
        }
    }

    /// A safe wrapper that validates inputs before calling the unsafe core.
    /// This encapsulates the risk, providing a safe API to the rest of the application.
    fn normalize_safe(data: &mut [f32]) {
        if data.is_empty() {
            return;
        }

        // 1. Find min and max (safe, standard Rust).
        // In a real SIMD-optimized version, this would also be unsafe/optimized.
        let mut min = f32::MAX;
        let mut max = f32::MIN;
        for &val in data.iter() {
            if val < min { min = val; }
            if val > max { max = val; }
        }

        // 2. Call the unsafe implementation with verified parameters.
        // SAFETY: We have verified data is not empty and calculated real min/max.
        unsafe {
            Self::normalize_unsafe(data, min, max);
        }
    }
}

fn main() {
    // Simulating a batch of sensor readings (e.g., from an autonomous vehicle).
    let mut sensor_data = vec![10.5, 25.0, 5.0, 100.0, 42.5];
    
    println!("Before normalization: {:?}", sensor_data);
    
    // Process data using the safe API.
    DataProcessor::normalize_safe(&mut sensor_data);
    
    println!("After normalization:  {:?}", sensor_data);
    
    // Verify the result is in range [0.0, 1.0]
    assert!(sensor_data.iter().all(|&x| x >= 0.0 && x <= 1.0));
}
