
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.rs
// Description: Basic Code Example
// ==========================================

use std::collections::HashMap;
use std::sync::{Arc, RwLock};
use std::thread;
use std::time::Duration;

/// Represents a single, immutable model weight tensor.
/// We wrap the raw data in an `Arc` to allow cheap, shared ownership
/// across multiple threads without deep copying the underlying data.
/// The `f32` data is the actual weight values.
pub type SharedWeight = Arc<Vec<f32>>;

/// A thread-safe cache for model weights.
///
/// This struct acts as a central repository for model weights that can be
/// accessed concurrently by multiple threads. It uses an `RwLock` (Read-Write Lock)
/// to protect the internal `HashMap`.
///
/// - `RwLock` is chosen over a `Mutex` because reads (inference) are far more
///   frequent than writes (loading a model). `RwLock` allows multiple readers
///   to access the data simultaneously, which significantly improves throughput
///   in a multi-threaded environment.
/// - The `HashMap` stores `String` keys (e.g., "layer1_weights") and `SharedWeight`
///   values.
pub struct WeightCache {
    cache: RwLock<HashMap<String, SharedWeight>>,
}

impl WeightCache {
    /// Creates a new, empty WeightCache.
    pub fn new() -> Self {
        Self {
            cache: RwLock::new(HashMap::new()),
        }
    }

    /// Inserts a new weight tensor into the cache.
    /// This method requires a mutable reference (`&mut self`) because it modifies
    /// the cache structure. It acquires a write lock, which is exclusive.
    ///
    /// # Arguments
    /// * `key` - A string key to identify the weight tensor.
    /// * `weights` - The actual weight data as a `Vec<f32>`.
    ///
    /// # How it works
    /// 1. It acquires a write lock on the internal `HashMap`. This blocks until
    ///    all other readers and writers have released their locks.
    /// 2. It wraps the input `Vec<f32>` in an `Arc` (Atomic Reference Counted) pointer.
    ///    This is the key to zero-copy sharing. The `Arc` allows the data to exist
    ///    on the heap once, with multiple threads holding a reference to it.
    /// 3. It inserts the `Arc`-wrapped weight into the `HashMap`.
    /// 4. The write lock is automatically released when the guard goes out of scope.
    pub fn insert(&mut self, key: String, weights: Vec<f32>) {
        println!("[Writer] Acquiring write lock to insert '{}'", key);
        let mut cache = self.cache.write().unwrap(); // Blocks here if readers are active
        let shared_weights = Arc::new(weights);
        cache.insert(key, shared_weights);
        println!("[Writer] Inserted '{}'. Lock released.", key);
    }

    /// Retrieves a weight tensor from the cache.
    /// This method takes an immutable reference (`&self`) because it only reads data.
    /// Multiple threads can call this method concurrently.
    ///
    /// # Arguments
    /// * `key` - The string key of the weight tensor to retrieve.
    ///
    /// # Returns
    /// An `Option<SharedWeight>`. It's `Some(Arc<Vec<f32>>)` if the key exists,
    /// otherwise `None`.
    ///
    /// # How it works
    /// 1. It acquires a read lock on the internal `HashMap`. This allows other
    ///    readers to also acquire a read lock simultaneously.
    /// 2. It looks up the key in the `HashMap`.
    /// 3. If found, it clones the `Arc`. This is a very cheap operation; it only
    ///    increments the atomic reference count, it does NOT clone the underlying
    ///    `Vec<f32>` data.
    /// 4. The read lock is released automatically.
    pub fn get(&self, key: &str) -> Option<SharedWeight> {
        println!("[Reader-{}] Acquiring read lock for '{}'", thread::current().name().unwrap_or("unknown"), key);
        let cache = self.cache.read().unwrap(); // Blocks only if a writer is active
        let result = cache.get(key).cloned(); // Cheap Arc clone
        println!("[Reader-{}] Released read lock for '{}'", thread::current().name().unwrap_or("unknown"), key);
        result
    }
}

/// A worker function that simulates an inference thread.
/// It repeatedly accesses the shared weight cache to perform its task.
fn inference_worker(cache: Arc<WeightCache>, weight_key: String) {
    // Give the main thread a moment to populate the cache.
    thread::sleep(Duration::from_millis(100));

    for i in 0..3 {
        // The worker gets a clone of the Arc, not a copy of the data.
        if let Some(weights) = cache.get(&weight_key) {
            // In a real scenario, this is where the heavy computation happens.
            // We just simulate a tiny bit of work here.
            let sum: f32 = weights.iter().take(10).sum();
            println!(
                "[Worker-{}] Iteration {}: Got weights, sum of first 10 elements = {:.4}",
                thread::current().name().unwrap_or("unnamed"),
                i,
                sum
            );
        } else {
            println!(
                "[Worker-{}] Iteration {}: Weight '{}' not found in cache.",
                thread::current().name().unwrap_or("unnamed"),
                i,
                weight_key
            );
        }
        thread::sleep(Duration::from_millis(50));
    }
}

fn main() {
    // 1. Create the central cache. It's not thread-safe by itself,
    //    so we wrap it in an Arc to share it across threads.
    let mut cache = WeightCache::new();
    let shared_cache = Arc::new(cache);

    // 2. Populate the cache with some dummy model weights.
    //    This happens on the main thread before workers start.
    println!("--- Main Thread: Loading model weights ---");
    let layer1_weights: Vec<f32> = (0..1000).map(|i| i as f32 * 0.01).collect();
    // We need a mutable reference to the Arc to call `insert`, but `Arc` doesn't provide
    // interior mutability. So we use `get_mut` on the `Arc` when we are the sole owner.
    // In a real server, this might be done during initialization before sharing.
    if let Some(cache_mut) = Arc::get_mut(&mut shared_cache) {
        cache_mut.insert("layer1".to_string(), layer1_weights);
    }
    println!("--- Main Thread: Model loaded, starting workers ---");

    // 3. Spawn multiple worker threads that will read from the cache concurrently.
    let mut handles = vec
![];
    for i in 0..4 {
        // Clone the Arc for each thread. This increments the reference count.
        let cache_clone = Arc::clone(&shared_cache)
;
        let key_clone = "layer1".to_string();
        let handle = thread::Builder::new()
            .name(format!("Worker-{}", i))
            .spawn(move || {
                inference_worker(cache_clone, key_clone);
            })
            .unwrap();
        handles.push(handle);
    }

    // 4. Wait for all worker threads to complete.
    for handle in handles {
        handle.join().unwrap();
    }

    println!("--- All workers finished. Program exiting. ---");
}
