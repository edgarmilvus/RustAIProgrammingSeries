
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.rs
// Description: Solution for Exercise 1
// ==========================================

use std::sync::atomic::{AtomicUsize, Ordering};
use std::marker::PhantomData;
use std::ptr;

/// A custom thread-safe handle for immutable data.
/// Internally uses atomic reference counting for thread-safe cloning and dropping.
pub struct WeightHandle<T> {
    // Pointer to the immutable data on the heap.
    data_ptr: *const T,
    // Pointer to the heap-allocated atomic reference counter.
    count_ptr: *mut AtomicUsize,
    // PhantomData to tell the compiler that this struct logically owns a T.
    _marker: PhantomData<T>,
}

// Explicitly mark as Send and Sync since T is Send+Sync and we manage pointers manually.
unsafe impl<T: Send + Sync> Send for WeightHandle<T> {}
unsafe impl<T: Send + Sync> Sync for WeightHandle<T> {}

impl<T> WeightHandle<T> {
    /// Creates a new WeightHandle.
    pub fn new(value: T) -> Self {
        // Allocate memory for the data and the counter on the heap.
        let data = Box::new(value);
        let counter = Box::new(AtomicUsize::new(1)); // Start with 1 reference.

        // Convert Box to raw pointers (transferring ownership).
        let data_ptr = Box::into_raw(data);
        let count_ptr = Box::into_raw(counter);

        WeightHandle {
            data_ptr,
            count_ptr,
            _marker: PhantomData,
        }
    }

    /// Returns the number of active references.
    /// Acquire ordering ensures that any reads from this handle see
    /// the writes that happened before the reference count was incremented.
    pub fn strong_count(&self) -> usize {
        unsafe {
            // Safety: count_ptr is valid as long as self exists.
            (*self.count_ptr).load(Ordering::Acquire)
        }
    }
}

impl<T> Clone for WeightHandle<T> {
    fn clone(&self) -> Self {
        unsafe {
            // Safety: count_ptr is valid as long as self exists.
            // We use Relaxed ordering because the synchronization happens
            // via the data pointer itself or fences in other parts of the system.
            // However, for a general reference count, Relaxed is sufficient for
            // incrementing the count itself.
            let old_count = (*self.count_ptr).fetch_add(1, Ordering::Relaxed);
            
            // Check for overflow (unlikely for usize, but good practice).
            if old_count > isize::MAX as usize {
                std::process::abort();
            }
        }

        Self {
            data_ptr: self.data_ptr,
            count_ptr: self.count_ptr,
            _marker: PhantomData,
        }
    }
}

impl<T> Drop for WeightHandle<T> {
    fn drop(&mut self) {
        unsafe {
            // Safety: We are the owner of this handle.
            // Decrement the count. If it hits 0, we are the last owner.
            if (*self.count_ptr).fetch_sub(1, Ordering::Release) != 1 {
                return;
            }

            // Fence to ensure that all memory operations on this data
            // happen before we deallocate.
            std::sync::atomic::fence(Ordering::Acquire);

            // Reconstruct Boxes to drop them and free memory.
            // Safety: The pointer was created via Box::into_raw, so it is valid
            // to reconstruct the Box here.
            let _ = Box::from_raw(self.data_ptr);
            let _ = Box::from_raw(self.count_ptr);
        }
    }
}

// Helper to access the underlying data (unsafe due to dereferencing raw pointer).
impl<T> WeightHandle<T> {
    pub unsafe fn get(&self) -> &T {
        &*self.data_ptr
    }
}
