
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.rs
// Description: Solution for Exercise 3
// ==========================================

// mem-inspect/src/main.rs
use std::collections::HashMap;
use std::mem;
use std::env;

// Define a trait to unify type inspection.
trait TypeInspector {
    fn size(&self) -> usize;
    fn align(&self) -> usize;
    fn name(&self) -> &str;
    fn inspect(&self) {
        let size = self.size();
        let align = self.align();
        println!("Type: {}", self.name());
        println!("  Size: {} bytes", size);
        println!("  Alignment: {} bytes", align);
        
        if size == 0 {
            println!("  Category: Zero Sized Type (ZST)");
        } else if size % align != 0 {
            println!("  Note: Size is not a multiple of alignment (potential padding issues)");
        } else {
            println!("  Layout: Standard");
        }
    }
}

// Macro to generate inspectors for concrete types.
macro_rules! impl_inspector {
    ($ty:ty, $name:expr) => {
        struct Inspector;
        impl TypeInspector for Inspector {
            fn size(&self) -> usize { mem::size_of::<$ty>() }
            fn align(&self) -> usize { mem::align_of::<$ty>() }
            fn name(&self) -> &str { $name }
        }
    };
}

// Generate inspectors for our registry types.
impl_inspector!(i32, "i32");
impl_inspector!(f64, "f64");
impl_inspector!(Vec<u8>, "Vec<u8>");
impl_inspector!(std::sync::Arc<i32>, "std::sync::Arc<i32>");

fn main() {
    let args: Vec<String> = env::args().collect();
    
    // Basic CLI parsing
    let type_name = args.get(1)
        .map(|s| s.as_str())
        .unwrap_or("i32"); // Default to i32 if no arg provided

    // Registry simulation
    // In a real dynamic tool, we would use plugins or reflection. 
    // Here we map strings to our static inspector structs.
    let registry: HashMap<&str, Box<dyn TypeInspector>> = {
        let mut m = HashMap::new();
        m.insert("i32", Box::new(Inspector) as Box<dyn TypeInspector>);
        m.insert("f64", Box::new(Inspector) as Box<dyn TypeInspector>);
        m.insert("Vec<u8>", Box::new(Inspector) as Box<dyn TypeInspector>);
        m.insert("std::sync::Arc<i32>", Box::new(Inspector) as Box<dyn TypeInspector>);
        m
    };

    if let Some(inspector) = registry.get(type_name) {
        inspector.inspect();
        
        // Bonus: Cache line calculation
        if env::args().any(|arg| arg == "--cache-line") {
            let size = inspector.size();
            let cache_line_size = 64; // Standard assumption
            let elements_per_line = cache_line_size / size;
            let remainder = cache_line_size % size;
            
            println!("\n--- Cache Line Analysis ({} bytes) ---", cache_line_size);
            if elements_per_line > 0 {
                println!("Elements per cache line: {}", elements_per_line);
            } else {
                println!("Element is larger than a cache line.");
            }
            println!("Padding required to align to cache line: {}", remainder);
        }
    } else {
        eprintln!("Error: Type '{}' not found in registry.", type_name);
        eprintln!("Available types: i32, f64, Vec<u8>, std::sync::Arc<i32>");
        std::process::exit(1);
    }
}
