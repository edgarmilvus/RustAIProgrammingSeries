
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.rs
// Description: Solution for Exercise 4
// ==========================================

use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::{Arc, RwLock};
use std::collections::HashMap;
use std::thread;
use std::time::Duration;

// Reusing the WeightHandle from Exercise 1, but adding the evictable flag.
pub struct WeightHandle<T> {
    data_ptr: *const T,
    count_ptr: *mut AtomicUsize,
    evictable: AtomicBool, // New flag
}

// Implementation details (simplified for brevity, assuming same safety as Ex 1)
impl<T> WeightHandle<T> {
    pub fn new(value: T) -> Self {
        let data = Box::new(value);
        let counter = Box::new(AtomicUsize::new(1));
        WeightHandle {
            data_ptr: Box::into_raw(data),
            count_ptr: Box::into_raw(counter),
            evictable: AtomicBool::new(false),
        }
    }

    pub fn mark_evictable(&self) {
        self.evictable.store(true, Ordering::Release);
    }

    pub fn is_evictable(&self) -> bool {
        self.evictable.load(Ordering::Acquire)
    }
    
    // Helper to get strong count (unsafe, for internal use)
    unsafe fn strong_count(&self) -> usize {
        (*self.count_ptr).load(Ordering::Relaxed)
    }
}

// Clone implementation (similar to Ex 1, but needs to copy the evictable flag logic if needed)
impl<T> Clone for WeightHandle<T> {
    fn clone(&self) -> Self {
        unsafe {
            (*self.count_ptr).fetch_add(1, Ordering::Relaxed);
        }
        Self {
            data_ptr: self.data_ptr,
            count_ptr: self.count_ptr,
            evictable: AtomicBool::new(self.evictable.load(Ordering::Relaxed)),
        }
    }
}

// Drop implementation (similar to Ex 1)
impl<T> Drop for WeightHandle<T> {
    fn drop(&mut self) {
        unsafe {
            if (*self.count_ptr).fetch_sub(1, Ordering::Release) == 1 {
                std::sync::atomic::fence(Ordering::Acquire);
                let _ = Box::from_raw(self.data_ptr);
                let _ = Box::from_raw(self.count_ptr);
            }
        }
    }
}

// The Cache
pub struct WeightCache<K, V> {
    // Using RwLock<HashMap> for simplicity. 
    // In a high-performance scenario, we might use DashMap or a lock-free hash table.
    map: RwLock<HashMap<K, Arc<WeightHandle<V>>>>,
}

impl<K, V> WeightCache<K, V>
where
    K: Eq + std::hash::Hash + Clone,
{
    pub fn new() -> Self {
        WeightCache {
            map: RwLock::new(HashMap::new()),
        }
    }

    pub fn insert(&self, key: K, value: V) {
        let handle = Arc::new(WeightHandle::new(value));
        let mut map = self.map.write().unwrap();
        map.insert(key, handle);
    }

    pub fn get(&self, key: &K) -> Option<Arc<WeightHandle<V>>> {
        let map = self.map.read().unwrap();
        map.get(key).cloned()
    }

    pub fn mark_for_eviction(&self, key: &K) -> bool {
        if let Some(handle) = self.map.read().unwrap().get(key) {
            handle.mark_evictable();
            true
        } else {
            false
        }
    }

    /// Scans the map and removes entries that are marked evictable 
    /// AND have a reference count of 1 (only held by the cache).
    pub fn cleanup_evicted(&self) -> usize {
        let mut map = self.map.write().unwrap();
        let mut removed_count = 0;
        
        // We collect keys to remove to avoid borrow checker issues while iterating
        let keys_to_remove: Vec<K> = map.iter()
            .filter(|(_, handle)| {
                // Check if marked
                if handle.is_evictable() {
                    // Check strong count. 
                    // Note: handle.strong_count() returns the count including this reference in the map.
                    // If count is 1, it means no external threads hold it, only the map itself.
                    unsafe {
                        if handle.strong_count() == 1 {
                            return true;
                        }
                    }
                }
                false
            })
            .map(|(k, _)| k.clone())
            .collect();

        for key in keys_to_remove {
            map.remove(&key);
            removed_count += 1;
        }

        removed_count
    }
}
