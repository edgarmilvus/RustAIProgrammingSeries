
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.rs
// Description: Solution for Exercise 2
// ==========================================

use std::ptr;
use std::mem;
use std::cell::UnsafeCell;

// We use the standard constant if available, or fallback to 64 bytes.
#[allow(dead_code)]
const CACHE_LINE_SIZE: usize = std::hardware_destructive_interference_size;

/// A wrapper that pads a value to ensure it occupies a full cache line.
#[repr(C, align(64))] // Explicitly align to 64 bytes (common cache line size)
pub struct CacheLinePadded<T> {
    value: T,
    // Padding is implicit based on alignment and size. 
    // If T is smaller than 64 bytes, the compiler adds padding at the end.
}

/// A simple bump-pointer arena for demonstration.
pub struct MemoryArena {
    buffer: Vec<u8>,
    offset: usize,
}

impl MemoryArena {
    pub fn new(capacity: usize) -> Self {
        MemoryArena {
            buffer: Vec::with_capacity(capacity),
            offset: 0,
        }
    }

    /// Allocates space for a T, aligns it, and writes the value.
    /// Returns a mutable pointer to the allocated slot.
    pub fn allocate<T>(&mut self, value: T) -> *mut CacheLinePadded<T> {
        // Calculate alignment for CacheLinePadded<T>.
        // Since CacheLinePadded<T> is #[repr(C, align(64))], its alignment is 64.
        let align = mem::align_of::<CacheLinePadded<T>>();
        
        // Calculate the padding needed to align the current offset.
        let align_offset = (align - (self.offset % align)) % align;
        
        // Ensure we have enough capacity.
        let required_size = mem::size_of::<CacheLinePadded<T>>();
        let new_len = self.offset + align_offset + required_size;
        
        if new_len > self.buffer.capacity() {
            // In a real arena, we might allocate a new chunk. 
            // For this exercise, we just panic if we run out of space.
            panic!("MemoryArena capacity exceeded");
        }
        
        // Resize the buffer to the new length to make space initialized.
        self.buffer.resize(new_len, 0);
        
        // Calculate the pointer address.
        let ptr = unsafe { self.buffer.as_mut_ptr().add(self.offset + align_offset) } as *mut CacheLinePadded<T>;
        
        // Write the value.
        // We use ptr::write because we are initializing uninitialized memory.
        unsafe {
            let wrapper = CacheLinePadded { value };
            ptr::write(ptr, wrapper);
        }
        
        // Update offset for next allocation.
        self.offset = new_len;
        
        ptr
    }
}
