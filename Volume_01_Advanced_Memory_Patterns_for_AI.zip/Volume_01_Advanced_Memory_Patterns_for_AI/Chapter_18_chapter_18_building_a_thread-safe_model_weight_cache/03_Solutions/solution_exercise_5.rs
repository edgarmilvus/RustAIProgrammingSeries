
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.rs
// Description: Solution for Exercise 5
// ==========================================

use std::sync::atomic::{AtomicPtr, Ordering};
use std::ptr;
use std::thread;
use std::time::Duration;

// ==========================================
// PART A: The Buggy Naive Implementation
// ==========================================

struct Node<T> {
    value: T,
    next: *mut Node<T>,
}

struct LockFreeStack<T> {
    head: AtomicPtr<Node<T>>,
}

impl<T> LockFreeStack<T> {
    fn new() -> Self {
        LockFreeStack {
            head: AtomicPtr::new(ptr::null_mut()),
        }
    }

    fn push(&self, value: T) {
        let mut node = Box::new(Node {
            value,
            next: ptr::null_mut(),
        });
        let node_ptr = Box::into_raw(node);

        loop {
            let current_head = self.head.load(Ordering::Relaxed);
            unsafe { (*node_ptr).next = current_head; }
            
            if self.head.compare_and_swap(current_head, node_ptr, Ordering::SeqCst) == current_head {
                break;
            } else {
                // CAS failed, retry (node_ptr is reused, but that's fine here)
            }
        }
    }

    fn pop(&self) -> Option<T> {
        loop {
            let current_head = self.head.load(Ordering::Relaxed);
            
            if current_head.is_null() {
                return None;
            }

            let next_head = unsafe { (*current_head).next };

            // CAS: Try to swap head with next_head
            if self.head.compare_and_swap(current_head, next_head, Ordering::SeqCst) == current_head {
                // Success: We claimed the node.
                // SAFETY: We are the only thread that successfully popped this node.
                unsafe {
                    let node = Box::from_raw(current_head);
                    return Some(node.value);
                }
            }
            // CAS failed: Retry loop
        }
    }
}

// ==========================================
// PART B: The ABA Simulation Test
// ==========================================

pub fn run_aba_simulation() {
    println!("=== Running ABA Simulation (Buggy Version) ===");
    
    // Using a pointer to a dummy node to simulate "A" being reused.
    // In a real scenario, A is popped, freed, and a new allocation (C) 
    // might reuse the exact same memory address as A.
    
    let stack = LockFreeStack::new();
    
    // Thread 1 Logic
    let handle1 = thread::spawn(|| {
        // 1. Push A (Value 10)
        stack.push(10); 
        println!("Thread 1: Pushed 10 (A)");
        
        // 2. Push B (Value 20)
        stack.push(20);
        println!("Thread 1: Pushed 20 (B)");
        
        // 3. Pop B (Leaving A at head)
        stack.pop();
        println!("Thread 1: Popped 20 (B)");
        
        // Simulate delay to let Thread 2 read A
        thread::sleep(Duration::from_millis(100));
        
        // 4. Pop A (Stack becomes empty)
        stack.pop();
        println!("Thread 1: Popped 10 (A) - Stack Empty");
        
        // 5. Push C (Value 30)
        // Note: In Rust, memory addresses might be reused immediately.
        // Let's push C. It might land at the same address A was at.
        stack.push(30);
        println!("Thread 1: Pushed 30 (C)");
    });

    // Thread 2 Logic
    let handle2 = thread::spawn(|| {
        // 1. Read Head (Expecting A)
        let head = stack.head.load(Ordering::Relaxed);
        let val = unsafe { (*head).value };
        println!("Thread 2: Read head value: {} (A)", val);
        
        // 2. Context Switch (Simulated by sleep)
        thread::sleep(Duration::from_millis(200));
        
        // 3. Attempt to Pop A
        // Thread 2 still holds the pointer `head` (address of A).
        // The stack currently contains C (at potentially the same address).
        // Thread 2 tries CAS with the old pointer `head`.
        
        // In this specific Rust implementation, the address of C might differ from A.
        // However, the BUG exists conceptually: Thread 2 thinks the stack state is [A],
        // but it is actually [C].
        // If the address is reused, the CAS succeeds, popping C thinking it popped A.
        
        println!("Thread 2: Attempting to pop A...");
        let result = stack.pop();
        match result {
            Some(v) => println!("Thread 2: Popped value: {}", v),
            None => println!("Thread 2: Stack empty (Pop failed)"),
        }
    });

    handle1.join().unwrap();
    handle2.join().unwrap();
}

// ==========================================
// PART C: The Fix (Tagged Pointer)
// ==========================================

// We need a way to pack a pointer and a tag (version) into a single atomic word.
// Since AtomicPtr is just a wrapper around an atomic integer, we can use 
// AtomicUsize to simulate a tagged pointer, or use a custom struct if we 
// have 128-bit atomics available (rare). 
// For this exercise, we will use AtomicUsize where the lower bits are the tag
// and the upper bits are the pointer (assuming 48-bit addressing).

struct TaggedNode<T> {
    value: T,
    next: *mut TaggedNode<T>, // Raw pointer, not tagged.
}

struct TaggedStack<T> {
    // We store the head as an AtomicUsize representing (ptr << 16 | tag)
    head: AtomicUsize,
    _marker: std::marker::PhantomData<T>,
}

impl<T> TaggedStack<T> {
    fn new() -> Self {
        TaggedStack {
            head: AtomicUsize::new(0),
            _marker: std::marker::PhantomData,
        }
    }

    // Helper to pack pointer and tag into a usize.
    // Assumes 64-bit system. We use 16 bits for tag, 48 for pointer.
    fn pack(ptr: *mut TaggedNode<T>, tag: usize) -> usize {
        let ptr_val = ptr as usize;
        // In a real scenario, we'd check for overflow.
        (ptr_val << 16) | (tag & 0xFFFF)
    }

    // Helper to unpack
    fn unpack(val: usize) -> (*mut TaggedNode<T>, usize) {
        let tag = val & 0xFFFF;
        let ptr_val = val >> 16;
        (ptr_val as *mut TaggedNode<T>, tag)
    }

    fn push(&self, value: T) {
        let mut node = Box::new(TaggedNode {
            value,
            next: ptr::null_mut(),
        });
        let node_ptr = Box::into_raw(node);

        loop {
            let current_packed = self.head.load(Ordering::Relaxed);
            let (current_head, current_tag) = Self::unpack(current_packed);
            
            unsafe { (*node_ptr).next = current_head; }
            
            let new_packed = Self::pack(node_ptr, current_tag + 1);
            
            // CAS on the usize value (pointer + tag)
            if self.head.compare_and_swap(current_packed, new_packed, Ordering::SeqCst) == current_packed {
                break;
            }
        }
    }

    fn pop(&self) -> Option<T> {
        loop {
            let current_packed = self.head.load(Ordering::Relaxed);
            let (current_head, current_tag) = Self::unpack(current_packed);

            if current_head.is_null() {
                return None;
            }

            let next_head = unsafe { (*current_head).next };
            
            // We increment the tag on modification
            let new_packed = Self::pack(next_head, current_tag + 1);

            // CAS compares the FULL packed value (ptr + tag)
            if self.head.compare_and_swap(current_packed, new_packed, Ordering::SeqCst) == current_packed {
                unsafe {
                    let node = Box::from_raw(current_head);
                    return Some(node.value);
                }
            }
        }
    }
}

// Test for the fixed version
pub fn run_fixed_aba() {
    println!("\n=== Running Fixed Tagged Pointer Version ===");
    let stack = TaggedStack::new();
    
    let handle1 = thread::spawn(|| {
        stack.push(10);
        stack.push(20);
        stack.pop(); // Pops 20
        thread::sleep(Duration::from_millis(50));
        stack.pop(); // Pops 10
        stack.push(30); // Pushes 30
    });

    let handle2 = thread::spawn(|| {
        // Read head (Tag 0, Ptr A)
        let head_val = stack.head.load(Ordering::Relaxed);
        let (ptr, tag) = TaggedStack::<i32>::unpack(head_val);
        println!("Thread 2 read: Tag {}, Ptr {:?}", tag, ptr);
        
        thread::sleep(Duration::from_millis(100));
        
        // Attempt CAS with OLD packed value (Tag 0, Ptr A)
        // This will fail because Thread 1 changed it to Tag 2, Ptr C (or similar)
        let new_head = ptr::null_mut(); 
        let new_packed = TaggedStack::<i32>::pack(new_head, tag + 1); // Trying to update to Tag 1
        
        let result = stack.head.compare_and_swap(head_val, new_packed, Ordering::SeqCst);
        
        if result == head_val {
            println!("Thread 2 CAS Succeeded (Unexpected in fixed version)");
        } else {
            println!("Thread 2 CAS Failed (Correct behavior - ABA prevented)");
        }
    });

    handle1.join().unwrap();
    handle2.join().unwrap();
}
