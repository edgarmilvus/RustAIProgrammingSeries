
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/RustAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_example.rs
// Description: Advanced Application Example
// ==========================================

use std::collections::HashMap;
use std::sync::{Arc, RwLock, Weak};
use std::time::{Duration, Instant};

/// Represents a heavy model weight (e.g., a neural network layer).
/// In a real scenario, this might wrap a tensor library type like `tch::Tensor`.
#[derive(Debug, Clone)]
pub struct ModelWeights {
    pub name: String,
    pub data: Arc<Vec<f32>>,
    pub loaded_at: Instant,
}

/// A cache entry holding a strong reference to the weights and metadata.
/// We align this to `cache_line_size` (typically 64 bytes) to prevent
/// false sharing when multiple threads access different entries concurrently.
#[repr(align(64))]
pub struct CacheEntry {
    pub weights: Arc<ModelWeights>,
    pub last_accessed: Instant,
    pub access_count: u64,
}

/// A thread-safe cache for model weights.
/// Uses `RwLock` for interior mutability of the map, but the values
/// are `Arc` wrapped, allowing readers to access weights without locking the map.
pub struct ModelWeightCache {
    // Maps model names to their cache entries.
    storage: RwLock<HashMap<String, CacheEntry>>,
    // Tracks total estimated memory usage to trigger eviction.
    current_memory_usage: std::sync::atomic::AtomicUsize,
    // Maximum memory in bytes before eviction is triggered.
    capacity: usize,
}

impl ModelWeightCache {
    /// Creates a new cache with a specific memory capacity (in bytes).
    pub fn new(capacity: usize) -> Self {
        Self {
            storage: RwLock::new(HashMap::new()),
            current_memory_usage: std::sync::atomic::AtomicUsize::new(0),
            capacity,
        }
    }

    /// Loads a model into the cache. If the cache is full, it triggers eviction.
    /// This function simulates the expensive I/O operation of loading weights.
    pub fn load_model(&self, name: &str, size_bytes: usize) -> Arc<ModelWeights> {
        // 1. Check if already cached (Read Lock)
        {
            let store = self.storage.read().unwrap();
            if let Some(entry) = store.get(name) {
                // Update metadata (simulated mutation via interior mutability pattern if needed,
                // but here we just return the existing Arc).
                println!("[Cache] Hit: {} (Cached)", name);
                return entry.weights.clone();
            }
        }

        // 2. Cache Miss: Simulate loading from disk/network
        println!("[Cache] Miss: Loading {} ({} MB)...", name, size_bytes / 1_000_000);
        let data = vec
![1.0f32; size_bytes / 4]; // Simulate f32 tensor data
        let weights = Arc::new(ModelWeights {
            name: name.to_string()
,
            data: Arc::new(data),
            loaded_at: Instant::now(),
        });

        // 3. Eviction Logic if necessary
        self.evict_if_needed(size_bytes);

        // 4. Insert into Cache (Write Lock)
        let mut store = self.storage.write().unwrap();
        let entry = CacheEntry {
            weights: weights.clone(),
            last_accessed: Instant::now(),
            access_count: 0,
        };
        store.insert(name.to_string(), entry);
        
        // Update memory counter
        self.current_memory_usage
            .fetch_add(size_bytes, std::sync::atomic::Ordering::SeqCst);

        weights
    }

    /// Accesses a model weight. Returns `None` if not found.
    /// This is a hot path and should be extremely fast.
    pub fn get(&self, name: &str) -> Option<Arc<ModelWeights>> {
        let mut store = self.storage.write().unwrap(); // Write lock to update access stats
        store.get_mut(name).map(|entry| {
            entry.last_accessed = Instant::now();
            entry.access_count += 1;
            entry.weights.clone()
        })
    }

    /// Eviction strategy: Removes Least Recently Used (LRU) items until space is available.
    /// Uses `Weak` pointers to verify if the data is still in use elsewhere before panicking.
    fn evict_if_needed(&self, requested_size: usize) {
        let current_usage = self.current_memory_usage.load(std::sync::atomic::Ordering::Relaxed);
        
        if current_usage + requested_size <= self.capacity {
            return;
        }

        println!("[Cache] Pressure detected. Starting eviction...");

        let mut store = self.storage.write().unwrap();
        let mut to_remove = Vec::new();

        // Identify candidates (Naive LRU scan)
        // In production, use a linked list (e.g., `linked_hash_set`) for O(1) eviction.
        let mut sorted_entries: Vec<(&String, &CacheEntry)> = store.iter().collect();
        sorted_entries.sort_by_key(|(_, entry)| entry.last_accessed);

        let mut freed_memory = 0;
        
        for (name, entry) in sorted_entries {
            // Check if this Arc is the only strong reference (meaning no worker threads are using it)
            if Arc::strong_count(&entry.weights) == 1 {
                let size = entry.weights.data.capacity() * std::mem::size_of::<f32>();
                freed_memory += size;
                to_remove.push(name.clone());
                println!("[Cache] Evicting: {} ({} bytes)", name, size);

                if current_usage + requested_size - freed_memory <= self.capacity {
                    break;
                }
            } else {
                println!("[Cache] Skipping {} (in use by {} threads)", name, Arc::strong_count(&entry.weights) - 1);
            }
        }

        // Perform removal
        for name in to_remove {
            store.remove(&name);
        }

        self.current_memory_usage.fetch_sub(freed_memory, std::sync::atomic::Ordering::SeqCst);
    }
}

/// Simulates a worker thread that performs inference.
fn simulate_worker(cache: Arc<ModelWeightCache>, model_name: &'static str, duration_ms: u64) {
    std::thread::spawn(move || {
        let weights = cache.load_model(model_name, 1024 * 1024 * 5); // 5MB model
        
        // Simulate inference work
        std::thread::sleep(Duration::from_millis(duration_ms));
        
        // Accessing the weights (Zero-copy, just cloning the Arc pointer)
        let _data = weights.data.clone();
        println!("Worker finished processing {}", model_name);
    });
}

fn main() {
    // Initialize cache with 10MB capacity
    let cache = Arc::new(ModelWeightCache::new(10 * 1024 * 1024));

    // Spawn multiple threads simulating concurrent inference requests
    let handles = vec
![
        std::thread::spawn({
            let c = cache.clone()
;
            move || simulate_worker(c, "ResNet50", 50)
        }),
        std::thread::spawn({
            let c = cache.clone();
            move || simulate_worker(c, "BERT-Large", 100)
        }),
        std::thread::spawn({
            let c = cache.clone();
            move || simulate_worker(c, "GPT-3", 200)
        }),
    ];

    // Wait for workers to finish
    for h in handles {
        h.join().unwrap();
    }

    // Trigger manual eviction check
    println!("\n--- Main Thread: Requesting new large model ---");
    cache.load_model("VisionTransformer", 8 * 1024 * 1024); // 8MB, should trigger eviction

    println!("Execution complete.");
}
